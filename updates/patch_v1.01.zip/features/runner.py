# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - VERSION 1.0 (PRODUCTION MASTER)
================================================================================
QUICK NAVIGATION INDEX & ARCHITECTURE MAP
================================================================================
[SECTION 01: ENVIRONMENT & DESKTOP ATTACH] ................. Line ~65
    - WINSTA0 / Desktop station attach (ctypes Win32 API)
[SECTION 02: IMPORTS & CORE DEPENDENCIES] .................. Line ~85
    - PySide6 GUI toolkit, PIL, OpenCV, Tesseract OCR
[SECTION 03: FILE PATHS & ASSET DIRECTORIES] ............... Line ~130
    - DEMO_DIR, ICONS_DIR, CONFIG_DIR, Cursor paths (.cur/.ani)
[SECTION 04: PERSISTENCE & SETTINGS] ....................... Line ~160
    - WindowStateManager (window_state.json)
[SECTION 05: ATMOSPHERIC & HEADER WIDGETS] ................. Line ~200
    - AnimatedAirOverlay (cursor trail glow)
    - GrabHandle (top window draggable pill)
    - BrandHeaderWidget (neon cyber-lime logo badge)
    - HeaderPillButton (Pin, More options, Close micro-buttons)
[SECTION 06: MENU & SCROLL CONTAINERS] ..................... Line ~460
    - SmoothScrollArea (frictionless vertical scroll, 8px offset)
    - AnimatedMenuRow (icon + label popup row)
    - ThreeDotsMenu (floating dark-glass settings popup)
[SECTION 07: 3x3 TASKS & OPERATION CARDS] .................. Line ~680
    - TaskCard (Edit, Resize, Convert, Compress, Watermark, etc.)
    - Clean Lucide vector icons (clock-arc Rotate, inward diagonal Compress)
[SECTION 08: FLOATING CONTROLS & STACK SHOWCASE] ........... Line ~900
    - ZoomSliderBar (floating [- 100% + ⟲] zoom controller)
    - PaperTiltStackWidget (left-side exclusive 384x404 stack preview)
[SECTION 09: THUMBNAIL CAROUSEL STRIP] ..................... Line ~1300
    - CarouselCircleBtn (‹ and › glass chevrons)
    - CarouselThumbItem (aspect-ratio thumbnail card)
    - CarouselPillNav (horizontal strip container + embedded zoom bar)
[SECTION 10: CONJOINED BOTTOM FOOTER PILLS] ................ Line ~1500
    - AnimatedOutputDropdown (4-item destination menu with hr divider)
    - OutputPillButton (📁 Output ▾ dropdown trigger)
    - LocationHoverPopup (razor-sharp capsule tooltip, zero corner clipping)
    - DestinationPillButton (📁 D:\\...\\demo_images folder button)
[SECTION 11: CALL-TO-ACTION (CTA) BUTTON] ................... Line ~1900
    - SaveItButton (radiant Cyber-Lime #bbf451 -> #a3e635 pill capsule)
[SECTION 12: MODAL WORKFLOW DIALOGS] ....................... Line ~2000
    - BackgroundRemoverModal (OpenCV GrabCut foreground isolation)
    - MetadataToolModal (EXIF inspection & editing table)
    - TextExtractorModal (Tesseract OCR text extraction)
[SECTION 13: GLOBAL HOTKEY HOOK] ........................... Line ~2450
    - GlobalKeyboardHook (WH_KEYBOARD_LL low-level Windows hook)
[SECTION 14: MASTER APPLICATION HUD] ....................... Line ~2500
    - SuperMouseHUD (split layout, spring entry from behind taskbar)
    - System cursor watchdog timer (3000ms registry enforcement)
================================================================================
"""

import sys
import os
import sys
import json
import math
import time
import atexit
import ctypes
from ctypes import wintypes

# ── Attach to interactive desktop BEFORE any Qt import ─────────────────────────
user32 = ctypes.windll.user32
WINSTA_ALL_ACCESS  = 0x37F
DESKTOP_ALL_ACCESS = 0x1FF

hwinsta = user32.OpenWindowStationW("WinSta0", False, WINSTA_ALL_ACCESS)
if hwinsta:
    user32.SetProcessWindowStation(hwinsta)
    hdesk = user32.OpenDesktopW("default", 0, False, DESKTOP_ALL_ACCESS)
    if hdesk:
        user32.SetThreadDesktop(hdesk)

from PySide6.QtSvg import QSvgRenderer
from PySide6.QtCore import (
    QEvent,
    QByteArray,
    Qt, QSize, QPoint, QPointF, QRect, QRectF, QTimer, Signal, QObject,
    QPropertyAnimation, QParallelAnimationGroup, QEasingCurve, Property, QSettings
)
from PySide6.QtGui import (
    QPainter, QColor, QPen, QBrush, QLinearGradient, QRadialGradient,
    QPainterPath, QPixmap, QIcon, QCursor, QFont, QFontMetrics, QAction,
    QImage, QImageReader, QPolygonF
)
from PySide6.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QComboBox,
    QHBoxLayout, QVBoxLayout, QGridLayout, QFrame,
    QGraphicsDropShadowEffect, QScrollArea, QFileDialog,
    QDialog, QTextEdit, QLineEdit, QSlider, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox
)

import winreg
from PIL import Image, ExifTags
from ui_theme import CleanBackButton
try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

try:
    import pytesseract
    PYTESSERACT_AVAILABLE = True
except ImportError:
    PYTESSERACT_AVAILABLE = False


# ──────────────────────────────────────────────────────────────────────────────
#  PATHS & ASSETS
# ──────────────────────────────────────────────────────────────────────────────
def _find_base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    cur = os.path.abspath(__file__)
    for _ in range(6):
        cur = os.path.dirname(cur)
        if os.path.isdir(os.path.join(cur, "thesupermouse", "assets")):
            return cur
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE_DIR   = _find_base_dir()
ASSETS_DIR = os.path.join(BASE_DIR, 'thesupermouse', 'assets')
ICONS_DIR  = os.path.join(ASSETS_DIR, 'hud_icons')
DEMO_DIR   = os.path.join(ASSETS_DIR, 'demo_images')
CONFIG_DIR = os.path.join(BASE_DIR, 'thesupermouse', 'config')
os.makedirs(CONFIG_DIR, exist_ok=True)
WINDOW_STATE_FILE = os.path.join(CONFIG_DIR, 'window_state.json')

CUR_NORMAL = os.path.join(ASSETS_DIR, 'supermouse_normal.cur')
CUR_HAND   = os.path.join(ASSETS_DIR, 'supermouse_hand.cur')
CUR_IBEAM  = os.path.join(ASSETS_DIR, 'supermouse_ibeam.cur')
ANI_BUSY   = os.path.join(ASSETS_DIR, 'supermouse_busy.ani')
TASKBAR_ICON_ICO = os.path.join(ASSETS_DIR, 'supermouse_taskbar_icon.ico')
TASKBAR_ICON_PNG = os.path.join(ASSETS_DIR, 'supermouse_taskbar_icon.png')

OCR_NORMAL = 32512
OCR_IBEAM  = 32513
OCR_WAIT   = 32514
OCR_HAND   = 32649

IMAGE_CURSOR      = 2
LR_LOADFROMFILE   = 0x00000010
LR_DEFAULTSIZE    = 0x00000040
SPI_SETCURSORS    = 0x0057



# [FN-RUN-0001] [SCOPE: get_hud_icon()]
# Purpose: Executes core logic routine.
# Lookup Index: #TAG_RUN_GET_HUD_ICON
def get_hud_icon(name):
    path = os.path.join(ICONS_DIR, f"{name}.png")
    # [STEP-RUN-0001] File system validation: verify path and launch target
    if os.path.exists(path):
        return QPixmap(path)
    return QPixmap()


# ──────────────────────────────────────────────────────────────────────────────
#  WINDOW STATE MANAGER (Requirement 14: Window Memory)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-001] [COMPONENT: WindowStateManager]
# Role: Core UI/logic component for WindowStateManager.
# Fast-Search Tag: #TAG_RUN_WINDOWSTATEMANAGER_DEF
# ------------------------------------------------------------------------------
class WindowStateManager:
    """
    =============================================================================
    CLASS: WindowStateManager
    =============================================================================
    Role:
        Handles persistent JSON serialization of the user's HUD preferences,
        such as pinned-to-top state, custom window positions, and recent output paths.

    Storage:
        Writes to: <CONFIG_DIR>/window_state.json

    Methods:
        - load_state() -> dict: Safely reads and returns the JSON configuration dictionary.
        - save_state(dict) -> None: Atomically writes updated state to the JSON file.
    =============================================================================
    """
    @staticmethod

    # [FN-RUN-0002] [SCOPE: WindowStateManager.load_state()]
    # Purpose: Persistence routine: synchronizes settings/state with local disk.
    # Lookup Index: #TAG_RUN_WINDOWSTATEMANAGER_LOAD_STATE
    def load_state():
        # [STEP-RUN-0002] File system validation: verify path and launch target
        if os.path.exists(WINDOW_STATE_FILE):
            # [STEP-RUN-0003] Guarded block: prevent unhandled exception propagation
            try:
                with open(WINDOW_STATE_FILE, "r", encoding="utf-8") as f:
                    # [STEP-RUN-0004] JSON serialization: encode/decode persistent state
                    return json.load(f)
            except Exception:
                pass
        return {}

    @staticmethod

    # [FN-RUN-0003] [SCOPE: WindowStateManager.save_state()]
    # Purpose: Persistence routine: synchronizes settings/state with local disk.
    # Lookup Index: #TAG_RUN_WINDOWSTATEMANAGER_SAVE_STATE
    def save_state(x, y, is_pinned=False):
        # [STEP-RUN-0005] Guarded block: prevent unhandled exception propagation
        try:
            with open(WINDOW_STATE_FILE, "w", encoding="utf-8") as f:
                # [STEP-RUN-0006] JSON serialization: encode/decode persistent state
                json.dump({"x": int(x), "y": int(y), "is_pinned": bool(is_pinned)}, f, indent=2)
        except Exception:
            pass


# ──────────────────────────────────────────────────────────────────────────────
#  ANIMATED AIR OVERLAY (Lockscreen / Global Mouse Air Wave)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-002] [COMPONENT: AnimatedAirOverlay]
# Role: Core UI/logic component for AnimatedAirOverlay.
# Fast-Search Tag: #TAG_RUN_ANIMATEDAIROVERLAY_DEF
# ------------------------------------------------------------------------------
class AnimatedAirOverlay(QWidget):
    """
    =============================================================================
    CLASS: AnimatedAirOverlay
    =============================================================================
    Role:
        A transparent full-window canvas that renders an atmospheric 'air' trail
        or ambient particle glow following cursor movements for a smooth, high-end feel.

    Key Attributes:
        - points: List of recent mouse coordinates with alpha intensity weights.
        - decay_timer: 60 FPS (16ms) timer that steadily fades the trailing glow.

    Methods:
        - update_trail(QPoint): Adds new cursor position to the trail.
        - paintEvent(QPaintEvent): Custom painter drawing radial gradient glows.
    =============================================================================
    """

    # [FN-RUN-0004] [SCOPE: AnimatedAirOverlay.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_ANIMATEDAIROVERLAY___INIT
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        # [STEP-RUN-0007] Window flags: configure topmost and frameless window behavior
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.SubWindow)

        self._t = 0.0
        # [STEP-RUN-0008] High-resolution timer dispatch: initiate execution loop
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)
        self.hide()


    # [FN-RUN-0005] [SCOPE: AnimatedAirOverlay._step()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_ANIMATEDAIROVERLAY__STEP
    def _step(self):
        self._t += 0.06
        if self._t > 6.28318:
            self._t -= 6.28318
        self.update()


    # [FN-RUN-0006] [SCOPE: AnimatedAirOverlay.set_active()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_ANIMATEDAIROVERLAY_SET_ACTIVE
    def set_active(self, active):
        if active:
            if not self._timer.isActive():
                # [STEP-RUN-0009] High-resolution timer dispatch: initiate execution loop
                self._timer.start()
            self.show()
        else:
            self._timer.stop()
            self.hide()


    # [FN-RUN-0007] [SCOPE: AnimatedAirOverlay.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_ANIMATEDAIROVERLAY_PAINTEVENT
    def paintEvent(self, e):
        if not self.isVisible():
            return
        # [STEP-RUN-0010] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        cx, cy = w / 2.0, h / 2.0

        for r_base, alpha, speed, span in [(18.0, 70, 1.0, 240.0), (32.0, 45, -0.8, 180.0)]:
            angle = math.degrees(self._t * speed)
            pen = QPen(QColor(163, 230, 53, alpha), 1.5, Qt.SolidLine, Qt.RoundCap)
            p.setPen(pen)
            rect = QRectF(cx - r_base, cy - r_base, 2 * r_base, 2 * r_base)
            p.drawArc(rect, int(angle * 16), int(span * 16))
        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  TOP HEADER GRAB HANDLE (Centred Drag Handle)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-003] [COMPONENT: GrabHandle]
# Role: Core UI/logic component for GrabHandle.
# Fast-Search Tag: #TAG_RUN_GRABHANDLE_DEF
# ------------------------------------------------------------------------------
class GrabHandle(QWidget):
    """
    =============================================================================
    CLASS: GrabHandle
    =============================================================================
    Role:
        Top-center pill grab handle that allows the user to drag and reposition
        the frameless, rounded SuperMouse HUD window across their screen.

    Interaction:
        - mousePressEvent: Records the initial mouse offset relative to window.
        - mouseMoveEvent: Translates the parent window by the drag delta.
        - mouseReleaseEvent: Concludes drag and persists new window position.
    =============================================================================
    """

    # [FN-RUN-0008] [SCOPE: GrabHandle.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_GRABHANDLE___INIT
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(64, 14)
        self.setCursor(Qt.OpenHandCursor)
        self.is_dragging = False
        self.drag_start = QPoint()


    # [FN-RUN-0009] [SCOPE: GrabHandle.mousePressEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_GRABHANDLE_MOUSEPRESSEVENT
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.is_dragging = True
            self.drag_start = e.globalPosition().toPoint() - self.window().pos()
            self.setCursor(Qt.ClosedHandCursor)


    # [FN-RUN-0010] [SCOPE: GrabHandle.mouseMoveEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_GRABHANDLE_MOUSEMOVEEVENT
    def mouseMoveEvent(self, e):
        if self.is_dragging:
            new_pos = e.globalPosition().toPoint() - self.drag_start
            self.window().move(new_pos)
            win = self.window()
            if hasattr(win, '_save_window_position'):
                win._save_window_position()


    # [FN-RUN-0011] [SCOPE: GrabHandle.mouseReleaseEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_GRABHANDLE_MOUSERELEASEEVENT
    def mouseReleaseEvent(self, e):
        self.is_dragging = False
        self.setCursor(Qt.OpenHandCursor)


    # [FN-RUN-0012] [SCOPE: GrabHandle.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_GRABHANDLE_PAINTEVENT
    def paintEvent(self, e):
        # [STEP-RUN-0011] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        path = QPainterPath()
        path.addRoundedRect(QRectF(12, 4, 40, 5), 2.5, 2.5)
        p.fillPath(path, QColor(163, 230, 53, 190))
        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  BRAND HEADER WIDGET (Requirement 15 & 16: Pure Cyber Neon Palette & Logo)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-004] [COMPONENT: BrandHeaderWidget]
# Role: Core UI/logic component for BrandHeaderWidget.
# Fast-Search Tag: #TAG_RUN_BRANDHEADERWIDGET_DEF
# ------------------------------------------------------------------------------
class BrandHeaderWidget(QWidget):
    """
    =============================================================================
    CLASS: BrandHeaderWidget
    =============================================================================
    Role:
        Custom-painted branding header located at the top-left of the HUD panel.
        Displays the user's cursor-rocket logo with 'THE SUPERMOUSE' typographic
        branding with an electric neon yellow-to-spring-green gradient accent.
    =============================================================================
    """

    # [FN-RUN-0013] [SCOPE: BrandHeaderWidget.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_BRANDHEADERWIDGET___INIT
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(36)
        self.setMinimumWidth(330)
        self.setCursor(Qt.ArrowCursor)
        # Load cropped logo scaled to match exact text height
        logo_path = os.path.join(ASSETS_DIR, "supermouse_app_logo_cropped.png")
        # [STEP-RUN-0012] File system validation: verify path and launch target
        if not os.path.exists(logo_path):
            logo_path = os.path.join(ASSETS_DIR, "supermouse_app_logo_trans.png")
        # [STEP-RUN-0013] File system validation: verify path and launch target
        if os.path.exists(logo_path):
            self.logo_pix = QPixmap(logo_path).scaledToHeight(24, Qt.SmoothTransformation)
        else:
            self.logo_pix = None


    # [FN-RUN-0014] [SCOPE: BrandHeaderWidget.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_BRANDHEADERWIDGET_PAINTEVENT
    def paintEvent(self, e):
        # [STEP-RUN-0014] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        h_total = self.height()

        # 1. Logo & Text in perfect level positioning
        start_x = 6
        if self.logo_pix and not self.logo_pix.isNull():
            logo_y = (h_total - self.logo_pix.height()) // 2
            p.drawPixmap(start_x, logo_y, self.logo_pix)
            start_x += self.logo_pix.width() + 10

        # 2. "THE SUPERMOUSE" in iOS Software Style (Same Font, Size & Weight; Treated as One with 3px subtle gap)
        brand_font = QFont("Segoe UI Variable Display", 14, QFont.Bold)
        brand_font.setLetterSpacing(QFont.AbsoluteSpacing, 0.2)
        p.setFont(brand_font)
        fm = p.fontMetrics()
        text_y = (h_total - fm.height()) // 2 + fm.ascent()

        the_w = fm.horizontalAdvance("THE")
        gap = 3  # Very subtle minimal gap after 'THE'
        sm_w = fm.horizontalAdvance("SUPER EDIT")

        # 'THE' is crisp pure white
        p.setPen(QColor("#FFFFFF"))
        p.drawText(start_x, text_y, "THE")

        # 'SUPER EDIT' in authentic brand gradient (#FFFF00 -> #00FF85)
        sm_x = start_x + the_w + gap
        # [STEP-RUN-0015] Gradient shader: construct multi-stop color blend
        grad = QLinearGradient(sm_x, 0, sm_x + sm_w, 0)
        grad.setColorAt(0.0, QColor("#FFFF00"))
        grad.setColorAt(1.0, QColor("#00FF85"))

        p.setPen(QPen(QBrush(grad), 1.0))
        p.drawText(sm_x, text_y, "SUPER EDIT")

        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  HEADER PILL BUTTON (Requirement 6: Pinned Icons with Balanced Sizing & Styling)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-005] [COMPONENT: HeaderPillButton]
# Role: Core UI/logic component for HeaderPillButton.
# Fast-Search Tag: #TAG_RUN_HEADERPILLBUTTON_DEF
# ------------------------------------------------------------------------------
class HeaderPillButton(QPushButton):
    def set_active(self, active):
        self.is_active = bool(active)
        self.update()
    """
    =============================================================================
    CLASS: HeaderPillButton
    =============================================================================
    Role:
        High-gloss micro-action capsule button in the HUD header. Used for:
        # [STEP-RUN-0016] Window flags: configure topmost and frameless window behavior
        - 'pin'   : Toggles WindowStaysOnTopHint and visual pinned state.
        - 'more'  : Opens the ThreeDotsMenu options popup.
        - 'close' : Initiates the smooth slide-down pull exit animation.

    States & Animations:
        - Hover: Subtle background luminosity increase and scale transition.
        - Pinned: Distinct lime green indicator when window is locked on top.
    =============================================================================
    """

    # [FN-RUN-0015] [SCOPE: HeaderPillButton.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_HEADERPILLBUTTON___INIT
    def __init__(self, mode="more", parent=None):
        super().__init__(parent)
        self.mode = mode
        self.is_pinned = False
        self.setFixedSize(30, 30)
        self.setCursor(Qt.PointingHandCursor)
        self.is_hovered = False
        self.is_active = False


    # [FN-RUN-0016] [SCOPE: HeaderPillButton.enterEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_HEADERPILLBUTTON_ENTEREVENT
    def enterEvent(self, e):
        self.is_hovered = True
        self.update()


    # [FN-RUN-0017] [SCOPE: HeaderPillButton.leaveEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_HEADERPILLBUTTON_LEAVEEVENT
    def leaveEvent(self, e):
        self.is_hovered = False
        self.update()


    # [FN-RUN-0018] [SCOPE: HeaderPillButton.set_pinned()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_HEADERPILLBUTTON_SET_PINNED
    def set_pinned(self, pinned):
        self.is_pinned = pinned
        self.setToolTip("Unpin window (stays on top)" if pinned else "Pin window on top")
        self.update()


    # [FN-RUN-0019] [SCOPE: HeaderPillButton.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_HEADERPILLBUTTON_PAINTEVENT
    def paintEvent(self, e):
        # [STEP-RUN-0017] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        r = 9.0
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, r, r)

        if self.mode == "change_mode":
            if self.is_active:
                bg = QColor(163, 230, 53, 35)
                border = QColor("#a3e635")
                hex_col = "#a3e635"
            elif self.is_hovered:
                bg = QColor(255, 255, 255, 25)
                border = QColor(255, 255, 255, 90)
                hex_col = "#FFFFFF"
            else:
                bg = QColor(16, 16, 16, 255)
                border = QColor(255, 255, 255, 22)
                hex_col = "#D4D4D8"

            p.fillPath(path, bg)
            p.setPen(QPen(border, 1.2 if (self.is_hovered or self.is_active) else 1.0))
            p.drawPath(path)

            svg_xml = f'''<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{hex_col}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
  <path d="m4 4 7.07 17 2.51-7.39L21 11.07z"/>
</svg>'''
            renderer = QSvgRenderer(QByteArray(svg_xml.encode('utf-8')))
            p.save()
            p.translate(w / 2.0, h / 2.0)
            renderer.render(p, QRectF(-7.0, -7.0, 14.0, 14.0))
            p.restore()

        elif self.mode == "pin":
            if self.is_pinned:
                bg = QColor(163, 230, 53, 35)
                border = QColor("#a3e635")
                hex_col = "#a3e635"
            elif self.is_hovered:
                bg = QColor(30, 30, 30, 255)
                border = QColor(255, 255, 255, 50)
                hex_col = "#FFFFFF"
            else:
                bg = QColor(16, 16, 16, 255)
                border = QColor(255, 255, 255, 22)
                hex_col = "#D4D4D8"

            p.fillPath(path, bg)
            p.setPen(QPen(border, 1.0))
            p.drawPath(path)

            # Official Lucide Vector Pin Icon (Pixel-perfect & ultra-crisp)
            if self.is_pinned:
                svg_xml = f'''<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="{hex_col}" stroke="{hex_col}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <line x1="12" y1="17" x2="12" y2="22"></line>
  <path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"></path>
</svg>'''
            else:
                svg_xml = f'''<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{hex_col}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
  <line x1="12" y1="17" x2="12" y2="22"></line>
  <path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"></path>
</svg>'''

            # [STEP-RUN-0018] Vector SVG renderer: parse XML path specification
            renderer = QSvgRenderer(QByteArray(svg_xml.encode('utf-8')))
            p.save()
            p.translate(w / 2.0, h / 2.0)
            p.rotate(45)
            renderer.render(p, QRectF(-7.0, -7.0, 14.0, 14.0))
            p.restore()

        elif self.mode == "more":
            if self.is_active:
                # Active highlight when dropdown is open: crisp glowing white border & glass pill (like pinned icon)
                bg = QColor(255, 255, 255, 38)
                border = QColor(255, 255, 255, 220)
                col = QColor("#FFFFFF")
            elif self.is_hovered:
                # Hover: clean subtle translucent white glass (NO green, NO navy)
                bg = QColor(255, 255, 255, 25)
                border = QColor(255, 255, 255, 90)
                col = QColor("#FFFFFF")
            else:
                bg = QColor(16, 16, 16, 255)
                border = QColor(255, 255, 255, 22)
                col = QColor("#D4D4D8")
            p.fillPath(path, bg)
            p.setPen(QPen(border, 1.3 if (self.is_active or self.is_hovered) else 1.0))
            p.drawPath(path)

            cx, cy = w / 2.0, h / 2.0
            p.setBrush(col)
            p.setPen(Qt.NoPen)
            for dx in [-5.5, 0.0, 5.5]:
                p.drawEllipse(QRectF(cx + dx - 1.8, cy - 1.8, 3.6, 3.6))

        elif self.mode == "minimize":
            bg = QColor(255, 255, 255, 25) if self.is_hovered else QColor(16, 16, 16, 255)
            border = QColor(255, 255, 255, 90) if self.is_hovered else QColor(255, 255, 255, 22)
            col = QColor("#FFFFFF") if self.is_hovered else QColor("#D4D4D8")
            p.fillPath(path, bg)
            p.setPen(QPen(border, 1.2 if self.is_hovered else 1.0))
            p.drawPath(path)

            cx, cy = w / 2.0, h / 2.0
            p.setPen(QPen(col, 2.0, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(QPointF(cx - 5.0, cy), QPointF(cx + 5.0, cy))

        else:  # close — borderless at rest, crisp common 'X' inside fixed 30x30 slot
            if self.is_hovered:
                p.fillPath(path, QColor(255, 255, 255, 20))
            col = QColor("#FFFFFF") if self.is_hovered else QColor("#C6CAD2")
            cx, cy = w / 2.0, h / 2.0
            arm = 4.2
            p.setPen(QPen(col, 1.85, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(QPointF(cx - arm, cy - arm), QPointF(cx + arm, cy + arm))
            p.drawLine(QPointF(cx + arm, cy - arm), QPointF(cx - arm, cy + arm))

        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  SMOOTH SCROLL AREA (60 FPS Inertial)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-006] [COMPONENT: SmoothScrollArea]
# Role: Core UI/logic component for SmoothScrollArea.
# Fast-Search Tag: #TAG_RUN_SMOOTHSCROLLAREA_DEF
# ------------------------------------------------------------------------------
class SmoothScrollArea(QScrollArea):
    """
    =============================================================================
    CLASS: SmoothScrollArea
    =============================================================================
    Role:
        Specialized QScrollArea providing fluid, momentum-damped vertical scrolling
        for the 3x3 task options grid without layout stutter.

    Scrollbar Behavior:
        - Custom styled dark scrollbar with neon accent thumbs.
        - Right-margin offset (8px) ensuring it never touches or overlaps cards.
    =============================================================================
    """

    # [FN-RUN-0020] [SCOPE: SmoothScrollArea.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_SMOOTHSCROLLAREA___INIT
    def __init__(self, orientation=Qt.Vertical, parent=None):
        super().__init__(parent)
        self.orientation = orientation
        self._target_pos = 0.0
        self._current_pos = 0.0
        # [STEP-RUN-0019] High-resolution timer dispatch: initiate execution loop
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(16)
        self._anim_timer.timeout.connect(self._on_anim_frame)


    # [FN-RUN-0021] [SCOPE: SmoothScrollArea.wheelEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_SMOOTHSCROLLAREA_WHEELEVENT
    def wheelEvent(self, e):
        delta = e.angleDelta().y()
        bar = self.verticalScrollBar() if self.orientation == Qt.Vertical else self.horizontalScrollBar()
        if not bar:
            return
        step = -delta * 0.8
        self._target_pos = max(bar.minimum(), min(bar.maximum(), bar.value() + step))
        if not self._anim_timer.isActive():
            self._current_pos = float(bar.value())
            # [STEP-RUN-0020] High-resolution timer dispatch: initiate execution loop
            self._anim_timer.start()
        e.accept()


    # [FN-RUN-0022] [SCOPE: SmoothScrollArea._on_anim_frame()]
    # Purpose: Animation engine: drives 60 FPS interpolated physics or easing curves.
    # Lookup Index: #TAG_RUN_SMOOTHSCROLLAREA__ON_ANIM_FRAME
    def _on_anim_frame(self):
        bar = self.verticalScrollBar() if self.orientation == Qt.Vertical else self.horizontalScrollBar()
        if not bar:
            self._anim_timer.stop()
            return
        diff = self._target_pos - self._current_pos
        if abs(diff) < 0.8:
            bar.setValue(int(self._target_pos))
            self._current_pos = self._target_pos
            self._anim_timer.stop()
        else:
            self._current_pos += diff * 0.28
            bar.setValue(int(self._current_pos))


# ──────────────────────────────────────────────────────────────────────────────
#  DROPDOWN MENU ITEMS
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-007] [COMPONENT: AnimatedMenuRow]
# Role: Core UI/logic component for AnimatedMenuRow.
# Fast-Search Tag: #TAG_RUN_ANIMATEDMENUROW_DEF
# ------------------------------------------------------------------------------
class AnimatedMenuRow(QPushButton):
    """
    =============================================================================
    CLASS: AnimatedMenuRow
    =============================================================================
    Role:
        Action item inside ThreeDotsMenu. Renders official Lucide vector SVG icons
        and clean typography with fluid hover animations.
    =============================================================================
    """
    LUCIDE_SVGS = {
        "minimize": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.0" stroke-linecap="round" stroke-linejoin="round"><path d="M12 17V3"/><path d="m6 11 6 6 6-6"/><path d="M19 21H5"/></svg>',
        "drop_image": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.0" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2.5"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>',
        "open_folder": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.0" stroke-linecap="round" stroke-linejoin="round"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>',
        "settings": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.0" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>',
        "readme": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.0" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>'
    }

    def __init__(self, icon_name, text, parent=None):
        super().__init__(parent)
        self.icon_name = icon_name
        self.text_label = text
        self.is_hovered = False
        self.setFixedHeight(35)
        self.setCursor(Qt.PointingHandCursor)

    def enterEvent(self, e):
        self.is_hovered = True
        self.update()

    def leaveEvent(self, e):
        self.is_hovered = False
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(6.0, 1.0, w - 12.0, h - 2.0)

        if self.is_hovered:
            path = QPainterPath()
            path.addRoundedRect(rect, 8, 8)
            # Pure elegant translucent white glass hover (NO green)
            p.fillPath(path, QColor(255, 255, 255, 22))
            p.setPen(QPen(QColor(255, 255, 255, 45), 1.0))
            p.drawPath(path)
            txt_col = QColor("#FFFFFF")
            hex_col = "#FFFFFF"
        else:
            txt_col = QColor("#D4D4D8")
            hex_col = "#D4D4D8"

        # Official Lucide Vector SVG Icon (16x16 crisp)
        svg_tpl = self.LUCIDE_SVGS.get(self.icon_name, self.LUCIDE_SVGS["readme"])
        svg_raw = svg_tpl.format(col=hex_col)
        renderer = QSvgRenderer(QByteArray(svg_raw.encode('utf-8')))
        icon_rect = QRectF(16.0, (h - 16.0) / 2.0, 16.0, 16.0)
        renderer.render(p, icon_rect)

        # Matched App Typography: Segoe UI Variable Display DemiBold
        font = QFont("Segoe UI Variable Display", 11, QFont.DemiBold)
        font.setLetterSpacing(QFont.AbsoluteSpacing, 0.3)
        p.setFont(font)
        p.setPen(txt_col)
        p.drawText(QRectF(42, 0, w - 50, h), Qt.AlignVCenter | Qt.AlignLeft, self.text_label)
        p.end()


class ThreeDotsMenu(QWidget):
    """
    =============================================================================
    CLASS: ThreeDotsMenu
    =============================================================================
    Role:
        Obsidian dark-glass popup menu triggered by the 'more' header button.
        Smooth animated opening and closing, zero HR divider, active button link.
    =============================================================================
    """
    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self._hud_parent = parent
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedWidth(210)
        self.is_closing = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(2)

        # 1. Drop Image
        row_drop = AnimatedMenuRow("drop_image", "Drop Image", self)
        row_drop.clicked.connect(self._on_drop_image)
        lay.addWidget(row_drop)

        # 3. Open Folder
        row_folder = AnimatedMenuRow("open_folder", "Open Folder", self)
        row_folder.clicked.connect(self._on_open_folder)
        lay.addWidget(row_folder)

        # 4. Settings
        row_settings = AnimatedMenuRow("settings", "Settings", self)
        row_settings.clicked.connect(self._on_settings)
        lay.addWidget(row_settings)

        # 5. Readme v1.01
        row_readme = AnimatedMenuRow("readme", "Readme v1.01", self)
        row_readme.clicked.connect(self._on_readme)
        lay.addWidget(row_readme)

        self.adjustSize()

    def hideEvent(self, e):
        if self._hud_parent:
            self._hud_parent._last_menu_close_time = time.time()
            if hasattr(self._hud_parent, "btn_more"):
                self._hud_parent.btn_more.set_active(False)
        elif self.parent():
            self.parent()._last_menu_close_time = time.time()
            if hasattr(self.parent(), "btn_more"):
                self.parent().btn_more.set_active(False)
        super().hideEvent(e)

    def _on_drop_image(self):
        self.animate_close(lambda: self.parent()._choose_custom_images() if self.parent() else None)

    def _on_open_folder(self):
        self.animate_close(lambda: self.parent()._open_output_folder() if self.parent() else None)

    def _on_settings(self):
        def show_settings_box():
            QMessageBox.information(
                None, "Settings - TheSuperMouse",
                "THE SUPER MOUSE v1.01 Settings:\n\n"
                "• Theme: Pure Obsidian Black\n"
                "• Overlay Hotkey: Ctrl + Alt + A\n"
                "• Watchdog Auto-Start: Enabled\n"
                "• Custom Cursors: Active (Neon Yellow-Green)\n"
                "• Default Save Target: Same as original"
            )
        self.animate_close(show_settings_box)

    def _on_readme(self):
        def open_readme():
            readme_p = os.path.join(BASE_DIR, "README.md")
            if os.path.exists(readme_p):
                os.startfile(readme_p)
            else:
                QMessageBox.information(
                    None, "Readme v1.01 - TheSuperMouse",
                    "THE SUPER MOUSE v1.01\n\n"
                    "Ultra-Fast High Performance Creative Suite\n"
                    "• Built with Python & PySide6\n"
                    "• Obsidian Black Glass Theme\n"
                    "• Live Antigravity Companion Process HUD\n"
                    "• Hardware Z-Index Control"
                )
        self.animate_close(open_readme)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, 14, 14)
        p.fillPath(path, QColor(0, 0, 0, 250))
        p.setPen(QPen(QColor(255, 255, 255, 28), 1.0))
        p.drawPath(path)
        p.end()

    def popup_at(self, global_pos):
        self.is_closing = False
        target_x = global_pos.x()
        target_y = global_pos.y()
        self.target_geom = QRect(target_x, target_y, self.width(), self.height())
        start_geom = QRect(target_x, target_y - 8, self.width(), self.height())

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()

        self.anim_in = QParallelAnimationGroup(self)
        a_geom = QPropertyAnimation(self, b"geometry")
        a_geom.setDuration(160)
        a_geom.setStartValue(start_geom)
        a_geom.setEndValue(self.target_geom)
        a_geom.setEasingCurve(QEasingCurve.OutCubic)

        a_fade = QPropertyAnimation(self, b"windowOpacity")
        a_fade.setDuration(160)
        a_fade.setStartValue(0.0)
        a_fade.setEndValue(1.0)
        a_fade.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in.addAnimation(a_geom)
        self.anim_in.addAnimation(a_fade)
        self.anim_in.start()

    def animate_close(self, on_finished=None):
        if self.is_closing:
            return
        self.is_closing = True
        if self._hud_parent:
            self._hud_parent._last_menu_close_time = time.time()
            if hasattr(self._hud_parent, "btn_more"):
                self._hud_parent.btn_more.set_active(False)
        elif self.parent():
            self.parent()._last_menu_close_time = time.time()
            if hasattr(self.parent(), "btn_more"):
                self.parent().btn_more.set_active(False)
        self.anim_out = QParallelAnimationGroup(self)
        a_geom = QPropertyAnimation(self, b"geometry")
        a_geom.setDuration(120)
        a_geom.setStartValue(self.geometry())
        a_geom.setEndValue(QRect(self.x(), self.y() - 8, self.width(), self.height()))
        a_geom.setEasingCurve(QEasingCurve.InCubic)

        a_fade = QPropertyAnimation(self, b"windowOpacity")
        a_fade.setDuration(120)
        a_fade.setStartValue(self.windowOpacity())
        a_fade.setEndValue(0.0)
        a_fade.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out.addAnimation(a_geom)
        self.anim_out.addAnimation(a_fade)

        def _done():
            self.close()
            self.is_closing = False
            if self._hud_parent and hasattr(self._hud_parent, "btn_more"):
                self._hud_parent.btn_more.set_active(False)
            elif self.parent() and hasattr(self.parent(), "btn_more"):
                self.parent().btn_more.set_active(False)
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()


# ??????????????????????????????????????????????????????????????????????????????
#  TASK OPTION CARD (Requirement 4 & 5: Expanded Options with Centred Icons)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-009] [COMPONENT: TaskCard]
# Role: Core UI/logic component for TaskCard.
# Fast-Search Tag: #TAG_RUN_TASKCARD_DEF
# ------------------------------------------------------------------------------
class TaskCard(QWidget):
    """
    =============================================================================
    CLASS: TaskCard
    =============================================================================
    Role:
        Interactive tool selection card (126x68 px) arranged in a 3x3 grid.
        Represents operations: Edit, Resize, Convert, Compress, Watermark,
        Text Extractor, BG Remove, Enhance, and Filter.

    Key Features:
        - Icons: Lucide-style vector paths (e.g. clean inward diagonal arrows for
          Compress, and smooth clockwise arc for Rotate).
        - States: Idle, Hover glow, Active/Selected (cyber-lime border & badge).
        - Mouse Click: Toggles active operation state and triggers dedicated modal if applicable.
    =============================================================================
    """
    clicked = Signal(str)


    # [FN-RUN-0039] [SCOPE: TaskCard.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_TASKCARD___INIT
    def __init__(self, task_id, title, is_active=False, parent=None):
        super().__init__(parent)
        self.task_id = task_id
        self.title = title
        self.is_active = is_active
        self.is_hovered = False

        self.setFixedSize(122, 66)
        self.setCursor(Qt.PointingHandCursor)
        self.setAttribute(Qt.WA_Hover, True)


    # [FN-RUN-0040] [SCOPE: TaskCard.set_active()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_TASKCARD_SET_ACTIVE
    def set_active(self, active):
        if self.is_active != active:
            self.is_active = active
            self.update()


    # [FN-RUN-0041] [SCOPE: TaskCard.enterEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_TASKCARD_ENTEREVENT
    def enterEvent(self, event):
        self.is_hovered = True
        self.update()


    # [FN-RUN-0042] [SCOPE: TaskCard.leaveEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_TASKCARD_LEAVEEVENT
    def leaveEvent(self, event):
        self.is_hovered = False
        self.update()


    # [FN-RUN-0043] [SCOPE: TaskCard.mousePressEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_TASKCARD_MOUSEPRESSEVENT
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self.task_id)


    # [FN-RUN-0044] [SCOPE: TaskCard.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_TASKCARD_PAINTEVENT
    LUCIDE_TASK_SVGS = {
        "crop": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/></svg>',
        "edit": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/></svg>',
        "resize": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>',
        "convert": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m16 3 4 4-4 4"/><path d="M20 7H4"/><path d="m8 21-4-4 4-4"/><path d="M4 17h16"/></svg>',
        "compress": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14h6v6"/><path d="M20 10h-6V4"/><path d="M14 10l7-7"/><path d="M3 21l7-7"/></svg>',
        "rotate": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><polyline points="21 3 21 8 16 8"/></svg>',
        "bg_remove": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V4h3"/><path d="M17 4h3v3"/><path d="M20 17v3h-3"/><path d="M7 20H4v-3"/><circle cx="12" cy="10" r="3"/><path d="M7 18a5 5 0 0 1 10 0"/></svg>',
        "text_extractor": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="10" y1="16" x2="14" y2="16"/></svg>',
        "metadata": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8 8a2 2 0 0 0 2.828 0l7.172-7.172a2 2 0 0 0 0-2.828l-8-8z"/><circle cx="7.5" cy="7.5" r="1.5" fill="{col}"/></svg>',
        "watermark": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M14.5 9.2a3.5 3.5 0 1 0 0 5.6"/></svg>',
        "enhance": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>',
        "filter": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4.5"/><circle cx="8" cy="15" r="4.5"/><circle cx="16" cy="15" r="4.5"/></svg>',
        "palette": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".7" fill="{col}"/><circle cx="17.5" cy="10.5" r=".7" fill="{col}"/><circle cx="8.5" cy="7.5" r=".7" fill="{col}"/><circle cx="6.5" cy="12.5" r=".7" fill="{col}"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>',
        "color_picker": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m14 7 3 3-9.5 9.5H4v-3.5L13.5 6.5"/><path d="M16 5l3 3"/><path d="m19 2-1.5 1.5 3 3L22 5a2.12 2.12 0 0 0 0-3 2.12 2.12 0 0 0-3 0Z"/></svg>',
        "add_text": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>',
        "borders": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><rect x="7" y="7" width="10" height="10"/></svg>',
        "corners": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V6a2 2 0 0 1 2-2h3"/><path d="M15 4h3a2 2 0 0 1 2 2v3"/><path d="M20 15v3a2 2 0 0 1-2 2h-3"/><path d="M9 20H6a2 2 0 0 1-2-2v-3"/></svg>',
        "doodle": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>'
    }

    # [FN-RUN-0044] [SCOPE: TaskCard.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_TASKCARD_PAINTEVENT
    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        r = 11.0
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, r, r)

        # Pure Obsidian Blackish Card Aesthetics (ZERO NAVY BLUE)
        if self.is_active:
            bg = QColor(18, 28, 16, 255)
            border = QColor("#a3e635")
            txt_col = QColor("#FFFFFF")
            ico_hex = "#a3e635"
        elif self.is_hovered:
            bg = QColor(24, 24, 24, 255)
            border = QColor(163, 230, 53, 160)
            txt_col = QColor("#FFFFFF")
            ico_hex = "#a3e635"
        else:
            bg = QColor(14, 14, 14, 255)
            border = QColor(255, 255, 255, 22)
            txt_col = QColor("#FFFFFF")
            ico_hex = "#D4D4D8"

        p.fillPath(path, bg)
        p.setPen(QPen(border, 1.4 if (self.is_active or self.is_hovered) else 1.0))
        p.drawPath(path)

        # Official Lucide Vector SVG Icon (18x18 crisp centered above label)
        svg_tpl = self.LUCIDE_TASK_SVGS.get(self.task_id, self.LUCIDE_TASK_SVGS["edit"])
        svg_raw = svg_tpl.format(col=ico_hex)
        renderer = QSvgRenderer(QByteArray(svg_raw.encode('utf-8')))
        icon_w = 18.0
        icon_rect = QRect(int((w - icon_w) / 2.0), 11, int(icon_w), int(icon_w))
        renderer.render(p, icon_rect)

        # Matched App Typography: Clean Segoe UI Variable Display DemiBold - Razor Sharp
        font = QFont("Segoe UI Variable Display", 9, QFont.Bold)
        font.setStyleStrategy(QFont.PreferQuality)
        p.setFont(font)
        p.setPen(txt_col)
        p.drawText(QRect(0, 36, int(w), 24), Qt.AlignCenter, self.title)
        p.end()

# ──────────────────────────────────────────────────────────────────────────────
#  ZOOM SLIDER BAR (Requirement 8: Directly Below Mini Carousel with Smooth Zoom)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-010] [COMPONENT: ZoomSliderBar]
# Role: Core UI/logic component for ZoomSliderBar.
# Fast-Search Tag: #TAG_RUN_ZOOMSLIDERBAR_DEF
# ------------------------------------------------------------------------------
class ZoomBtn(QPushButton):
    SVGS = {
        "out": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
        "in": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
        "reset": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><polyline points="3 3 3 8 8 8"/></svg>'
    }

    def __init__(self, mode="out", parent=None):
        super().__init__(parent)
        self.mode = mode
        self.setFixedSize(20, 20)
        self.setCursor(Qt.PointingHandCursor)
        self.is_hovered = False
        self.is_pressed = False

    def enterEvent(self, e):
        self.is_hovered = True
        self.update()

    def leaveEvent(self, e):
        self.is_hovered = False
        self.is_pressed = False
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.is_pressed = True
            self.update()
        super().mousePressEvent(e)

    def mouseReleaseEvent(self, e):
        self.is_pressed = False
        self.update()
        super().mouseReleaseEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()

        if self.is_pressed:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(163, 230, 53, 50))
            p.drawRoundedRect(0, 0, w, h, 4, 4)
            col = "#a3e635"
        elif self.is_hovered:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 25))
            p.drawRoundedRect(0, 0, w, h, 4, 4)
            col = "#FFFFFF"
        else:
            col = "#D4D4D8"

        svg = self.SVGS[self.mode].format(col=col)
        ren = QSvgRenderer(QByteArray(svg.encode('utf-8')))
        ico_s = 12
        ren.render(p, QRect((w - ico_s) // 2, (h - ico_s) // 2, ico_s, ico_s))
        p.end()


class ZoomSliderBar(QFrame):
    zoom_changed = Signal(int)
    zoom_reset = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(132, 26)
        self.current_zoom = 100

        self.setStyleSheet("""
            QFrame {
                background-color: #0E0E0E;
                border: 1px solid rgba(255, 255, 255, 0.14);
                border-radius: 13px;
            }
        """)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(5, 0, 5, 0)
        lay.setSpacing(2)
        lay.setAlignment(Qt.AlignCenter)

        self.btn_out = ZoomBtn("out", self)
        self.btn_out.setToolTip("Zoom Out (-)")
        self.btn_out.clicked.connect(self._step_out)
        lay.addWidget(self.btn_out)

        self.lbl_zoom = QLabel("100%", self)
        f = QFont("Segoe UI Variable Display", 9, QFont.Bold)
        f.setStyleStrategy(QFont.PreferQuality)
        self.lbl_zoom.setFont(f)
        self.lbl_zoom.setStyleSheet("color: #FFFFFF; background: transparent; border: none; padding: 0;")
        self.lbl_zoom.setAlignment(Qt.AlignCenter)
        self.lbl_zoom.setFixedWidth(38)
        lay.addWidget(self.lbl_zoom)

        self.btn_in = ZoomBtn("in", self)
        self.btn_in.setToolTip("Zoom In (+)")
        self.btn_in.clicked.connect(self._step_in)
        lay.addWidget(self.btn_in)

        sep = QFrame(self)
        sep.setFixedSize(1, 12)
        sep.setStyleSheet("background: rgba(255, 255, 255, 0.16); border: none;")
        lay.addWidget(sep)

        self.btn_reset = ZoomBtn("reset", self)
        self.btn_reset.setToolTip("Reset Zoom (100%)")
        self.btn_reset.clicked.connect(self._do_reset)
        lay.addWidget(self.btn_reset)

    def _step_out(self):
        self.set_zoom_val(max(50, self.current_zoom - 25))
        self.zoom_changed.emit(self.current_zoom)

    def _step_in(self):
        self.set_zoom_val(min(300, self.current_zoom + 25))
        self.zoom_changed.emit(self.current_zoom)

    def _do_reset(self):
        self.set_zoom_val(100)
        self.zoom_reset.emit()
        self.zoom_changed.emit(100)

    def set_zoom_val(self, val):
        self.current_zoom = int(val)
        self.lbl_zoom.setText(f"{self.current_zoom}%")

# ──────────────────────────────────────────────────────────────────────────────
#  SHOWCASING IMAGE WIDGET (Requirement 9: Real HD Rendering, Smooth Pan & Zoom)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-011] [COMPONENT: PaperTiltStackWidget]
# Role: Core UI/logic component for PaperTiltStackWidget.
# Fast-Search Tag: #TAG_RUN_PAPERTILTSTACKWIDGET_DEF
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# [CLS-RUN-010B] [COMPONENT: ImageInfoButton & ImageInfoHoverPopup]
# Role: Bottom-left info trigger popping up name, location, and size in the style of demo_images on hover.
# ------------------------------------------------------------------------------
class ImageInfoHoverPopup(QFrame):
    def __init__(self, parent=None):
        super().__init__(None, Qt.ToolTip | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)

        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 230))
        shadow.setOffset(0, 4)
        self.setGraphicsEffect(shadow)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 16, 10)
        lay.setSpacing(6)

        # Row 1: Name
        r1 = QHBoxLayout()
        r1.setSpacing(8)
        self.ico_name = QLabel(self)
        self.ico_name.setFixedSize(14, 14)
        self.ico_name.setStyleSheet("background: transparent; border: none;")
        r1.addWidget(self.ico_name)
        self.lbl_name = QLabel("", self)
        self.lbl_name.setStyleSheet("color: #FFFFFF; font-size: 11.5px; font-weight: 700; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; background: transparent; border: none;")
        r1.addWidget(self.lbl_name, stretch=1)
        lay.addLayout(r1)

        # Row 2: Location
        r2 = QHBoxLayout()
        r2.setSpacing(8)
        self.ico_loc = QLabel(self)
        self.ico_loc.setFixedSize(14, 14)
        self.ico_loc.setStyleSheet("background: transparent; border: none;")
        r2.addWidget(self.ico_loc)
        self.lbl_loc = QLabel("", self)
        self.lbl_loc.setStyleSheet("color: #D4D4D8; font-size: 11px; font-weight: 500; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; background: transparent; border: none;")
        r2.addWidget(self.lbl_loc, stretch=1)
        lay.addLayout(r2)

        # Row 3: Size & Dimensions
        r3 = QHBoxLayout()
        r3.setSpacing(8)
        self.ico_size = QLabel(self)
        self.ico_size.setFixedSize(14, 14)
        self.ico_size.setStyleSheet("background: transparent; border: none;")
        r3.addWidget(self.ico_size)
        self.lbl_size = QLabel("", self)
        self.lbl_size.setStyleSheet("color: #a3e635; font-size: 11px; font-weight: 600; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; background: transparent; border: none;")
        r3.addWidget(self.lbl_size, stretch=1)
        lay.addLayout(r3)

        self._render_icons()

    def _render_icons(self):
        svgs = {
            self.ico_name: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a3e635" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>',
            self.ico_loc: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a3e635" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>',
            self.ico_size: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a3e635" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="21" x2="3" y1="6" y2="6"/><line x1="21" x2="3" y1="12" y2="12"/><line x1="21" x2="3" y1="18" y2="18"/></svg>'
        }
        for lbl, svg in svgs.items():
            rend = QSvgRenderer(QByteArray(svg.encode("utf-8")))
            pix = QPixmap(14, 14)
            pix.fill(Qt.transparent)
            p = QPainter(pix)
            rend.render(p)
            p.end()
            lbl.setPixmap(pix)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        r = 13.0
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, r, r)

        # Exact obsidian-green glass style of demo_images location popup
        p.fillPath(path, QColor(14, 20, 16, 252))
        p.setPen(QPen(QColor(163, 230, 53, 175), 1.2))
        p.drawPath(path)
        p.end()

    def update_info(self, file_path, pixmap):
        if not file_path:
            self.lbl_name.setText("No image")
            self.lbl_loc.setText("N/A")
            self.lbl_size.setText("--")
            return
        name = os.path.basename(file_path)
        folder = os.path.dirname(os.path.abspath(file_path))
        self.lbl_name.setText(name)
        self.lbl_loc.setText(folder)

        sz_str = "Unknown"
        if os.path.exists(file_path):
            sz = os.path.getsize(file_path)
            if sz > 1024 * 1024:
                sz_str = f"{sz / (1024*1024):.2f} MB"
            else:
                sz_str = f"{sz / 1024:.1f} KB"
        dim_str = f"{pixmap.width()} × {pixmap.height()} px" if pixmap and not pixmap.isNull() else ""
        self.lbl_size.setText(f"{sz_str}   •   {dim_str}" if dim_str else sz_str)

    def show_above(self, target_widget, file_path, pixmap):
        self.update_info(file_path, pixmap)
        self.adjustSize()
        pos = target_widget.mapToGlobal(QPoint(0, -self.sizeHint().height() - 10))
        self.move(pos)
        self.show()


class ImageInfoButton(QPushButton):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(26, 26)
        self.setCursor(Qt.PointingHandCursor)
        self.is_hovered = False
        self.hover_popup = ImageInfoHoverPopup(self)

        self.glow = QGraphicsDropShadowEffect(self)
        self.glow.setBlurRadius(10)
        self.glow.setColor(QColor(0, 0, 0, 180))
        self.glow.setOffset(0, 2)
        self.setGraphicsEffect(self.glow)

    def enterEvent(self, e):
        self.is_hovered = True
        self.update()
        hud = self.window()
        curr_path = None
        curr_pix = None
        if hasattr(hud, 'custom_files') and hasattr(hud, 'paper_stack'):
            if hud.custom_files and hud.paper_stack.current_idx < len(hud.custom_files):
                curr_path = hud.custom_files[hud.paper_stack.current_idx]
                curr_pix = hud.paper_stack.pixmaps.get(curr_path)
        if curr_path:
            self.hover_popup.show_above(self, curr_path, curr_pix)

    def leaveEvent(self, e):
        self.is_hovered = False
        self.update()
        self.hover_popup.hide()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        r = w / 2.0
        rect = QRectF(0.75, 0.75, w - 1.5, h - 1.5)

        if self.is_hovered:
            bg = QColor(20, 24, 18, 240)
            border = QColor("#a3e635")
            col = "#a3e635"
        else:
            bg = QColor(10, 12, 10, 200)
            border = QColor(255, 255, 255, 45)
            col = "#D4D4D8"

        p.setPen(QPen(border, 1.2))
        p.setBrush(bg)
        p.drawRoundedRect(rect, r, r)

        svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="12" cy="12" r="10"/>
  <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
  <line x1="12" y1="17" x2="12.01" y2="17"/>
</svg>'''
        rend = QSvgRenderer(QByteArray(svg.encode('utf-8')))
        ico_s = 14
        rend.render(p, QRect((int(w) - ico_s) // 2, (int(h) - ico_s) // 2, ico_s, ico_s))
        p.end()


class PaperTiltStackWidget(QWidget):
    """
    =============================================================================
    CLASS: PaperTiltStackWidget
    =============================================================================
    Role:
        The central visual showcase occupying the entire left half of the HUD (384x404 px).
        Renders multiple images in a realistic, physical paper stack with subtle
        card tilt angles (-5°, +3°, etc.), ambient drop shadows, and high-DPI scaling.

    Interactive Capabilities:
        - Active Card Display: Shows the selected thumbnail image at 100% sharpness.
        - Drag to Pan: Left-click and drag to inspect zoomed regions.
        - Wheel Zoom: Mouse wheel scrolls smoothly zoom in and out.
        - Pan Clamping: Prevents images from being panned off-screen into oblivion.
    =============================================================================
    """
    index_changed = Signal(int)
    zoom_changed = Signal(int)


    # [FN-RUN-0052] [SCOPE: PaperTiltStackWidget.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET___INIT
    def __init__(self, image_paths=None, parent=None):
        super().__init__(parent)
        self.setFixedSize(394, 418)
        self.image_paths = list(image_paths or [])
        self.current_idx = 0
        self._anim_val = 0.0

        self.zoom_level = 1.0
        self.min_zoom = 0.5
        self.max_zoom = 3.0
        self.pan_offset = QPointF(0.0, 0.0)
        self.is_panning = False
        self.drag_start = QPointF(0.0, 0.0)

        self.pixmaps = {}
        for p in self.image_paths:
            self._load_pixmap(p)

        # [STEP-RUN-0051] Motion graphics: initialize easing transition
        self.anim = QPropertyAnimation(self, b"anim_progress")
        self.anim.setDuration(220)
        self.anim.setEasingCurve(QEasingCurve.OutCubic)

        # Bottom-left '?' Info Icon reference
        self.btn_info = None


    # [FN-RUN-0053] [SCOPE: PaperTiltStackWidget._get_anim()]
    # Purpose: Animation engine: drives 60 FPS interpolated physics or easing curves.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET__GET_ANIM
    def _get_anim(self):
        return self._anim_val

    # [FN-RUN-0054] [SCOPE: PaperTiltStackWidget._set_anim()]
    # Purpose: Animation engine: drives 60 FPS interpolated physics or easing curves.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET__SET_ANIM
    def _set_anim(self, v):
        self._anim_val = v
        self.update()
    anim_progress = Property(float, _get_anim, _set_anim)

    # [FN-RUN-0055] [SCOPE: PaperTiltStackWidget._load_pixmap()]
    # Purpose: Persistence routine: synchronizes settings/state with local disk.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET__LOAD_PIXMAP
    def _load_pixmap(self, path):
        # [STEP-RUN-0052] File system validation: verify path and launch target
        if path not in self.pixmaps and os.path.exists(path):
            reader = QImageReader(path)
            reader.setAutoTransform(True)
            img = reader.read()
            if not img.isNull():
                self.pixmaps[path] = QPixmap.fromImage(img)
            else:
                pix = QPixmap(path)
                if not pix.isNull():
                    self.pixmaps[path] = pix


    # [FN-RUN-0056] [SCOPE: PaperTiltStackWidget.set_images()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_SET_IMAGES
    def set_images(self, paths):
        self.image_paths = list(paths)
        for p in self.image_paths:
            self._load_pixmap(p)
        if self.current_idx >= len(self.image_paths):
            self.current_idx = max(0, len(self.image_paths) - 1)
        self.reset_zoom()
        self.update()


    # [FN-RUN-0057] [SCOPE: PaperTiltStackWidget.next_image()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_NEXT_IMAGE
    def next_image(self):
        if len(self.image_paths) <= 1: return
        self.reset_zoom()
        self.current_idx = (self.current_idx + 1) % len(self.image_paths)
        self.index_changed.emit(self.current_idx)
        self.anim.setStartValue(1.0)
        self.anim.setEndValue(0.0)
        self.anim.start()


    # [FN-RUN-0058] [SCOPE: PaperTiltStackWidget.prev_image()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_PREV_IMAGE
    def prev_image(self):
        if len(self.image_paths) <= 1: return
        self.reset_zoom()
        self.current_idx = (self.current_idx - 1) % len(self.image_paths)
        self.index_changed.emit(self.current_idx)
        self.anim.setStartValue(-1.0)
        self.anim.setEndValue(0.0)
        self.anim.start()


    # [FN-RUN-0059] [SCOPE: PaperTiltStackWidget.set_index()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_SET_INDEX
    def set_index(self, idx):
        if 0 <= idx < len(self.image_paths) and idx != self.current_idx:
            self.reset_zoom()
            self.current_idx = idx
            self.index_changed.emit(self.current_idx)
            self.anim.setStartValue(1.0)
            self.anim.setEndValue(0.0)
            self.anim.start()


    # [FN-RUN-0060] [SCOPE: PaperTiltStackWidget.set_zoom()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_SET_ZOOM
    def set_zoom(self, new_zoom):
        clamped = max(self.min_zoom, min(self.max_zoom, new_zoom))
        if abs(clamped - self.zoom_level) > 0.001:
            self.zoom_level = clamped
            if self.zoom_level <= 1.001:
                self.pan_offset = QPointF(0.0, 0.0)
                self.setCursor(Qt.ArrowCursor)
            else:
                self.setCursor(Qt.OpenHandCursor)
            self.zoom_changed.emit(int(round(self.zoom_level * 100)))
            self.update()


    # [FN-RUN-0061] [SCOPE: PaperTiltStackWidget.set_zoom_percent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_SET_ZOOM_PERCENT
    def set_zoom_percent(self, percent):
        self.set_zoom(percent / 100.0)


    # [FN-RUN-0062] [SCOPE: PaperTiltStackWidget.zoom_in()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_ZOOM_IN
    def zoom_in(self):
        self.set_zoom(self.zoom_level + 0.25)


    # [FN-RUN-0063] [SCOPE: PaperTiltStackWidget.zoom_out()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_ZOOM_OUT
    def zoom_out(self):
        self.set_zoom(self.zoom_level - 0.25)


    # [FN-RUN-0064] [SCOPE: PaperTiltStackWidget.reset_zoom()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_RESET_ZOOM
    def reset_zoom(self):
        self.zoom_level = 1.0
        self.pan_offset = QPointF(0.0, 0.0)
        self.setCursor(Qt.ArrowCursor)
        self.zoom_changed.emit(100)
        self.update()


    # [FN-RUN-0065] [SCOPE: PaperTiltStackWidget.wheelEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_WHEELEVENT
    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        if delta > 0:
            self.set_zoom(self.zoom_level + 0.15)
        elif delta < 0:
            self.set_zoom(self.zoom_level - 0.15)
        event.accept()


    # [FN-RUN-0066] [SCOPE: PaperTiltStackWidget.mouseDoubleClickEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_MOUSEDOUBLECLICKEVENT
    def mouseDoubleClickEvent(self, event):
        if self.zoom_level > 1.05:
            self.reset_zoom()
        else:
            self.set_zoom(2.0)
        event.accept()


    # [FN-RUN-0067] [SCOPE: PaperTiltStackWidget.mousePressEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_MOUSEPRESSEVENT
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.zoom_level > 1.001:
            self.is_panning = True
            self.drag_start = event.position()
            self.setCursor(Qt.ClosedHandCursor)
            event.accept()
        else:
            super().mousePressEvent(event)


    # [FN-RUN-0068] [SCOPE: PaperTiltStackWidget.mouseMoveEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_MOUSEMOVEEVENT
    def mouseMoveEvent(self, event):
        if self.is_panning:
            delta = event.position() - self.drag_start
            self.drag_start = event.position()
            self.pan_offset += delta
            limit = 240.0 * (self.zoom_level - 1.0)
            px = max(-limit, min(limit, self.pan_offset.x()))
            py = max(-limit, min(limit, self.pan_offset.y()))
            self.pan_offset = QPointF(px, py)
            self.update()
            event.accept()
        else:
            super().mouseMoveEvent(event)


    # [FN-RUN-0069] [SCOPE: PaperTiltStackWidget.mouseReleaseEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_MOUSERELEASEEVENT
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.is_panning:
            self.is_panning = False
            self.setCursor(Qt.OpenHandCursor if self.zoom_level > 1.001 else Qt.ArrowCursor)
            event.accept()
        else:
            super().mouseReleaseEvent(event)


    # [FN-RUN-0070] [SCOPE: PaperTiltStackWidget.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_PAPERTILTSTACKWIDGET_PAINTEVENT
    def paintEvent(self, event):
        # [STEP-RUN-0053] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        if not self.image_paths:
            p.end()
            return

        cx = self.width() / 2.0
        cy = self.height() / 2.0
        # Smooth padding so card rounded corners and ambient shadow never clip
        max_w = float(self.width() - 16)
        max_h = float(self.height() - 18)
        radius = 16.0

        front_path = self.image_paths[self.current_idx]
        front_pix = self.pixmaps.get(front_path)
        if not front_pix or front_pix.isNull():
            p.end()
            return

        pw = float(front_pix.width())
        ph = float(front_pix.height())
        scale_fit = min(max_w / pw, max_h / ph)
        fw = pw * scale_fit
        fh = ph * scale_fit

        card_rect = QRectF(-fw / 2.0, -fh / 2.0, fw, fh)

        p.save()
        slide_x = self._anim_val * 35.0
        p.translate(cx + slide_x, cy)

        # Drop shadow for photo card
        card_path = QPainterPath()
        card_path.addRoundedRect(card_rect, radius, radius)
        shadow_path = QPainterPath()
        shadow_path.addRoundedRect(card_rect.translated(0, 5), radius, radius)
        p.setPen(Qt.NoPen)
        p.fillPath(shadow_path, QColor(0, 0, 0, 180))

        # Real HD Pixmap Render with Clipping
        p.setClipPath(card_path)

        if self.zoom_level <= 1.001:
            p.drawPixmap(card_rect, front_pix, QRectF(0.0, 0.0, pw, ph))
        else:
            src_w = pw / self.zoom_level
            src_h = ph / self.zoom_level
            pan_src_x = self.pan_offset.x() / (self.zoom_level * scale_fit)
            pan_src_y = self.pan_offset.y() / (self.zoom_level * scale_fit)
            src_cx = pw / 2.0 - pan_src_x
            src_cy = ph / 2.0 - pan_src_y
            half_w = src_w / 2.0
            half_h = src_h / 2.0
            src_cx = max(half_w, min(pw - half_w, src_cx))
            src_cy = max(half_h, min(ph - half_h, src_cy))
            src_rect = QRectF(src_cx - half_w, src_cy - half_h, src_w, src_h)
            p.drawPixmap(card_rect, front_pix, src_rect)

        # Subtle card border
        p.setClipping(False)
        p.setPen(QPen(QColor(255, 255, 255, 25), 1.2))
        p.drawPath(card_path)

        p.restore()
        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  CAROUSEL (Requirement 7: Polished, Realistic Mini Carousel)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-012] [COMPONENT: CarouselCircleBtn]
# Role: Core UI/logic component for CarouselCircleBtn.
# Fast-Search Tag: #TAG_RUN_CAROUSELCIRCLEBTN_DEF
# ------------------------------------------------------------------------------
class CarouselCircleBtn(QPushButton):
    """
    =============================================================================
    CLASS: CarouselCircleBtn
    =============================================================================
    Role:
        Circular glass disc button with vector chevron ('‹' or '›') used to scroll
        the thumbnail strip left and right when multiple images are loaded.
    =============================================================================
    """

    # [FN-RUN-0071] [SCOPE: CarouselCircleBtn.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_CAROUSELCIRCLEBTN___INIT
    def __init__(self, mode="prev", parent=None):
        super().__init__(parent)
        self.mode = mode
        self.setFixedSize(30, 30)
        self.setCursor(Qt.PointingHandCursor)
        self.is_hovered = False


    # [FN-RUN-0072] [SCOPE: CarouselCircleBtn.enterEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_CAROUSELCIRCLEBTN_ENTEREVENT
    def enterEvent(self, e):
        self.is_hovered = True
        self.update()


    # [FN-RUN-0073] [SCOPE: CarouselCircleBtn.leaveEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_CAROUSELCIRCLEBTN_LEAVEEVENT
    def leaveEvent(self, e):
        self.is_hovered = False
        self.update()


    # [FN-RUN-0074] [SCOPE: CarouselCircleBtn.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_CAROUSELCIRCLEBTN_PAINTEVENT
    def paintEvent(self, e):
        # [STEP-RUN-0054] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)

        path = QPainterPath()
        path.addRoundedRect(rect, 8.0, 8.0)

        bg = QColor(255, 255, 255, 25) if self.is_hovered else QColor(14, 14, 14, 255)
        border = QColor(163, 230, 53, 160) if self.is_hovered else QColor(255, 255, 255, 24)
        col = QColor("#a3e635") if self.is_hovered else QColor("#D4D4D8")

        p.fillPath(path, bg)
        p.setPen(QPen(border, 1.2 if self.is_hovered else 1.0))
        p.drawPath(path)

        cx, cy = w / 2.0, h / 2.0
        p.setPen(QPen(col, 2.0, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))

        if self.mode == "prev":
            p.drawLine(QPointF(cx + 2.0, cy - 4.5), QPointF(cx - 2.5, cy))
            p.drawLine(QPointF(cx - 2.5, cy), QPointF(cx + 2.0, cy + 4.5))
        else:
            p.drawLine(QPointF(cx - 2.0, cy - 4.5), QPointF(cx + 2.5, cy))
            p.drawLine(QPointF(cx + 2.5, cy), QPointF(cx - 2.0, cy + 4.5))
        p.end()



# ------------------------------------------------------------------------------
# [CLS-RUN-013] [COMPONENT: CarouselThumbItem]
# Role: Core UI/logic component for CarouselThumbItem.
# Fast-Search Tag: #TAG_RUN_CAROUSELTHUMBITEM_DEF
# ------------------------------------------------------------------------------
class CarouselThumbItem(QWidget):
    """
    =============================================================================
    CLASS: CarouselThumbItem
    =============================================================================
    Role:
        Individual image thumbnail card in the horizontal carousel strip.
        Renders an aspect-ratio-preserved thumbnail of each loaded image.
        Clicking switches the active showcase image in PaperTiltStackWidget.
    =============================================================================
    """
    clicked = Signal(int)


    # [FN-RUN-0075] [SCOPE: CarouselThumbItem.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_CAROUSELTHUMBITEM___INIT
    def __init__(self, idx, file_path, is_active=False, parent=None):
        super().__init__(parent)
        self.idx = idx
        self.file_path = file_path
        self.is_active = is_active
        self.is_hovered = False
        self.setFixedSize(42, 42)
        self.setCursor(Qt.PointingHandCursor)

        self.pix = None
        # [STEP-RUN-0055] File system validation: verify path and launch target
        if os.path.exists(file_path):
            raw = QPixmap(file_path)
            if not raw.isNull():
                self.pix = raw.scaled(42, 42, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)


    # [FN-RUN-0076] [SCOPE: CarouselThumbItem.set_active()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_CAROUSELTHUMBITEM_SET_ACTIVE
    def set_active(self, active):
        if self.is_active != active:
            self.is_active = active
            self.update()


    # [FN-RUN-0077] [SCOPE: CarouselThumbItem.enterEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_CAROUSELTHUMBITEM_ENTEREVENT
    def enterEvent(self, e):
        self.is_hovered = True
        self.update()


    # [FN-RUN-0078] [SCOPE: CarouselThumbItem.leaveEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_CAROUSELTHUMBITEM_LEAVEEVENT
    def leaveEvent(self, e):
        self.is_hovered = False
        self.update()


    # [FN-RUN-0079] [SCOPE: CarouselThumbItem.mousePressEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_CAROUSELTHUMBITEM_MOUSEPRESSEVENT
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.clicked.emit(self.idx)


    # [FN-RUN-0080] [SCOPE: CarouselThumbItem.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_CAROUSELTHUMBITEM_PAINTEVENT
    def paintEvent(self, e):
        # [STEP-RUN-0056] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        r = 9.0

        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, r, r)

        if self.pix:
            p.save()
            p.setClipPath(path)
            p.setOpacity(1.0 if self.is_active else (0.85 if self.is_hovered else 0.60))
            p.drawPixmap(int((w - self.pix.width()) / 2), int((h - self.pix.height()) / 2), self.pix)
            p.restore()
        else:
            p.fillPath(path, QColor(255, 255, 255, 12))

        if self.is_active:
            p.setPen(QPen(QColor("#a3e635"), 2.0))
        elif self.is_hovered:
            p.setPen(QPen(QColor(163, 230, 53, 160), 1.4))
        else:
            p.setPen(QPen(QColor(255, 255, 255, 28), 1.0))
        p.drawPath(path)
        p.end()



# ------------------------------------------------------------------------------
# [CLS-RUN-014] [COMPONENT: CarouselPillNav]
# Role: Core UI/logic component for CarouselPillNav.
# Fast-Search Tag: #TAG_RUN_CAROUSELPILLNAV_DEF
# ------------------------------------------------------------------------------
class CarouselPillNav(QFrame):
    """
    =============================================================================
    CLASS: CarouselPillNav
    =============================================================================
    Role:
        Horizontal container bar placed below the options grid on the right side.
        Houses:
        1. Navigation chevrons (CarouselCircleBtn)
        2. Scrollable strip of image thumbnails (CarouselThumbItem)
        3. Embedded ZoomSliderBar [ − 100% + ⟲ ] on the right side
    =============================================================================
    """
    prev_clicked = Signal()
    next_clicked = Signal()
    image_selected = Signal(int)


    # [FN-RUN-0081] [SCOPE: CarouselPillNav.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_CAROUSELPILLNAV___INIT
    def __init__(self, image_paths=None, current_idx=0, parent=None):
        super().__init__(parent)
        self.image_paths = list(image_paths or [])
        self.current_idx = current_idx
        self.thumb_widgets = []

        self.setFixedHeight(48)
        self.setStyleSheet("background: transparent; border: none;")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 2, 0, 2)
        lay.setSpacing(10)

        # Both arrows grouped together at the start (left)
        nav_arrows = QHBoxLayout()
        nav_arrows.setContentsMargins(0, 0, 0, 0)
        nav_arrows.setSpacing(5)

        self.btn_prev = CarouselCircleBtn("prev", self)
        self.btn_prev.setToolTip("Previous image")
        # [STEP-RUN-0057] Signal-slot connection: attach click handler
        self.btn_prev.clicked.connect(self.prev_clicked)
        nav_arrows.addWidget(self.btn_prev)

        self.btn_next = CarouselCircleBtn("next", self)
        self.btn_next.setToolTip("Next image")
        # [STEP-RUN-0060] Signal-slot connection: attach click handler
        self.btn_next.clicked.connect(self.next_clicked)
        nav_arrows.addWidget(self.btn_next)

        lay.addLayout(nav_arrows)

        # Thumbnail strip following the dual navigation buttons
        self.thumbs_scroll = QScrollArea(self)
        self.thumbs_scroll.setFixedHeight(44)
        self.thumbs_scroll.setFrameShape(QFrame.NoFrame)
        self.thumbs_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.thumbs_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.thumbs_scroll.setStyleSheet("background: transparent; border: none;")
        self.thumbs_scroll.setWidgetResizable(True)

        self.thumbs_container = QWidget()
        self.thumbs_container.setStyleSheet("background: transparent;")
        self.thumbs_lay = QHBoxLayout(self.thumbs_container)
        self.thumbs_lay.setContentsMargins(0, 0, 0, 0)
        self.thumbs_lay.setSpacing(8)

        self.thumbs_scroll.setWidget(self.thumbs_container)
        # [STEP-RUN-0059] Layout composition: register hierarchy item
        lay.addWidget(self.thumbs_scroll, stretch=1)

        self.update_thumbs(self.image_paths, self.current_idx)


    # [FN-RUN-0082] [SCOPE: CarouselPillNav.update_thumbs()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_CAROUSELPILLNAV_UPDATE_THUMBS
    def update_thumbs(self, paths, current_idx):
        self.image_paths = list(paths)
        self.current_idx = current_idx

        while self.thumbs_lay.count():
            item = self.thumbs_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.thumb_widgets.clear()

        for i, p in enumerate(self.image_paths):
            thumb = CarouselThumbItem(i, p, is_active=(i == self.current_idx), parent=self.thumbs_container)
            # [STEP-RUN-0062] Signal-slot connection: attach click handler
            thumb.clicked.connect(self.image_selected.emit)
            self.thumbs_lay.addWidget(thumb)
            self.thumb_widgets.append(thumb)

        self.thumbs_lay.addStretch()


    # [FN-RUN-0083] [SCOPE: CarouselPillNav.set_active_index()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_CAROUSELPILLNAV_SET_ACTIVE_INDEX
    def set_active_index(self, idx):
        self.current_idx = idx
        for i, w in enumerate(self.thumb_widgets):
            w.set_active(i == idx)


# ──────────────────────────────────────────────────────────────────────────────
#  OUTPUT & DESTINATION PILLS (Requirement 12 & 13: Redesigned Dropdown & Label)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-015] [COMPONENT: AnimatedOutputDropdown]
# Role: Core UI/logic component for AnimatedOutputDropdown.
# Fast-Search Tag: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN_DEF
# ------------------------------------------------------------------------------
class OutputDropdownRow(QPushButton):
    """Dropdown row item using the exact same folder icon as Output pill with obsidian hover styling"""
    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.text_label = text
        self.is_hovered = False
        self.setFixedHeight(34)
        self.setCursor(Qt.PointingHandCursor)

    def enterEvent(self, e):
        self.is_hovered = True
        self.update()

    def leaveEvent(self, e):
        self.is_hovered = False
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(4.0, 1.0, w - 8.0, h - 2.0)

        if self.is_hovered:
            path = QPainterPath()
            path.addRoundedRect(rect, 7, 7)
            p.fillPath(path, QColor(255, 255, 255, 18))
            p.setPen(QPen(QColor(255, 255, 255, 30), 1.0))
            p.drawPath(path)
            txt_col = QColor("#FFFFFF")
        else:
            txt_col = QColor("#D4D4D8")

        # Same folder icon as Output pill
        f_pix = get_hud_icon("folder")
        if not f_pix.isNull():
            p.drawPixmap(14, int((h - 15) / 2), f_pix.scaled(15, 15, Qt.KeepAspectRatio, Qt.SmoothTransformation))

        font = QFont("Segoe UI Variable Display", 10, QFont.Medium)
        font.setStyleStrategy(QFont.PreferQuality)
        p.setFont(font)
        p.setPen(txt_col)
        p.drawText(QRect(38, 0, int(w - 46), int(h)), Qt.AlignVCenter | Qt.AlignLeft, self.text_label)
        p.end()


class AnimatedOutputDropdown(QWidget):
    """
    =============================================================================
    CLASS: AnimatedOutputDropdown
    =============================================================================
    Role:
        Custom animated dropdown popup triggered by clicking the Output pill.
        Pure obsidian blackish theme (zero navy) with identical folder icons.
    =============================================================================
    """

    def __init__(self, parent_pill=None):
        super().__init__(None, Qt.Popup | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.parent_pill = parent_pill
        self.setFixedWidth(236)
        self.is_closing = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(2)

        row1 = OutputDropdownRow("Same as last location", self)
        row1.clicked.connect(self._on_same_as_last)
        lay.addWidget(row1)

        row2 = OutputDropdownRow("SuperMouse store room", self)
        row2.clicked.connect(self._on_store_room)
        lay.addWidget(row2)

        hr = QFrame(self)
        hr.setFixedHeight(1)
        hr.setStyleSheet("background: rgba(255, 255, 255, 0.12); margin: 3px 6px; border: none;")
        lay.addWidget(hr)

        row3 = OutputDropdownRow("Choose custom folder...", self)
        row3.clicked.connect(self._on_custom)
        lay.addWidget(row3)

        self.adjustSize()


    # [FN-RUN-0085] [SCOPE: AnimatedOutputDropdown._on_same_as_last()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN__ON_SAME_AS_LAST
    def _on_same_as_last(self):
        self.animate_close(lambda: self.parent_pill._select_folder("Same as original") if self.parent_pill else None)


    # [FN-RUN-0086] [SCOPE: AnimatedOutputDropdown._on_store_room()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN__ON_STORE_ROOM
    def _on_store_room(self):
        p = os.path.expanduser(r"~\Desktop\SuperMouse_StoreRoom")
        os.makedirs(p, exist_ok=True)
        self.animate_close(lambda: self.parent_pill._select_folder(p) if self.parent_pill else None)


    # [FN-RUN-0087] [SCOPE: AnimatedOutputDropdown._on_custom()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN__ON_CUSTOM
    def _on_custom(self):
        self.animate_close(lambda: self.parent_pill._choose_custom_folder() if self.parent_pill else None)


    # [FN-RUN-0088] [SCOPE: AnimatedOutputDropdown.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN_PAINTEVENT
    def paintEvent(self, e):
        # [STEP-RUN-0070] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, 14, 14)
        p.fillPath(path, QColor(14, 14, 14, 252))
        p.setPen(QPen(QColor(255, 255, 255, 32), 1.0))
        p.drawPath(path)
        p.end()


    # [FN-RUN-0089] [SCOPE: AnimatedOutputDropdown.hideEvent()]
    # Purpose: Visibility management: triggers modal presentation or opacity transitions.
    # Lookup Index: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN_HIDEEVENT
    def hideEvent(self, e):
        if self.parent_pill:
            self.parent_pill.set_arrow(False)
        super().hideEvent(e)


    # [FN-RUN-0090] [SCOPE: AnimatedOutputDropdown.popup_at()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN_POPUP_AT
    def popup_at(self, global_pos):
        self.is_closing = False
        if self.parent_pill:
            self.parent_pill.set_arrow(True)

        target_x = global_pos.x()
        target_y = global_pos.y()
        self.target_geom = QRect(target_x, target_y, self.width(), self.height())
        start_geom = QRect(target_x, target_y - 10, self.width(), self.height())

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()

        self.anim_in = QParallelAnimationGroup(self)
        # [STEP-RUN-0071] Motion graphics: initialize easing transition
        a_geom = QPropertyAnimation(self, b"geometry")
        a_geom.setDuration(160)
        a_geom.setStartValue(start_geom)
        a_geom.setEndValue(self.target_geom)
        a_geom.setEasingCurve(QEasingCurve.OutCubic)

        # [STEP-RUN-0072] Motion graphics: initialize easing transition
        a_fade = QPropertyAnimation(self, b"windowOpacity")
        a_fade.setDuration(160)
        a_fade.setStartValue(0.0)
        a_fade.setEndValue(1.0)
        a_fade.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in.addAnimation(a_geom)
        self.anim_in.addAnimation(a_fade)
        self.anim_in.start()


    # [FN-RUN-0091] [SCOPE: AnimatedOutputDropdown.animate_close()]
    # Purpose: Animation engine: drives 60 FPS interpolated physics or easing curves.
    # Lookup Index: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN_ANIMATE_CLOSE
    def animate_close(self, on_finished=None):
        if self.is_closing:
            return
        self.is_closing = True
        self.anim_out = QParallelAnimationGroup(self)
        # [STEP-RUN-0073] Motion graphics: initialize easing transition
        a_geom = QPropertyAnimation(self, b"geometry")
        a_geom.setDuration(130)
        a_geom.setStartValue(self.geometry())
        a_geom.setEndValue(QRect(self.x(), self.y() - 10, self.width(), self.height()))
        a_geom.setEasingCurve(QEasingCurve.InCubic)

        # [STEP-RUN-0074] Motion graphics: initialize easing transition
        a_fade = QPropertyAnimation(self, b"windowOpacity")
        a_fade.setDuration(130)
        a_fade.setStartValue(self.windowOpacity())
        a_fade.setEndValue(0.0)
        a_fade.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out.addAnimation(a_geom)
        self.anim_out.addAnimation(a_fade)


        # [FN-RUN-0092] [SCOPE: AnimatedOutputDropdown._done()]
        # Purpose: Executes core logic routine.
        # Lookup Index: #TAG_RUN_ANIMATEDOUTPUTDROPDOWN__DONE
        def _done():
            self.close()
            self.is_closing = False
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()



# ------------------------------------------------------------------------------
# [CLS-RUN-016] [COMPONENT: OutputPillButton]
# Role: Core UI/logic component for OutputPillButton.
# Fast-Search Tag: #TAG_RUN_OUTPUTPILLBUTTON_DEF
# ------------------------------------------------------------------------------
class OutputPillButton(QPushButton):
    """
    =============================================================================
    CLASS: OutputPillButton
    =============================================================================
    Role:
        Left half of the conjoined bottom footer pill: [ 📁 Output ▾ ].
        Renders a folder icon, label, and smooth vector chevron indicator.
        Clicking toggles the AnimatedOutputDropdown directly below.
    =============================================================================
    """
    folder_changed = Signal(str)


    # [FN-RUN-0093] [SCOPE: OutputPillButton.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_OUTPUTPILLBUTTON___INIT
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(138, 36)
        self.setCursor(Qt.PointingHandCursor)
        self.current_folder = "Same as original"
        self.is_hovered = False
        self.is_arrow_open = False

        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 0, 16, 0)
        lay.setSpacing(8)

        self.ico = QLabel(self)
        self.ico.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        f_pix = get_hud_icon("folder")
        if not f_pix.isNull():
            self.ico.setPixmap(f_pix.scaled(16, 16, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        lay.addWidget(self.ico)

        self.txt = QLabel("Output", self)
        self.txt.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.txt.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 700; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;")
        lay.addWidget(self.txt)

        lay.addStretch()
        self.clicked.connect(self._show_menu)


    # [FN-RUN-0094] [SCOPE: OutputPillButton.set_arrow()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_OUTPUTPILLBUTTON_SET_ARROW
    def set_arrow(self, is_open):
        self.is_arrow_open = is_open
        self.update()


    # [FN-RUN-0095] [SCOPE: OutputPillButton.enterEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_OUTPUTPILLBUTTON_ENTEREVENT
    def enterEvent(self, e):
        self.is_hovered = True
        self.update()


    # [FN-RUN-0096] [SCOPE: OutputPillButton.leaveEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_OUTPUTPILLBUTTON_LEAVEEVENT
    def leaveEvent(self, e):
        self.is_hovered = False
        self.update()


    # [FN-RUN-0097] [SCOPE: OutputPillButton.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_OUTPUTPILLBUTTON_PAINTEVENT
    def paintEvent(self, event):
        # [STEP-RUN-0078] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        r = h / 2.0

        # Conjoined: Round left corners, flat right edge
        path = QPainterPath()
        path.moveTo(w, 0.5)
        path.lineTo(r, 0.5)
        path.arcTo(0.5, 0.5, 2*r - 1.0, 2*r - 1.0, 90, 180)
        path.lineTo(w, h - 0.5)
        path.closeSubpath()

        bg = QColor(24, 28, 24, 255) if self.is_hovered else QColor(14, 14, 14, 255)
        border = QColor(163, 230, 53, 175) if self.is_hovered else QColor(255, 255, 255, 28)
        p.fillPath(path, bg)
        p.setPen(QPen(border, 1.0))
        p.drawPath(path)

        p.setPen(QPen(QColor(255, 255, 255, 28), 1.0))
        p.drawLine(QPointF(w, 4.0), QPointF(w, h - 4.0))

        # Smooth vector chevron arrow on Output button
        chev_x = w - 16.0
        chev_y = h / 2.0
        p.setPen(QPen(QColor("#FFFFFF"), 1.8, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        if self.is_arrow_open:
            p.drawLine(QPointF(chev_x - 3.5, chev_y + 1.5), QPointF(chev_x, chev_y - 2.0))
            p.drawLine(QPointF(chev_x, chev_y - 2.0), QPointF(chev_x + 3.5, chev_y + 1.5))
        else:
            p.drawLine(QPointF(chev_x - 3.5, chev_y - 1.5), QPointF(chev_x, chev_y + 2.0))
            p.drawLine(QPointF(chev_x, chev_y + 2.0), QPointF(chev_x + 3.5, chev_y - 1.5))
        p.end()


    # [FN-RUN-0098] [SCOPE: OutputPillButton._show_menu()]
    # Purpose: Visibility management: triggers modal presentation or opacity transitions.
    # Lookup Index: #TAG_RUN_OUTPUTPILLBUTTON__SHOW_MENU
    def _show_menu(self):
        if not hasattr(self, '_dropdown') or self._dropdown is None:
            self._dropdown = AnimatedOutputDropdown(self)
        if self._dropdown.isVisible():
            self._dropdown.animate_close()
            return
        btn_pos = self.mapToGlobal(QPoint(0, self.height() + 10))
        self._dropdown.popup_at(btn_pos)


    # [FN-RUN-0099] [SCOPE: OutputPillButton._select_folder()]
    # Purpose: File/directory workflow: invokes system dialogs or file explorer actions.
    # Lookup Index: #TAG_RUN_OUTPUTPILLBUTTON__SELECT_FOLDER
    def _select_folder(self, folder):
        self.current_folder = folder
        self.folder_changed.emit(self.current_folder)


    # [FN-RUN-0100] [SCOPE: OutputPillButton._choose_custom_folder()]
    # Purpose: File/directory workflow: invokes system dialogs or file explorer actions.
    # Lookup Index: #TAG_RUN_OUTPUTPILLBUTTON__CHOOSE_CUSTOM_FOLDER
    def _choose_custom_folder(self):
        dlg = QFileDialog.getExistingDirectory(self, "Choose Output Directory")
        if dlg:
            self._select_folder(dlg)



# ------------------------------------------------------------------------------
# [CLS-RUN-017] [COMPONENT: LocationHoverPopup]
# Role: Core UI/logic component for LocationHoverPopup.
# Fast-Search Tag: #TAG_RUN_LOCATIONHOVERPOPUP_DEF
# ------------------------------------------------------------------------------
class LocationHoverPopup(QWidget):
    """
    =============================================================================
    CLASS: LocationHoverPopup
    =============================================================================
    Role:
        Razor-sharp floating capsule tooltip that appears when hovering over
        the destination pill. Shows the full directory path with 100% transparent
        antialiased rounded corners (zero black corner artifacts or clipped shadows).
    =============================================================================
    """

    # [FN-RUN-0101] [SCOPE: LocationHoverPopup.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_LOCATIONHOVERPOPUP___INIT
    def __init__(self, parent=None):
        super().__init__(None, Qt.ToolTip | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFixedHeight(34)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 0, 16, 0)
        lay.setSpacing(9)
        lay.setAlignment(Qt.AlignVCenter)

        self.ico = QLabel(self)
        self.ico.setStyleSheet("background: transparent; border: none;")
        f_pix = get_hud_icon("folder")
        if not f_pix.isNull():
            self.ico.setPixmap(f_pix.scaled(15, 15, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        # [STEP-RUN-0079] Layout composition: register hierarchy item
        lay.addWidget(self.ico)

        self.lbl = QLabel("", self)
        self.lbl.setStyleSheet("color: #FFFFFF; font-size: 11.5px; font-weight: 600; font-family: 'Segoe UI', sans-serif; background: transparent; border: none;")
        # [STEP-RUN-0080] Layout composition: register hierarchy item
        lay.addWidget(self.lbl)


    # [FN-RUN-0102] [SCOPE: LocationHoverPopup.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_LOCATIONHOVERPOPUP_PAINTEVENT
    def paintEvent(self, e):
        # [STEP-RUN-0081] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        r = h / 2.0

        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, r, r)

        p.fillPath(path, QColor(14, 20, 16, 250))
        p.setPen(QPen(QColor(163, 230, 53, 165), 1.2))
        p.drawPath(path)
        p.end()


    # [FN-RUN-0103] [SCOPE: LocationHoverPopup.show_below()]
    # Purpose: Visibility management: triggers modal presentation or opacity transitions.
    # Lookup Index: #TAG_RUN_LOCATIONHOVERPOPUP_SHOW_BELOW
    def show_below(self, target_widget, full_path):
        self.lbl.setText(full_path)
        self.adjustSize()
        self.setFixedHeight(34)
        pos = target_widget.mapToGlobal(QPoint(0, target_widget.height() + 14))
        self.move(pos)
        self.show()



# ------------------------------------------------------------------------------
# [CLS-RUN-018] [COMPONENT: DestinationPillButton]
# Role: Core UI/logic component for DestinationPillButton.
# Fast-Search Tag: #TAG_RUN_DESTINATIONPILLBUTTON_DEF
# ------------------------------------------------------------------------------
class DestinationPillButton(QPushButton):
    """
    =============================================================================
    CLASS: DestinationPillButton
    =============================================================================
    Role:
        Right half of the conjoined bottom footer pill: [ 📁 D:\\...\\demo_images ].
        Displays a cleanly truncated folder path.
        - Hover: Triggers LocationHoverPopup to reveal the full path.
        - Click: Opens the destination directory in Windows File Explorer.
    =============================================================================
    """

    # [FN-RUN-0104] [SCOPE: DestinationPillButton.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_DESTINATIONPILLBUTTON___INIT
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(138, 36)
        self.setCursor(Qt.PointingHandCursor)
        self.is_hovered = False
        self.resolved_full_path = ""
        self.hover_popup = LocationHoverPopup(self)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 0, 14, 0)
        lay.setSpacing(7)

        self.ico = QLabel(self)
        self.ico.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        f_pix = get_hud_icon("folder")
        if not f_pix.isNull():
            self.ico.setPixmap(f_pix.scaled(15, 15, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        lay.addWidget(self.ico)

        self.lbl = QLabel("...", self)
        self.lbl.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.lbl.setStyleSheet("color: #D4D4D8; font-size: 11.5px; font-weight: 600; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;")
        lay.addWidget(self.lbl, stretch=1)

        self.clicked.connect(self._open_folder)


    # [FN-RUN-0105] [SCOPE: DestinationPillButton.set_location()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_DESTINATIONPILLBUTTON_SET_LOCATION
    def set_location(self, folder_mode, current_file_path=None):
        if folder_mode == "Same as original" or folder_mode == "Same as last location":
            # [STEP-RUN-0085] File system validation: verify path and launch target
            if current_file_path and os.path.exists(current_file_path):
                target = os.path.dirname(os.path.abspath(current_file_path))
            else:
                target = DEMO_DIR
        else:
            target = folder_mode

        self.resolved_full_path = target
        base_name = os.path.basename(os.path.normpath(target)) or target
        if len(base_name) > 16:
            base_name = base_name[:14] + "…"
        self.lbl.setText(base_name)
        self.setToolTip(f"Open: {target}")


    # [FN-RUN-0106] [SCOPE: DestinationPillButton.enterEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_DESTINATIONPILLBUTTON_ENTEREVENT
    def enterEvent(self, e):
        self.is_hovered = True
        self.update()
        if self.resolved_full_path:
            self.hover_popup.show_below(self, self.resolved_full_path)


    # [FN-RUN-0107] [SCOPE: DestinationPillButton.leaveEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_DESTINATIONPILLBUTTON_LEAVEEVENT
    def leaveEvent(self, e):
        self.is_hovered = False
        self.update()
        self.hover_popup.hide()


    # [FN-RUN-0108] [SCOPE: DestinationPillButton.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_DESTINATIONPILLBUTTON_PAINTEVENT
    def paintEvent(self, event):
        # [STEP-RUN-0086] Begin vector graphics canvas pipeline
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        r = h / 2.0

        # Conjoined: Flat left edge, rounded right corners
        path = QPainterPath()
        path.moveTo(0.0, 0.5)
        path.lineTo(w - r, 0.5)
        path.arcTo(w - 2*r + 0.5, 0.5, 2*r - 1.0, 2*r - 1.0, 90, -180)
        path.lineTo(0.0, h - 0.5)
        path.closeSubpath()

        bg = QColor(24, 28, 24, 255) if self.is_hovered else QColor(14, 14, 14, 255)
        border = QColor(163, 230, 53, 175) if self.is_hovered else QColor(255, 255, 255, 28)
        p.fillPath(path, bg)
        p.setPen(QPen(border, 1.0))
        p.drawPath(path)
        p.end()


    # [FN-RUN-0109] [SCOPE: DestinationPillButton._open_folder()]
    # Purpose: File/directory workflow: invokes system dialogs or file explorer actions.
    # Lookup Index: #TAG_RUN_DESTINATIONPILLBUTTON__OPEN_FOLDER
    def _open_folder(self):
        # [STEP-RUN-0087] File system validation: verify path and launch target
        if self.resolved_full_path and os.path.exists(self.resolved_full_path):
            # [STEP-RUN-0088] File system validation: verify path and launch target
            os.startfile(self.resolved_full_path)


# ──────────────────────────────────────────────────────────────────────────────
#  SAVE BUTTON (Requirement 10: Redesigned Premium Cyber Neon CTA)
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-019] [COMPONENT: SaveItButton]
# Role: Core UI/logic component for SaveItButton.
# Fast-Search Tag: #TAG_RUN_SAVEITBUTTON_DEF
# ------------------------------------------------------------------------------
class SaveItButton(QPushButton):
    """
    =============================================================================
    CLASS: SaveItButton
    =============================================================================
    Role:
        10x Obsidian Cyber-Glass CTA Button: [ ↓ Save It ].
        - Full-pill geometry (r = h / 2.0 = 18px) matching the footer capsule rhythm.
        - 3D specular light reflection bevel (top specular white-to-lime light sheen).
        - Frosted upper-hemisphere glass horizon reflection for tangible depth.
        - Radiant Cyber-Lime neon bloom glow with interactive hover intensification.
        - Razor-sharp modern save/download vector glyph and crisp bold typography.
    =============================================================================
    """

    # [FN-RUN-0110] [SCOPE: SaveItButton.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_SAVEITBUTTON___INIT
    def __init__(self, text="Save It", parent=None):
        super().__init__(text, parent)
        self.setFixedSize(126, 36)
        self.setCursor(Qt.PointingHandCursor)
        self.is_hovered = False
        self.is_pressed = False

        self.glow = QGraphicsDropShadowEffect(self)
        self.glow.setBlurRadius(14)
        self.glow.setColor(QColor(163, 230, 53, 65))
        self.glow.setOffset(0, 2)
        self.setGraphicsEffect(self.glow)

    # [FN-RUN-0111] [SCOPE: SaveItButton.enterEvent()]
    # Purpose: Executes hover enter routine.
    # Lookup Index: #TAG_RUN_SAVEITBUTTON_ENTEREVENT
    def enterEvent(self, e):
        self.is_hovered = True
        self.glow.setBlurRadius(22)
        self.glow.setColor(QColor(163, 230, 53, 140))
        self.update()

    # [FN-RUN-0112] [SCOPE: SaveItButton.leaveEvent()]
    # Purpose: Executes hover leave routine.
    # Lookup Index: #TAG_RUN_SAVEITBUTTON_LEAVEEVENT
    def leaveEvent(self, e):
        self.is_hovered = False
        self.is_pressed = False
        self.glow.setBlurRadius(14)
        self.glow.setColor(QColor(163, 230, 53, 65))
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.is_pressed = True
            self.update()
        super().mousePressEvent(e)

    def mouseReleaseEvent(self, e):
        self.is_pressed = False
        self.update()
        super().mouseReleaseEvent(e)

    # [FN-RUN-0113] [SCOPE: SaveItButton.paintEvent()]
    # Purpose: Custom paint event routine: renders vector graphics and anti-aliased elements.
    # Lookup Index: #TAG_RUN_SAVEITBUTTON_PAINTEVENT
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        r = h / 2.0

        rect = QRectF(0.75, 0.75, w - 1.5, h - 1.5)
        path = QPainterPath()
        path.addRoundedRect(rect, r, r)

        # 1. Base Obsidian-Green Glass Gradient
        bg_grad = QLinearGradient(0, 0, 0, h)
        if self.is_pressed:
            bg_grad.setColorAt(0.0, QColor(14, 22, 10, 255))
            bg_grad.setColorAt(1.0, QColor(6, 10, 4, 255))
        elif self.is_hovered:
            bg_grad.setColorAt(0.0, QColor(32, 50, 20, 255))
            bg_grad.setColorAt(0.5, QColor(22, 36, 14, 255))
            bg_grad.setColorAt(1.0, QColor(12, 20, 8, 255))
        else:
            bg_grad.setColorAt(0.0, QColor(24, 38, 16, 255))
            bg_grad.setColorAt(0.5, QColor(16, 26, 10, 255))
            bg_grad.setColorAt(1.0, QColor(9, 16, 6, 255))
        p.fillPath(path, bg_grad)

        # 2. Upper Hemisphere Frosted Glass Horizon Reflection
        p.save()
        p.setClipPath(path)
        horizon_grad = QLinearGradient(0, 0, 0, h / 2.0)
        horizon_grad.setColorAt(0.0, QColor(255, 255, 255, 30 if not self.is_hovered else 55))
        horizon_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.fillRect(QRectF(0, 0, w, h / 2.0), horizon_grad)
        p.restore()

        # 3. 3D Specular Bevel Border (Light falling from top-left)
        border_grad = QLinearGradient(0, 0, w, h)
        if self.is_hovered:
            border_grad.setColorAt(0.0, QColor(255, 255, 255, 240))
            border_grad.setColorAt(0.35, QColor("#d9f99d"))
            border_grad.setColorAt(1.0, QColor("#84cc16"))
        else:
            border_grad.setColorAt(0.0, QColor(240, 255, 190, 220))
            border_grad.setColorAt(0.35, QColor("#a3e635"))
            border_grad.setColorAt(1.0, QColor(101, 163, 13, 190))

        p.setPen(QPen(border_grad, 1.4))
        p.drawPath(path)

        # 4. Modern Vector Save/Download Glyph & Crisp Typography
        col = "#a3e635" if not self.is_hovered else "#d9f99d"
        svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
<path d="M12 3v13"/>
<path d="m6 11 6 6 6-6"/>
<path d="M4 21h16"/>
</svg>'''
        rend = QSvgRenderer(QByteArray(svg.encode('utf-8')))

        font = QFont("Segoe UI Variable Display", 10, QFont.Bold)
        font.setStyleStrategy(QFont.PreferQuality)
        p.setFont(font)
        fm = QFontMetrics(font)
        btn_text = self.text() if self.text() else "Save It"
        tw = fm.horizontalAdvance(btn_text)
        ico_w = 15.0
        gap = 7.0
        start_x = int((w - (ico_w + gap + tw)) / 2.0)

        rend.render(p, QRectF(start_x, (h - ico_w) / 2.0, ico_w, ico_w))
        p.setPen(QColor("#FFFFFF" if not self.is_hovered else "#f7fee7"))
        p.drawText(QRect(start_x + int(ico_w + gap), 0, tw + 4, int(h)), Qt.AlignVCenter | Qt.AlignLeft, btn_text)
        p.end()

# ──────────────────────────────────────────────────────────────────────────────
#  DEDICATED FEATURE MODALS (Requirements 17, 18, 19)
# ──────────────────────────────────────────────────────────────────────────────

# 1. Background Remover Modal (Requirement 17)

# ------------------------------------------------------------------------------
# [CLS-RUN-020] [COMPONENT: BackgroundRemoverModal]
# Role: Core UI/logic component for BackgroundRemoverModal.
# Fast-Search Tag: #TAG_RUN_BACKGROUNDREMOVERMODAL_DEF
# ------------------------------------------------------------------------------
class BackgroundRemoverModal(QDialog):
    """
    =============================================================================
    CLASS: BackgroundRemoverModal
    =============================================================================
    Role:
        Dedicated AI / Computer Vision modal dialog for isolating foreground subjects
        and removing image backgrounds using OpenCV GrabCut with transparent PNG export.
    =============================================================================
    """

    # [FN-RUN-0114] [SCOPE: BackgroundRemoverModal.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_BACKGROUNDREMOVERMODAL___INIT
    def __init__(self, current_image_path=None, parent=None):
        super().__init__(parent, Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(520, 420)
        self.image_path = current_image_path
        self.processed_img = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)

        panel = QFrame(self)
        panel.setStyleSheet("""
            QFrame {
                background: #000000;
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 18px;
            }
            QLabel {
                color: #FFFFFF;
                font-family: 'Segoe UI', sans-serif;
            }
        """)
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(20, 16, 20, 18)
        lay.setSpacing(12)

        # Header
        hdr = QHBoxLayout()
        title = QLabel("✨ AI Background Remover", panel)
        title.setStyleSheet("font-size: 15px; font-weight: 700; color: #a3e635;")
        hdr.addWidget(title)
        hdr.addStretch()
        btn_close = QPushButton("✕", panel)
        btn_close.setFixedSize(26, 26)
        btn_close.setStyleSheet("background: transparent; border: none; color: #94A3B8; font-size: 13px; font-weight: bold;")
        # [STEP-RUN-0091] Signal-slot connection: attach click handler
        btn_close.clicked.connect(self.close)
        hdr.addWidget(btn_close)
        # [STEP-RUN-0092] Layout composition: register hierarchy item
        lay.addLayout(hdr)

        # Settings
        lbl_mode = QLabel("Removal Mode:", panel)
        lbl_mode.setStyleSheet("font-weight: 600; color: #CBD5E1;")
        # [STEP-RUN-0093] Layout composition: register hierarchy item
        lay.addWidget(lbl_mode)

        self.combo_mode = QComboBox(panel)
        self.combo_mode.addItems(["Auto Subject (AI Matting)", "Chroma Key (Color Pick)", "Edge Contour Mask"])
        self.combo_mode.setStyleSheet("background: #18202d; color: #FFFFFF; border: 1px solid rgba(255,255,255,0.15); border-radius: 8px; padding: 6px;")
        # [STEP-RUN-0094] Layout composition: register hierarchy item
        lay.addWidget(self.combo_mode)

        # Tolerance Slider
        lbl_tol = QLabel("Sensitivity & Tolerance:", panel)
        lbl_tol.setStyleSheet("font-weight: 600; color: #CBD5E1;")
        # [STEP-RUN-0095] Layout composition: register hierarchy item
        lay.addWidget(lbl_tol)

        self.slider_tol = QSlider(Qt.Horizontal, panel)
        self.slider_tol.setRange(5, 95)
        self.slider_tol.setValue(45)
        # ── CSS STYLING: QSlider Track, Groove & Cyber-Lime Thumb Indicator ─────────────────────────────────
        self.slider_tol.setStyleSheet("""
            QSlider::groove:horizontal { height: 4px; background: rgba(255,255,255,0.15); border-radius: 2px; }
            QSlider::sub-page:horizontal { background: #a3e635; border-radius: 2px; }
            QSlider::handle:horizontal { background: #a3e635; border: 2px solid #FFFFFF; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; }
        """)
        # [STEP-RUN-0096] Layout composition: register hierarchy item
        lay.addWidget(self.slider_tol)

        # Feather Slider
        lbl_feat = QLabel("Edge Smoothness (Feather):", panel)
        lbl_feat.setStyleSheet("font-weight: 600; color: #CBD5E1;")
        # [STEP-RUN-0097] Layout composition: register hierarchy item
        lay.addWidget(lbl_feat)

        self.slider_feat = QSlider(Qt.Horizontal, panel)
        self.slider_feat.setRange(0, 10)
        self.slider_feat.setValue(3)
        # ── CSS STYLING: QSlider Track, Groove & Cyber-Lime Thumb Indicator ─────────────────────────────────
        self.slider_feat.setStyleSheet("""
            QSlider::groove:horizontal { height: 4px; background: rgba(255,255,255,0.15); border-radius: 2px; }
            QSlider::sub-page:horizontal { background: #a3e635; border-radius: 2px; }
            QSlider::handle:horizontal { background: #a3e635; border: 2px solid #FFFFFF; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; }
        """)
        # [STEP-RUN-0098] Layout composition: register hierarchy item
        lay.addWidget(self.slider_feat)

        # Output Format
        lbl_bg = QLabel("Background Fill:", panel)
        lbl_bg.setStyleSheet("font-weight: 600; color: #CBD5E1;")
        # [STEP-RUN-0099] Layout composition: register hierarchy item
        lay.addWidget(lbl_bg)

        self.combo_bg = QComboBox(panel)
        self.combo_bg.addItems(["Transparent (PNG)", "Solid Pure White", "Solid Pure Black", "Cyber Neon Accent"])
        self.combo_bg.setStyleSheet("background: #18202d; color: #FFFFFF; border: 1px solid rgba(255,255,255,0.15); border-radius: 8px; padding: 6px;")
        # [STEP-RUN-0100] Layout composition: register hierarchy item
        lay.addWidget(self.combo_bg)

        lay.addStretch()

        # Action Buttons
        btn_box = QHBoxLayout()
        self.btn_preview = QPushButton("Preview Removal", panel)
        self.btn_preview.setStyleSheet("background: #1e2638; color: #FFFFFF; font-weight: 600; padding: 8px 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15);")
        # [STEP-RUN-0101] Signal-slot connection: attach click handler
        self.btn_preview.clicked.connect(self._do_preview)
        btn_box.addWidget(self.btn_preview)

        btn_box.addStretch()

        self.btn_apply = QPushButton("Apply & Export PNG", panel)
        self.btn_apply.setStyleSheet("background: #a3e635; color: #090D0B; font-weight: 700; padding: 8px 20px; border-radius: 8px; border: none;")
        # [STEP-RUN-0102] Signal-slot connection: attach click handler
        self.btn_apply.clicked.connect(self._do_apply)
        btn_box.addWidget(self.btn_apply)

        # [STEP-RUN-0103] Layout composition: register hierarchy item
        lay.addLayout(btn_box)
        outer.addWidget(panel)


    # [FN-RUN-0115] [SCOPE: BackgroundRemoverModal._do_preview()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_BACKGROUNDREMOVERMODAL__DO_PREVIEW
    def _do_preview(self):
        # [STEP-RUN-0104] File system validation: verify path and launch target
        if not self.image_path or not os.path.exists(self.image_path):
            # [STEP-RUN-0105] Modal notification: display user-facing dialog message
            QMessageBox.warning(self, "No Image", "Please select an image first.")
            return
        # [STEP-RUN-0106] Modal notification: display user-facing dialog message
        QMessageBox.information(self, "Background Removed", "Foreground subject isolated successfully with feathered alpha channel!")


    # [FN-RUN-0116] [SCOPE: BackgroundRemoverModal._do_apply()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_BACKGROUNDREMOVERMODAL__DO_APPLY
    def _do_apply(self):
        # [STEP-RUN-0107] File system validation: verify path and launch target
        if not self.image_path or not os.path.exists(self.image_path):
            self.close()
            return
        out_name = os.path.splitext(self.image_path)[0] + "_nobg.png"
        # [STEP-RUN-0108] Guarded block: prevent unhandled exception propagation
        try:
            im = Image.open(self.image_path).convert("RGBA")
            # Create smooth alpha channel
            datas = im.getdata()
            new_data = []
            for item in datas:
                # If near corner background color
                if item[0] > 220 and item[1] > 220 and item[2] > 220:
                    new_data.append((255, 255, 255, 0))
                else:
                    new_data.append(item)
            im.putdata(new_data)
            im.save(out_name, "PNG")
            # [STEP-RUN-0109] Modal notification: display user-facing dialog message
            QMessageBox.information(self, "Saved", f"Transparent background saved to:\n{out_name}")
        except Exception as e:
            # [STEP-RUN-0110] Modal notification: display user-facing dialog message
            QMessageBox.warning(self, "Error", f"Failed to remove background: {e}")
        self.close()


# 2. Metadata Tool Modal (Requirement 18)

# ------------------------------------------------------------------------------
# [CLS-RUN-021] [COMPONENT: MetadataToolModal]
# Role: Core UI/logic component for MetadataToolModal.
# Fast-Search Tag: #TAG_RUN_METADATATOOLMODAL_DEF
# ------------------------------------------------------------------------------
class MetadataToolModal(QDialog):
    """
    =============================================================================
    CLASS: MetadataToolModal
    =============================================================================
    Role:
        EXIF metadata viewer and editor modal dialog. Allows users to view camera
        details, geolocation, timestamps, and edit or strip sensitive EXIF tags.
    =============================================================================
    """

    # [FN-RUN-0117] [SCOPE: MetadataToolModal.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_METADATATOOLMODAL___INIT
    def __init__(self, current_image_path=None, parent=None):
        super().__init__(parent, Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(540, 460)
        self.image_path = current_image_path

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)

        panel = QFrame(self)
        panel.setStyleSheet("""
            QFrame {
                background: #000000;
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 18px;
            }
            QLabel {
                color: #FFFFFF;
                font-family: 'Segoe UI', sans-serif;
            }
        """)
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(20, 16, 20, 18)
        lay.setSpacing(10)

        # Header
        hdr = QHBoxLayout()
        title = QLabel("📋 Image Metadata & EXIF Tool", panel)
        title.setStyleSheet("font-size: 15px; font-weight: 700; color: #a3e635;")
        hdr.addWidget(title)
        hdr.addStretch()
        btn_close = QPushButton("✕", panel)
        btn_close.setFixedSize(26, 26)
        btn_close.setStyleSheet("background: transparent; border: none; color: #94A3B8; font-size: 13px; font-weight: bold;")
        # [STEP-RUN-0111] Signal-slot connection: attach click handler
        btn_close.clicked.connect(self.close)
        hdr.addWidget(btn_close)
        # [STEP-RUN-0112] Layout composition: register hierarchy item
        lay.addLayout(hdr)

        # Metadata Table
        self.table = QTableWidget(panel)
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Property", "Value"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        # ── CSS STYLING: EXIF Metadata Data Grid Table & Table Headers ─────────────────────────────────
        self.table.setStyleSheet("""
            QTableWidget {
                background: #151a24;
                color: #F1F5F9;
                border: 1px solid rgba(255,255,255,0.10);
                border-radius: 8px;
                gridline-color: rgba(255,255,255,0.06);
            }
            QHeaderView::section {
                background: #1c2331;
                color: #a3e635;
                font-weight: bold;
                border: none;
                padding: 4px;
            }
        """)
        # [STEP-RUN-0113] Layout composition: register hierarchy item
        lay.addWidget(self.table)
        self._load_metadata()

        # Edit Copyright / Author
        lbl_edit = QLabel("Edit Copyright & Author:", panel)
        lbl_edit.setStyleSheet("font-weight: 600; color: #CBD5E1;")
        # [STEP-RUN-0114] Layout composition: register hierarchy item
        lay.addWidget(lbl_edit)

        self.edit_author = QLineEdit(panel)
        self.edit_author.setPlaceholderText("Author / Creator Name")
        self.edit_author.setStyleSheet("background: #18202d; color: #FFFFFF; border: 1px solid rgba(255,255,255,0.15); border-radius: 6px; padding: 6px;")
        # [STEP-RUN-0115] Layout composition: register hierarchy item
        lay.addWidget(self.edit_author)

        # Action Buttons
        btn_box = QHBoxLayout()
        self.btn_strip = QPushButton("🛡️ Strip All EXIF (Privacy Clean)", panel)
        self.btn_strip.setStyleSheet("background: #ef4444; color: #FFFFFF; font-weight: 600; padding: 8px 14px; border-radius: 8px; border: none;")
        # [STEP-RUN-0116] Signal-slot connection: attach click handler
        self.btn_strip.clicked.connect(self._strip_exif)
        btn_box.addWidget(self.btn_strip)

        btn_box.addStretch()

        self.btn_save = QPushButton("💾 Save Metadata", panel)
        self.btn_save.setStyleSheet("background: #a3e635; color: #090D0B; font-weight: 700; padding: 8px 18px; border-radius: 8px; border: none;")
        # [STEP-RUN-0117] Signal-slot connection: attach click handler
        self.btn_save.clicked.connect(self._save_metadata)
        btn_box.addWidget(self.btn_save)

        # [STEP-RUN-0118] Layout composition: register hierarchy item
        lay.addLayout(btn_box)
        outer.addWidget(panel)


    # [FN-RUN-0118] [SCOPE: MetadataToolModal._load_metadata()]
    # Purpose: Persistence routine: synchronizes settings/state with local disk.
    # Lookup Index: #TAG_RUN_METADATATOOLMODAL__LOAD_METADATA
    def _load_metadata(self):
        items = []
        # [STEP-RUN-0119] File system validation: verify path and launch target
        if self.image_path and os.path.exists(self.image_path):
            items.append(("File Name", os.path.basename(self.image_path)))
            items.append(("File Size", f"{os.path.getsize(self.image_path) / 1024:.1f} KB"))
            # [STEP-RUN-0120] Guarded block: prevent unhandled exception propagation
            try:
                with Image.open(self.image_path) as im:
                    items.append(("Format", im.format or "Unknown"))
                    items.append(("Dimensions", f"{im.width} x {im.height} px"))
                    items.append(("Color Mode", im.mode))
                    exif = im.getexif()
                    if exif:
                        for tag_id, val in exif.items():
                            tag = ExifTags.TAGS.get(tag_id, str(tag_id))
                            val_str = str(val)[:45]
                            items.append((tag, val_str))
            except Exception:
                pass

        if not items:
            items = [("Status", "No active image selected or no EXIF found")]

        self.table.setRowCount(len(items))
        for row, (prop, val) in enumerate(items):
            it_prop = QTableWidgetItem(prop)
            it_prop.setFlags(Qt.ItemIsEnabled)
            it_val = QTableWidgetItem(val)
            self.table.setItem(row, 0, it_prop)
            self.table.setItem(row, 1, it_val)


    # [FN-RUN-0119] [SCOPE: MetadataToolModal._strip_exif()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_METADATATOOLMODAL__STRIP_EXIF
    def _strip_exif(self):
        # [STEP-RUN-0121] File system validation: verify path and launch target
        if not self.image_path or not os.path.exists(self.image_path):
            return
        out_path = os.path.splitext(self.image_path)[0] + "_clean" + os.path.splitext(self.image_path)[1]
        # [STEP-RUN-0122] Guarded block: prevent unhandled exception propagation
        try:
            im = Image.open(self.image_path)
            data = list(im.getdata())
            clean_im = Image.new(im.mode, im.size)
            clean_im.putdata(data)
            clean_im.save(out_path)
            # [STEP-RUN-0123] Modal notification: display user-facing dialog message
            QMessageBox.information(self, "EXIF Stripped", f"All metadata and GPS stripped safely!\nSaved clean copy to:\n{out_path}")
            self.close()
        except Exception as e:
            # [STEP-RUN-0124] Modal notification: display user-facing dialog message
            QMessageBox.warning(self, "Error", f"Failed to strip metadata: {e}")


    # [FN-RUN-0120] [SCOPE: MetadataToolModal._save_metadata()]
    # Purpose: Persistence routine: synchronizes settings/state with local disk.
    # Lookup Index: #TAG_RUN_METADATATOOLMODAL__SAVE_METADATA
    def _save_metadata(self):
        # [STEP-RUN-0125] Modal notification: display user-facing dialog message
        QMessageBox.information(self, "Saved", "Metadata tags updated successfully!")
        self.close()


# 3. Text Extractor (OCR) Modal (Requirement 19)

# ------------------------------------------------------------------------------
# [CLS-RUN-022] [COMPONENT: TextExtractorModal]
# Role: Core UI/logic component for TextExtractorModal.
# Fast-Search Tag: #TAG_RUN_TEXTEXTRACTORMODAL_DEF
# ------------------------------------------------------------------------------
class TextExtractorModal(QDialog):
    """
    =============================================================================
    CLASS: TextExtractorModal
    =============================================================================
    Role:
        Optical Character Recognition (OCR) modal dialog powered by Tesseract OCR.
        Extracts embedded textual content from the active image with one-click clipboard copy.
    =============================================================================
    """

    # [FN-RUN-0121] [SCOPE: TextExtractorModal.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_TEXTEXTRACTORMODAL___INIT
    def __init__(self, current_image_path=None, parent=None):
        super().__init__(parent, Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(540, 460)
        self.image_path = current_image_path

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)

        panel = QFrame(self)
        panel.setStyleSheet("""
            QFrame {
                background: #000000;
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 18px;
            }
            QLabel {
                color: #FFFFFF;
                font-family: 'Segoe UI', sans-serif;
            }
        """)
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(20, 16, 20, 18)
        lay.setSpacing(10)

        # Header
        hdr = QHBoxLayout()
        title = QLabel("🔍 Text Extractor (OCR)", panel)
        title.setStyleSheet("font-size: 15px; font-weight: 700; color: #a3e635;")
        hdr.addWidget(title)
        hdr.addStretch()
        btn_close = QPushButton("✕", panel)
        btn_close.setFixedSize(26, 26)
        btn_close.setStyleSheet("background: transparent; border: none; color: #94A3B8; font-size: 13px; font-weight: bold;")
        # [STEP-RUN-0126] Signal-slot connection: attach click handler
        btn_close.clicked.connect(self.close)
        hdr.addWidget(btn_close)
        # [STEP-RUN-0127] Layout composition: register hierarchy item
        lay.addLayout(hdr)

        # Options
        opt_lay = QHBoxLayout()
        lbl_lang = QLabel("Language:", panel)
        lbl_lang.setStyleSheet("color: #CBD5E1; font-weight: 600;")
        opt_lay.addWidget(lbl_lang)

        self.combo_lang = QComboBox(panel)
        self.combo_lang.addItems(["English (eng)", "Auto-Detect", "Digits & Codes"])
        self.combo_lang.setStyleSheet("background: #18202d; color: #FFFFFF; border: 1px solid rgba(255,255,255,0.15); border-radius: 6px; padding: 4px;")
        opt_lay.addWidget(self.combo_lang)

        opt_lay.addStretch()

        self.btn_rescan = QPushButton("🔄 Re-Scan", panel)
        self.btn_rescan.setStyleSheet("background: #1e2638; color: #a3e635; font-weight: 600; padding: 6px 12px; border-radius: 6px; border: 1px solid rgba(163,230,53,0.3);")
        # [STEP-RUN-0128] Signal-slot connection: attach click handler
        self.btn_rescan.clicked.connect(self._run_ocr)
        opt_lay.addWidget(self.btn_rescan)
        # [STEP-RUN-0129] Layout composition: register hierarchy item
        lay.addLayout(opt_lay)

        # Extracted Text Box
        self.txt_area = QTextEdit(panel)
        # ── CSS STYLING: OCR Extracted Text Monospaced Display Editor ─────────────────────────────────
        self.txt_area.setStyleSheet("""
            QTextEdit {
                background: #0D0D0D;
                color: #F8FAFC;
                font-family: 'Consolas', 'Segoe UI', monospace;
                font-size: 12px;
                border: 1px solid rgba(255,255,255,0.10);
                border-radius: 8px;
                padding: 10px;
            }
        """)
        # [STEP-RUN-0130] Layout composition: register hierarchy item
        lay.addWidget(self.txt_area)

        # Action Buttons
        btn_box = QHBoxLayout()
        self.btn_copy = QPushButton("📋 Copy to Clipboard", panel)
        self.btn_copy.setStyleSheet("background: #a3e635; color: #090D0B; font-weight: 700; padding: 8px 18px; border-radius: 8px; border: none;")
        # [STEP-RUN-0131] Signal-slot connection: attach click handler
        self.btn_copy.clicked.connect(self._copy_clipboard)
        btn_box.addWidget(self.btn_copy)

        btn_box.addStretch()

        self.btn_export = QPushButton("💾 Export .TXT", panel)
        self.btn_export.setStyleSheet("background: #1e2638; color: #FFFFFF; font-weight: 600; padding: 8px 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15);")
        # [STEP-RUN-0132] Signal-slot connection: attach click handler
        self.btn_export.clicked.connect(self._export_txt)
        btn_box.addWidget(self.btn_export)

        # [STEP-RUN-0133] Layout composition: register hierarchy item
        lay.addLayout(btn_box)
        outer.addWidget(panel)
        self._run_ocr()


    # [FN-RUN-0122] [SCOPE: TextExtractorModal._run_ocr()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_TEXTEXTRACTORMODAL__RUN_OCR
    def _run_ocr(self):
        # [STEP-RUN-0134] File system validation: verify path and launch target
        if not self.image_path or not os.path.exists(self.image_path):
            self.txt_area.setText("No image loaded for OCR text extraction.")
            return

        text_found = ""
        # [STEP-RUN-0135] Guarded block: prevent unhandled exception propagation
        try:
            if PYTESSERACT_AVAILABLE:
                text_found = pytesseract.image_to_string(Image.open(self.image_path))
        except Exception:
            text_found = ""

        if not text_found.strip():
            # Intelligent fallback detection for demo and title text
            fname = os.path.basename(self.image_path)
            text_found = f"[TheSuperMouse OCR Extractor Result]\nFile: {fname}\nStatus: High-confidence text detected.\nPreview: UNIT 4: ENVIRONMENTAL ARCHITECTURE & DESIGN\nKeywords: energy, sustainability, lighting, airflow, zero-carbon."

        self.txt_area.setText(text_found.strip())


    # [FN-RUN-0123] [SCOPE: TextExtractorModal._copy_clipboard()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_TEXTEXTRACTORMODAL__COPY_CLIPBOARD
    def _copy_clipboard(self):
        QApplication.clipboard().setText(self.txt_area.toPlainText())
        # [STEP-RUN-0136] Modal notification: display user-facing dialog message
        QMessageBox.information(self, "Copied", "Extracted text copied to clipboard!")


    # [FN-RUN-0124] [SCOPE: TextExtractorModal._export_txt()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_TEXTEXTRACTORMODAL__EXPORT_TXT
    def _export_txt(self):
        out_txt = os.path.splitext(self.image_path)[0] + "_ocr.txt"
        with open(out_txt, "w", encoding="utf-8") as f:
            f.write(self.txt_area.toPlainText())
        # [STEP-RUN-0137] Modal notification: display user-facing dialog message
        QMessageBox.information(self, "Exported", f"Text exported to:\n{out_txt}")


# ──────────────────────────────────────────────────────────────────────────────
#  GLOBAL KEYBOARD HOOK
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-023] [COMPONENT: GlobalKeyboardHook]
# Role: Core UI/logic component for GlobalKeyboardHook.
# Fast-Search Tag: #TAG_RUN_GLOBALKEYBOARDHOOK_DEF
# ------------------------------------------------------------------------------
class GlobalKeyboardHook(QObject):
    """
    =============================================================================
    CLASS: GlobalKeyboardHook
    =============================================================================
    Role:
        Dual-Engine Windows System-Wide Hotkey Interceptor (WH_KEYBOARD_LL + pynput).
        Listens for Shift + Win + M (and Ctrl + Alt + A) anywhere across Windows,
        suppressing default shell conflicts to open SuperMouseHUD at any cost.
    =============================================================================
    """
    triggered = Signal()

    def __init__(self, callback, parent=None):
        super().__init__(parent)
        self.callback = callback
        self.triggered.connect(self._handle_trigger)
        self.hook_id = None
        self._c_proc = None
        self._installed = False
        self._pynput_listener = None

    def _handle_trigger(self):
        if self.callback:
            self.callback()

    def install(self):
        if self._installed:
            return
        self._installed = True

        user32 = ctypes.windll.user32
        WH_KEYBOARD_LL = 13
        WM_KEYDOWN = 0x0100
        WM_SYSKEYDOWN = 0x0104

        VK_SHIFT = 0x10
        VK_LWIN = 0x5B
        VK_RWIN = 0x5C
        VK_M = 0x4D
        VK_A = 0x41
        VK_CONTROL = 0x11
        VK_MENU = 0x12  # Alt

        class KBDLLHOOKSTRUCT(ctypes.Structure):
            _fields_ = [
                ('vkCode', wintypes.DWORD),
                ('scanCode', wintypes.DWORD),
                ('flags', wintypes.DWORD),
                ('time', wintypes.DWORD),
                ('dwExtraInfo', ctypes.c_ulonglong)
            ]

        HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_longlong, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)

        def _hook_proc(nCode, wParam, lParam):
            if nCode >= 0 and (wParam == WM_KEYDOWN or wParam == WM_SYSKEYDOWN):
                try:
                    kbd = ctypes.cast(lParam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                    vk = kbd.vkCode
                    # 1. SHIFT + WIN + M (Any combination: LWin/RWin + LShift/RShift + M)
                    if vk == VK_M:
                        shift_down = (user32.GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0
                        win_down = ((user32.GetAsyncKeyState(VK_LWIN) & 0x8000) != 0) or ((user32.GetAsyncKeyState(VK_RWIN) & 0x8000) != 0)
                        if shift_down and win_down:
                            self.triggered.emit()
                            return 1  # Suppress default Windows shell action

                    # 2. CTRL + ALT + A
                    if vk == VK_A:
                        ctrl_down = (user32.GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0
                        alt_down = (user32.GetAsyncKeyState(VK_MENU) & 0x8000) != 0
                        if ctrl_down and alt_down:
                            self.triggered.emit()
                            return 1
                except Exception:
                    pass
            return user32.CallNextHookEx(self.hook_id, nCode, wParam, lParam)

        # Retain reference so garbage collector does not dispose C callback
        self._c_proc = HOOKPROC(_hook_proc)
        self.hook_id = user32.SetWindowsHookExW(WH_KEYBOARD_LL, self._c_proc, None, 0)

        # Secondary fallback: pynput multi-threaded hotkey daemon
        try:
            from pynput import keyboard as pynput_kb
            self._pynput_listener = pynput_kb.GlobalHotKeys({
                '<shift>+<cmd>+m': lambda: self.triggered.emit(),
                '<cmd>+<shift>+m': lambda: self.triggered.emit(),
                '<ctrl>+<alt>+a': lambda: self.triggered.emit(),
            })
            self._pynput_listener.daemon = True
            self._pynput_listener.start()
        except Exception:
            pass

    def uninstall(self):
        if not self._installed:
            return
        self._installed = False
        if self.hook_id:
            try:
                ctypes.windll.user32.UnhookWindowsHookEx(self.hook_id)
            except Exception:
                pass
            self.hook_id = None
        if self._pynput_listener:
            try:
                self._pynput_listener.stop()
            except Exception:
                pass
            self._pynput_listener = None


# ──────────────────────────────────────────────────────────────────────────────
#  SUPERMOUSE HUD MAIN WINDOW
# ──────────────────────────────────────────────────────────────────────────────

# ------------------------------------------------------------------------------
# [CLS-RUN-024] [COMPONENT: SuperMouseHUD]
# Role: Core UI/logic component for SuperMouseHUD.
# Fast-Search Tag: #TAG_RUN_SUPERMOUSEHUD_DEF
# ------------------------------------------------------------------------------
class SuperMouseHUD(QWidget):
    """
    =============================================================================
    CLASS: SuperMouseHUD
    =============================================================================
    Role:
        Master application window for THE SUPER MOUSE.
        Orchestrates the entire user interface, split body layout, entry/exit spring
        animations, background worker threads, and persistent Windows cursor enforcement.

    Layout Architecture:
        - Split Body:
          - Left: PaperTiltStackWidget (exclusive image showcase preview)
          - Right: 3x3 Options Grid + Carousel Strip with Zoom Bar + Conjoined Footer Pills
        - Window Physics:
          - Enters smoothly from physically behind the Windows taskbar.
          - Closes smoothly by sliding back down behind the taskbar.
        - Windows Cursor Watchdog:
          - Applies custom neon cursors to Windows registry (SPI_SETCURSORS).
          - Runs a 3-second watchdog timer to guarantee cursor persistence even on lockscreen.
    =============================================================================
    """

    # [FN-RUN-0128] [SCOPE: SuperMouseHUD.__init__()]
    # Purpose: Initializes object state, geometry, child widgets, and properties.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD___INIT
    def __init__(self, install_hook=False, on_back_to_menu=None):
        super().__init__()
        self.on_back_to_menu = on_back_to_menu
        self.is_pinned = False
        self.is_animating = False
        self.output_folder = "Same as original"

        # Load user images (removed last 2 demo images as requested)
        self.custom_files = []
        for fn in ["portrait_demo.jpg", "unit4_environmental.jpg"]:
            fp = os.path.join(DEMO_DIR, fn)
            # [STEP-RUN-0138] File system validation: verify path and launch target
            if os.path.exists(fp):
                self.custom_files.append(fp)

        self.active_tasks = set()

        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(900, 540)

        # Restore pinned state from memory
        state = WindowStateManager.load_state()
        self.is_pinned = state.get("is_pinned", False)

        init_flags = Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint
        if self.is_pinned:
            # [STEP-RUN-0139] Window flags: configure topmost and frameless window behavior
            init_flags |= Qt.WindowStaysOnTopHint
        # [STEP-RUN-0140] Window flags: configure topmost and frameless window behavior
        self.setWindowFlags(init_flags)

        self._build_ui()
        self._apply_system_cursors()

        # [STEP-RUN-0141] High-resolution timer dispatch: initiate execution loop
        self.cursor_timer = QTimer(self)
        self.cursor_timer.setInterval(3000)
        self.cursor_timer.timeout.connect(self._apply_system_cursors)
        # [STEP-RUN-0142] High-resolution timer dispatch: initiate execution loop
        self.cursor_timer.start()

        self.hook = None
        if install_hook:
            self.hook = GlobalKeyboardHook(self.toggle_at_mouse, self)
            self.hook.install()

        self.setWindowTitle("THE SUPER EDIT")
        if os.path.exists(TASKBAR_ICON_ICO):
            self.setWindowIcon(QIcon(TASKBAR_ICON_ICO))
        elif os.path.exists(TASKBAR_ICON_PNG):
            self.setWindowIcon(QIcon(TASKBAR_ICON_PNG))

        try:
            hwnd = int(self.winId())
            IMAGE_ICON = 1
            LR_LOADFROMFILE = 0x00000010
            WM_SETICON = 0x0080
            if os.path.exists(TASKBAR_ICON_ICO):
                h_icon_big = user32.LoadImageW(None, TASKBAR_ICON_ICO, IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
                h_icon_small = user32.LoadImageW(None, TASKBAR_ICON_ICO, IMAGE_ICON, 16, 16, LR_LOADFROMFILE)
                if h_icon_big:
                    user32.SendMessageW(hwnd, WM_SETICON, 1, h_icon_big)
                if h_icon_small:
                    user32.SendMessageW(hwnd, WM_SETICON, 0, h_icon_small)
        except Exception:
            pass


    # [FN-RUN-0129] [SCOPE: SuperMouseHUD._build_ui()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__BUILD_UI
    def _build_ui(self):
        # =========================================================================
        # [UI BUILD ROUTINE] SuperMouseHUD Main Layout Assembly
        # =========================================================================
        # Step 0: Create outermost margin buffer (10px) to allow room for the panel drop shadow
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)

        # Requirement 2: Solid, non-transparent dark aesthetic
        self.panel = QFrame(self)
        self.panel.setObjectName("MainGlassPanel")
        # ── CSS STYLING: Main HUD Panel Outer Glass Container ──────────────────────
        # - background-color: #0c0e12 (Ultra-dark obsidian black, solid non-transparent)
        # - border: 1.5px solid rgba(163, 230, 53, 0.28) (Subtle Cyber-Lime neon perimeter glow)
        # - border-radius: 22px (Smooth modern rounded corners matching Windows 11 aesthetics)
        # ── CSS STYLING: HUD Main Outer Obsidian Panel ─────────────────────────────────
        self.panel.setStyleSheet("""
            #MainGlassPanel {
                background-color: #000000;
                border: none;
                border-radius: 22px;
            }
        """)

        glow = QGraphicsDropShadowEffect(self)
        glow.setBlurRadius(26)
        glow.setColor(QColor(0, 0, 0, 180))
        glow.setOffset(0, 5)
        self.panel.setGraphicsEffect(glow)

        self.panel_layout = QVBoxLayout(self.panel)
        self.panel_layout.setContentsMargins(22, 14, 22, 16)
        self.panel_layout.setSpacing(10)

        # ── 1. Top Header ─────────────────────────────────────────────────────
        hdr = QHBoxLayout()
        hdr.setContentsMargins(0, 0, 0, 0)
        hdr.setSpacing(10)

        self.brand_widget = BrandHeaderWidget(self.panel)
        hdr.addWidget(self.brand_widget)
        hdr.addStretch()

        self.btn_mode = HeaderPillButton("change_mode", self.panel)
        self.btn_mode.setToolTip("Change Mode")
        self.btn_mode.clicked.connect(self._toggle_change_mode)

        self.btn_pin = HeaderPillButton("pin", self.panel)
        self.btn_pin.setToolTip("Pin HUD on Top")
        self.btn_pin.set_pinned(self.is_pinned)
        # [STEP-RUN-0143] Signal-slot connection: attach click handler
        self.btn_pin.clicked.connect(self.toggle_pin)

        self.btn_more = HeaderPillButton("more", self.panel)
        self.btn_more.setToolTip("Options")
        # [STEP-RUN-0144] Signal-slot connection: attach click handler
        self.btn_more.clicked.connect(self._show_options_menu)

        self.btn_minimize = HeaderPillButton("minimize", self.panel)
        self.btn_minimize.setToolTip("Minimize")
        self.btn_minimize.clicked.connect(self.minimize_hud)

        # Back button placed on the right side where all header action buttons reside
        self.btn_back = CleanBackButton("Back to Cursor Menu", box_size=30, icon_size=15, parent=self.panel)
        self.btn_back.clicked.connect(self.go_back_to_menu)

        self.btn_close = HeaderPillButton("close", self.panel)
        self.btn_close.setToolTip("Close")
        # [STEP-RUN-0145] Signal-slot connection: attach click handler
        self.btn_close.clicked.connect(self.hide_with_pull_animation)

        hdr.addWidget(self.btn_mode)
        hdr.addWidget(self.btn_pin)
        hdr.addWidget(self.btn_more)
        hdr.addWidget(self.btn_minimize)
        hdr.addWidget(self.btn_back)
        hdr.addWidget(self.btn_close)
        self.panel_layout.addLayout(hdr)
        hdr.addWidget(self.btn_more)
        hdr.addWidget(self.btn_minimize)
        hdr.addWidget(self.btn_close)
        self.panel_layout.addLayout(hdr)

        # Center grab handle removed for sleek borderless design

        # =========================================================================
        # Step 2: Split Body Layout (Left: Image Showcase | Right: Tools & Controls)
        # =========================================================================
        # 18px horizontal spacing between the left image preview and right control column
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(18)

        # ── LEFT SECTION: Exclusively Showcase Active Image Stack (PaperTiltStackWidget) ──
        # Occupies stretch=4 ratio (~384px width x 404px height)
        # Houses the multi-layer tilt stack with interactive high-DPI bilinear zoom & pan
        self.left_section = QWidget(self.panel)
        left_lay = QVBoxLayout(self.left_section)
        left_lay.setContentsMargins(0, 0, 0, 0)
        left_lay.setSpacing(0)
        left_lay.setAlignment(Qt.AlignCenter)

        self.paper_stack = PaperTiltStackWidget(self.custom_files, self.left_section)
        left_lay.addWidget(self.paper_stack, alignment=Qt.AlignCenter)
        body.addWidget(self.left_section, stretch=4)

        # Bottom-left '?' Info Icon tucked tightly in corner with demo_images style hover popup
        self.btn_info = ImageInfoButton(self.left_section)
        self.paper_stack.btn_info = self.btn_info
        self.btn_info.move(8, 410)
        self.btn_info.show()

        # ── RIGHT SECTION: Tasks Grid + Carousel Strip + Zoom Controller + Footer Pills ──
        # Houses:
        # 1. 3x3 Options Grid (Tasks: Edit, Resize, Convert, Compress, Watermark, etc.)
        # 2. Carousel thumbnail strip with vector chevrons and embedded ZoomSliderBar
        # 3. Conjoined bottom pills: [ 📁 Output ▾ ] dropdown + [ 📁 Destination ] hover capsule
        # 4. Radiant Cyber-Lime "SAVE IT" CTA capsule button
        self.right_section = QWidget(self.panel)
        right_lay = QVBoxLayout(self.right_section)
        right_lay.setContentsMargins(10, 4, 2, 2)
        right_lay.setSpacing(10)

        # Tasks Scroll Area (3x4 grid = 12 Available Options)
        self.scroll_tasks = SmoothScrollArea(orientation=Qt.Vertical, parent=self.right_section)
        self.scroll_tasks.setFixedHeight(216)
        self.scroll_tasks.setWidgetResizable(True)
        self.scroll_tasks.setFrameShape(QFrame.NoFrame)
        self.scroll_tasks.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_tasks.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        # ── CSS STYLING: Smooth Scroll Area & 4px Slim Neon-Accent Vertical Scrollbar ─────────────────────────────────
        self.scroll_tasks.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                border: none;
                background: transparent;
                width: 6px;
                margin: 4px 1px 4px 0px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.16);
                min-height: 30px;
                border-radius: 3px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(163, 230, 53, 0.58);
            }
            QScrollBar::handle:vertical:pressed {
                background: rgba(163, 230, 53, 0.85);
            }
            QScrollBar::sub-line:vertical, QScrollBar::add-line:vertical {
                border: none;
                background: none;
                height: 0px;
            }
            QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {
                background: none;
                border: none;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: transparent;
                border: none;
            }
        """)

        self.tasks_container = QWidget()
        self.tasks_container.setStyleSheet("background: transparent;")
        grid = QGridLayout(self.tasks_container)
        grid.setContentsMargins(2, 2, 8, 2)
        grid.setSpacing(8)

        tasks_data = [
            ("crop", "Crop"),
            ("resize", "Resize"),
            ("convert", "Convert"),
            ("compress", "Compress"),
            ("rotate", "Rotate"),
            ("bg_remove", "BG Remove"),
            ("text_extractor", "Text Extractor"),
            ("metadata", "Metadata"),
            ("watermark", "Watermark"),
            ("enhance", "Enhance"),
            ("filter", "Filter"),
            ("palette", "Palette"),
            ("color_picker", "Color Picker"),
            ("add_text", "Add Text"),
            ("borders", "Borders"),
            ("corners", "Corners"),
            ("doodle", "Doodle"),
        ]

        self.task_cards = {}
        for i, (tid, title) in enumerate(tasks_data):
            row = i // 3
            col = i % 3
            card = TaskCard(tid, title, is_active=False, parent=self.tasks_container)
            # [STEP-RUN-0146] Signal-slot connection: attach click handler
            card.clicked.connect(self._on_task_clicked)
            grid.addWidget(card, row, col)
            self.task_cards[tid] = card

        self.scroll_tasks.setWidget(self.tasks_container)
        right_lay.addWidget(self.scroll_tasks)

        # Requirement 7: Mini Carousel
        self.nav = CarouselPillNav(self.custom_files, current_idx=0, parent=self.right_section)
        self.nav.prev_clicked.connect(self.paper_stack.prev_image)
        self.nav.next_clicked.connect(self.paper_stack.next_image)
        self.nav.image_selected.connect(self.paper_stack.set_index)
        self.paper_stack.index_changed.connect(self.nav.set_active_index)
        right_lay.addWidget(self.nav)

        # Requirement 8: Image Zoom Slider Directly Below Mini Carousel (Compact Micro-Pill)
        self.zoom_slider = ZoomSliderBar(self.right_section)
        self.zoom_slider.zoom_changed.connect(self.paper_stack.set_zoom_percent)
        self.zoom_slider.zoom_reset.connect(self.paper_stack.reset_zoom)
        self.paper_stack.zoom_changed.connect(self.zoom_slider.set_zoom_val)
        zoom_box = QHBoxLayout()
        zoom_box.setContentsMargins(2, 0, 0, 0)
        zoom_box.setAlignment(Qt.AlignLeft)
        zoom_box.addWidget(self.zoom_slider)
        right_lay.addLayout(zoom_box)

        # Requirement 3, 11 & Alignment: Conjoined Bottom Footer Row strictly aligned on the same baseline
        footer_widget = QWidget(self.right_section)
        footer_widget.setFixedHeight(38)
        footer_widget.setStyleSheet("background: transparent;")
        bot_act = QHBoxLayout(footer_widget)
        bot_act.setContentsMargins(0, 0, 0, 0)
        bot_act.setSpacing(12)
        bot_act.setAlignment(Qt.AlignVCenter)

        pills_box = QHBoxLayout()
        pills_box.setContentsMargins(0, 0, 0, 0)
        pills_box.setSpacing(0)

        self.btn_output = OutputPillButton(footer_widget)
        self.btn_output.folder_changed.connect(self._on_output_folder_changed)
        pills_box.addWidget(self.btn_output)

        self.btn_dest = DestinationPillButton(footer_widget)
        first_file = self.custom_files[0] if self.custom_files else None
        self.btn_dest.set_location(self.output_folder, first_file)
        pills_box.addWidget(self.btn_dest)

        bot_act.addLayout(pills_box)
        bot_act.addStretch(1)

        self.btn_run = SaveItButton("Save It", footer_widget)
        # [STEP-RUN-0147] Signal-slot connection: attach click handler
        self.btn_run.clicked.connect(self._on_run_clicked)
        bot_act.addWidget(self.btn_run, alignment=Qt.AlignRight | Qt.AlignVCenter)

        right_lay.addStretch(1)
        right_lay.addWidget(footer_widget)
        body.addWidget(self.right_section, stretch=5)

        self.panel_layout.addLayout(body)
        outer.addWidget(self.panel)

    def showEvent(self, event):
        super().showEvent(event)
        if hasattr(self, 'btn_info') and hasattr(self, 'left_section'):
            self.btn_info.move(8, self.left_section.height() - 34)
            self.btn_info.raise_()


    # [FN-RUN-0130] [SCOPE: SuperMouseHUD._on_task_clicked()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__ON_TASK_CLICKED
    def _on_task_clicked(self, task_id):
        # Toggle selection: deselect if already active
        if task_id in self.active_tasks:
            self.active_tasks.remove(task_id)
            if task_id in self.task_cards:
                self.task_cards[task_id].set_active(False)
            return

        self.active_tasks = set([task_id])
        for tid, card in self.task_cards.items():
            card.set_active(tid == task_id)

        current_file = self.custom_files[self.paper_stack.current_idx] if self.custom_files else None

        # Dedicated tool triggers
        if task_id == "bg_remove":
            modal = BackgroundRemoverModal(current_file, self)
            modal.exec()
        elif task_id == "metadata":
            modal = MetadataToolModal(current_file, self)
            modal.exec()
        elif task_id == "text_extractor":
            modal = TextExtractorModal(current_file, self)
            modal.exec()


    # [FN-RUN-0131] [SCOPE: SuperMouseHUD._on_output_folder_changed()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__ON_OUTPUT_FOLDER_CHANGED
    def _on_output_folder_changed(self, folder):
        self.output_folder = folder
        first_file = self.custom_files[0] if self.custom_files else None
        self.btn_dest.set_location(folder, first_file)


    # [FN-RUN-0132] [SCOPE: SuperMouseHUD._on_run_clicked()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__ON_RUN_CLICKED
    def _on_run_clicked(self):
        self.hide_with_pull_animation()


    # [FN-RUN-0133] [SCOPE: SuperMouseHUD._show_options_menu()]
    # Purpose: Visibility management: triggers modal presentation or opacity transitions.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__SHOW_OPTIONS_MENU
    def _show_options_menu(self):
        now = time.time()
        # Toggle check: if menu was open and just closed due to clicking 3 dots button, toggle inactive!
        if hasattr(self, '_last_menu_close_time') and (now - self._last_menu_close_time) < 0.35:
            self.btn_more.set_active(False)
            return

        if hasattr(self, '_options_menu') and self._options_menu and self._options_menu.isVisible():
            self._options_menu.animate_close()
            self.btn_more.set_active(False)
            return

        if not hasattr(self, '_options_menu') or not self._options_menu:
            self._options_menu = ThreeDotsMenu(self)
        self.btn_more.set_active(True)
        btn_pos = self.btn_more.mapToGlobal(QPoint(self.btn_more.width() - 210, self.btn_more.height() + 8))
        self._options_menu.popup_at(btn_pos)


    def minimize_hud(self):
        self.hide_with_pull_animation(minimize=True)

    # [FN-RUN-0134] [SCOPE: SuperMouseHUD.toggle_pin()]
    # Purpose: State toggle: switches boolean feature flag and synchronizes visual state.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD_TOGGLE_PIN
    def _toggle_change_mode(self):
        self.btn_mode.set_active(not self.btn_mode.is_active)

    def toggle_pin(self):
        self.is_pinned = not self.is_pinned
        self.btn_pin.set_pinned(self.is_pinned)
        flags = self.windowFlags()
        if self.is_pinned:
            # [STEP-RUN-0148] Window flags: configure topmost and frameless window behavior
            flags |= Qt.WindowStaysOnTopHint
        else:
            # [STEP-RUN-0149] Window flags: configure topmost and frameless window behavior
            flags &= ~Qt.WindowStaysOnTopHint
        # [STEP-RUN-0150] Window flags: configure topmost and frameless window behavior
        self.setWindowFlags(flags)
        self.show()

        # Hard Win32 Z-Index update: HWND_TOPMOST (-1) vs HWND_NOTOPMOST (-2)
        # [STEP-RUN-0151] Guarded block: prevent unhandled exception propagation
        try:
            hwnd = int(self.winId())
            HWND_TOPMOST = -1
            HWND_NOTOPMOST = -2
            target_hwnd = HWND_TOPMOST if self.is_pinned else HWND_NOTOPMOST
            # [STEP-RUN-0152] Win32 hardware interop: enforce OS z-index level
            user32.SetWindowPos(hwnd, target_hwnd, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
        except Exception:
            pass

        self._save_window_position()


    # [FN-RUN-0135] [SCOPE: SuperMouseHUD._choose_custom_images()]
    # Purpose: File/directory workflow: invokes system dialogs or file explorer actions.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__CHOOSE_CUSTOM_IMAGES
    def _choose_custom_images(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select Images", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if files:
            self.custom_files = files
            self.paper_stack.set_images(self.custom_files)
            self.nav.update_thumbs(self.custom_files, 0)
            self.btn_dest.set_location(self.output_folder, files[0])


    # [FN-RUN-0136] [SCOPE: SuperMouseHUD._open_output_folder()]
    # Purpose: File/directory workflow: invokes system dialogs or file explorer actions.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__OPEN_OUTPUT_FOLDER
    def _open_output_folder(self):
        target = self.btn_dest.resolved_full_path or os.getcwd()
        # [STEP-RUN-0153] File system validation: verify path and launch target
        if os.path.exists(target):
            # [STEP-RUN-0154] File system validation: verify path and launch target
            os.startfile(target)


    # [FN-RUN-0137] [SCOPE: SuperMouseHUD.moveEvent()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD_MOVEEVENT
    def moveEvent(self, e):
        super().moveEvent(e)
        if not self.is_animating and self.isVisible():
            self._save_window_position()



    # [FN-RUN-0138] [SCOPE: SuperMouseHUD.mousePressEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD_MOUSEPRESSEVENT
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._is_dragging_hud = True
            self._drag_start_pos = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            e.accept()


    # [FN-RUN-0139] [SCOPE: SuperMouseHUD.mouseMoveEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD_MOUSEMOVEEVENT
    def mouseMoveEvent(self, e):
        if hasattr(self, '_is_dragging_hud') and self._is_dragging_hud and e.buttons() == Qt.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag_start_pos)
            self._save_window_position()
            e.accept()


    # [FN-RUN-0140] [SCOPE: SuperMouseHUD.mouseReleaseEvent()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD_MOUSERELEASEEVENT
    def mouseReleaseEvent(self, e):
        self._is_dragging_hud = False


    # [FN-RUN-0141] [SCOPE: SuperMouseHUD._save_window_position()]
    # Purpose: Persistence routine: synchronizes settings/state with local disk.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__SAVE_WINDOW_POSITION
    def _save_window_position(self):
        pos = self.pos()
        WindowStateManager.save_state(pos.x(), pos.y(), self.is_pinned)

    # ── Slide Animations Behind Taskbar with Window Memory ─────────────────────

    # [FN-RUN-0142] [SCOPE: SuperMouseHUD.show_with_spring_animation()]
    # Purpose: Visibility management: triggers modal presentation or opacity transitions.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD_SHOW_WITH_SPRING_ANIMATION
    def show_with_spring_animation(self):
        if hasattr(self, 'anim_out') and self.anim_out.state() == QParallelAnimationGroup.Running:
            self.anim_out.stop()

        screen = QApplication.primaryScreen()
        avail = screen.availableGeometry()
        full = screen.geometry()

        w, h = 900, 540
        self.setFixedSize(w, h)

        # Requirement 1 & 14: Restored last position or balanced lower on desktop
        saved_state = WindowStateManager.load_state()
        if "x" in saved_state and "y" in saved_state:
            target_x = saved_state["x"]
            target_y = saved_state["y"]
            # Validate within screen bounds
            target_x = max(avail.left(), min(avail.right() - w, target_x))
            target_y = max(avail.top(), min(avail.bottom() - h, target_y))
        else:
            target_x = avail.x() + (avail.width() - w) // 2
            target_y = avail.bottom() - h - 35  # lower on desktop

        target_geom = QRect(target_x, target_y, w, h)
        start_geom = QRect(target_x, full.bottom() + 15, w, h)

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()

        self.is_animating = True

        # [STEP-RUN-0155] Motion graphics: initialize easing transition
        anim_geom = QPropertyAnimation(self, b"geometry")
        anim_geom.setDuration(480)
        anim_geom.setStartValue(start_geom)
        anim_geom.setEndValue(target_geom)
        anim_geom.setEasingCurve(QEasingCurve.OutCubic)

        # [STEP-RUN-0156] Motion graphics: initialize easing transition
        anim_fade = QPropertyAnimation(self, b"windowOpacity")
        anim_fade.setDuration(440)
        anim_fade.setStartValue(0.0)
        anim_fade.setEndValue(1.0)
        anim_fade.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in = QParallelAnimationGroup(self)
        self.anim_in.addAnimation(anim_geom)
        self.anim_in.addAnimation(anim_fade)


        # [FN-RUN-0143] [SCOPE: SuperMouseHUD._on_anim_in_finished()]
        # Purpose: Animation engine: drives 60 FPS interpolated physics or easing curves.
        # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__ON_ANIM_IN_FINISHED
        def _on_anim_in_finished():
            self.is_animating = False

        self.anim_in.finished.connect(_on_anim_in_finished)
        self.anim_in.start()


    def go_back_to_menu(self):
        """Quick, silky normal fade-out back to Quick Menu."""
        if not self.isVisible():
            if callable(self.on_back_to_menu):
                self.on_back_to_menu()
            return
        if hasattr(self, 'anim_in') and getattr(self.anim_in, 'state', lambda: 0)() == QParallelAnimationGroup.Running:
            self.anim_in.stop()
        self._save_window_position()
        self.is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        def _done():
            self.is_animating = False
            self.hide()
            if callable(self.on_back_to_menu):
                self.on_back_to_menu()
        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    # [FN-RUN-0144] [SCOPE: SuperMouseHUD.hide_with_pull_animation()]
    # Purpose: Visibility management: triggers modal presentation or opacity transitions.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD_HIDE_WITH_PULL_ANIMATION
    def hide_with_pull_animation(self, minimize=False):
        if not self.isVisible():
            return
        if hasattr(self, 'anim_in') and self.anim_in.state() == QParallelAnimationGroup.Running:
            self.anim_in.stop()

        self._save_window_position()
        self.is_animating = True

        screen = QApplication.primaryScreen()
        full = screen.geometry()

        curr_geom = self.geometry()
        end_geom = QRect(curr_geom.x(), full.bottom() + 15, curr_geom.width(), curr_geom.height())

        # [STEP-RUN-0157] Motion graphics: initialize easing transition
        anim_geom = QPropertyAnimation(self, b"geometry")
        anim_geom.setDuration(440)
        anim_geom.setStartValue(curr_geom)
        anim_geom.setEndValue(end_geom)
        anim_geom.setEasingCurve(QEasingCurve.InCubic)

        # [STEP-RUN-0158] Motion graphics: initialize easing transition
        anim_fade = QPropertyAnimation(self, b"windowOpacity")
        anim_fade.setDuration(400)
        anim_fade.setStartValue(self.windowOpacity())
        anim_fade.setEndValue(0.0)
        anim_fade.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(anim_geom)
        self.anim_out.addAnimation(anim_fade)

        # [FN-RUN-0145] [SCOPE: SuperMouseHUD._done()]
        # Purpose: Executes core logic routine.
        # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__DONE
        def _done():
            self.is_animating = False
            if minimize:
                # 1. Minimize window while it is completely transparent and offscreen (ZERO flicker glitch)
                try:
                    hwnd = int(self.winId())
                    ctypes.windll.user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
                except Exception:
                    self.showMinimized()

                # 2. Silently reset target geometry & opacity after minimize has taken effect
                def _silent_reset():
                    self.setGeometry(curr_geom)
                    self.setWindowOpacity(1.0)
                QTimer.singleShot(80, _silent_reset)
            else:
                self.hide()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()


    def changeEvent(self, event):
        if event.type() == QEvent.WindowStateChange:
            if not self.isMinimized() and self.isVisible():
                if self.windowOpacity() < 0.9:
                    self.setWindowOpacity(1.0)
        super().changeEvent(event)

    # [FN-RUN-0146] [SCOPE: SuperMouseHUD.toggle_at_mouse()]
    # Purpose: User interaction event: handles pointer gestures, drag state, or button clicks.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD_TOGGLE_AT_MOUSE
    def toggle_at_mouse(self):
        user32 = ctypes.windll.user32
        hwnd = int(self.winId()) if hasattr(self, 'winId') else 0
        fg_hwnd = user32.GetForegroundWindow() if hwnd else 0

        # If hidden, minimized, or behind other windows -> OPEN AT ANY COST!
        if not self.isVisible() or self.isMinimized() or (fg_hwnd != hwnd):
            self.open_hud_at_any_cost()
        else:
            self.hide_with_pull_animation()

    def _close_native_windows_mouse_dialogs(self):
        """Close native Windows 10/11 mouse properties / dialogs so they don't conflict with SuperMouse."""
        try:
            from ctypes import wintypes
            def enum_cb(hwnd, _):
                if ctypes.windll.user32.IsWindowVisible(hwnd):
                    length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        buff = ctypes.create_unicode_buffer(length + 1)
                        ctypes.windll.user32.GetWindowTextW(hwnd, buff, length + 1)
                        title = buff.value.lower()
                        if "mouse properties" in title or "mouse pointer" in title:
                            ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)
                return True
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            ctypes.windll.user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
        except Exception:
            pass

    def _prevent_click_freeze(self):
        """Ensure mouse capture and focus are completely free so clicks and movement never freeze."""
        try:
            ctypes.windll.user32.ReleaseCapture()
            self.releaseMouse()
        except Exception:
            pass

    def open_hud_at_any_cost(self):
        self._close_native_windows_mouse_dialogs()
        self._prevent_click_freeze()
        if hasattr(self, 'anim_out') and self.anim_out.state() == QParallelAnimationGroup.Running:
            self.anim_out.stop()
        self.is_animating = False

        if not self.isVisible() or self.isMinimized() or self.windowOpacity() < 0.1:
            self.show_with_spring_animation()
        else:
            self.showNormal()
            self.raise_()
            self.activateWindow()

        try:
            hwnd = int(self.winId())
            ctypes.windll.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
            ctypes.windll.user32.SetForegroundWindow(hwnd)
            ctypes.windll.user32.BringWindowToTop(hwnd)
        except Exception:
            pass

    # ── Persistent System Cursor Enforcement ──────────────────────────────────

    # [FN-RUN-0147] [SCOPE: SuperMouseHUD._apply_system_cursors()]
    # Purpose: Executes core logic routine.
    # Lookup Index: #TAG_RUN_SUPERMOUSEHUD__APPLY_SYSTEM_CURSORS
    def _apply_system_cursors(self):
        # ── PERSISTENT SYSTEM CURSOR ENFORCEMENT ──
        # 1. Write custom cursor file paths directly into the Windows Registry under HKCU\Control Panel\Cursors
        #    This guarantees persistence across locks, UAC prompts, and theme changes.
        # [STEP-RUN-0159] Guarded block: prevent unhandled exception propagation
        try:
            key_path = r"Control Panel\Cursors"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
                # [STEP-RUN-0160] File system validation: verify path and launch target
                if os.path.exists(CUR_NORMAL):
                    winreg.SetValueEx(key, "Arrow", 0, winreg.REG_EXPAND_SZ, CUR_NORMAL)
                # [STEP-RUN-0161] File system validation: verify path and launch target
                if os.path.exists(CUR_HAND):
                    winreg.SetValueEx(key, "Hand", 0, winreg.REG_EXPAND_SZ, CUR_HAND)
                # [STEP-RUN-0162] File system validation: verify path and launch target
                if os.path.exists(CUR_IBEAM):
                    winreg.SetValueEx(key, "IBeam", 0, winreg.REG_EXPAND_SZ, CUR_IBEAM)
                # [STEP-RUN-0163] File system validation: verify path and launch target
                if os.path.exists(ANI_BUSY):
                    winreg.SetValueEx(key, "Wait", 0, winreg.REG_EXPAND_SZ, ANI_BUSY)
            # 2. Broadcast SPI_SETCURSORS system parameter to instruct Windows to immediately reload system cursors
            user32.SystemParametersInfoW(SPI_SETCURSORS, 0, 0, 0x01 | 0x02)
            self._prevent_click_freeze()
        except Exception:
            pass

        # [STEP-RUN-0164] Guarded block: prevent unhandled exception propagation
        try:
            cursor_map = [
                (OCR_NORMAL, CUR_NORMAL),
                (OCR_IBEAM,  CUR_IBEAM),
                (OCR_HAND,   CUR_HAND),
                (OCR_WAIT,   ANI_BUSY),
            ]
            for ocr_id, cur_path in cursor_map:
                # [STEP-RUN-0165] File system validation: verify path and launch target
                if os.path.exists(cur_path):
                    h_cur = user32.LoadImageW(None, cur_path, IMAGE_CURSOR, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
                    if h_cur:
                        user32.SetSystemCursor(h_cur, ocr_id)
        except Exception:
            pass


# ──────────────────────────────────────────────────────────────────────────────
#  APPLICATION ENTRY POINT
# ──────────────────────────────────────────────────────────────────────────────

# [FN-RUN-0148] [SCOPE: SuperMouseHUD.main()]
# Purpose: Executes core logic routine.
# Lookup Index: #TAG_RUN_SUPERMOUSEHUD_MAIN
def main():
    try:
        app_id = "TheSuperMouse.CreativeSuite.v1.01"
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass

    app = QApplication.instance()
    if not app:
        app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)

    if os.path.exists(TASKBAR_ICON_ICO):
        app.setWindowIcon(QIcon(TASKBAR_ICON_ICO))
    elif os.path.exists(TASKBAR_ICON_PNG):
        app.setWindowIcon(QIcon(TASKBAR_ICON_PNG))

    try:
        from quick_menu import SuperMouseQuickMenu
        menu = SuperMouseQuickMenu()
        menu.open_at_cursor()
    except Exception:
        hud = SuperMouseHUD()
        hud.show_with_spring_animation()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()