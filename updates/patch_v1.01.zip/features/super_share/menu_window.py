# -*- coding: utf-8 -*-
import os
import sys
import ctypes

from PySide6.QtCore import (
    Qt,
    QPoint,
    QRect,
    QRectF,
    QTimer,
    Signal,
    QByteArray,
    QPropertyAnimation,
    QParallelAnimationGroup,
    QEasingCurve,
)
from PySide6.QtGui import (
    QColor,
    QCursor,
    QFont,
    QFontMetrics,
    QImage,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QVBoxLayout,
    QWidget,
)

from ui_theme import (
    COMMON_ICONS,
    CleanBackButton,
    CleanCloseButton,
    format_count_label,
    native_dpr,
)
from .common import count_stored_share_items


def _draw_crisp_text(p, rect, centered, font, color, text):
    f = QFont(font)
    f.setHintingPreference(QFont.PreferNoHinting)
    fm = QFontMetrics(f)
    tx = (rect.center().x() - fm.horizontalAdvance(text) * 0.5) if centered else float(rect.left())
    ty = rect.center().y() + (fm.ascent() - fm.descent()) * 0.5
    tp = QPainterPath()
    tp.addText(tx, ty, f, text)
    p.fillPath(tp, color)


def _draw_vector_brand(p, bx, by_c, logo_pix, word1, word2, font_pt=10.2):
    if logo_pix and not logo_pix.isNull():
        dpr = max(1.0, float(logo_pix.devicePixelRatio() or 1.0))
        lw = logo_pix.width() / dpr
        lh = logo_pix.height() / dpr
        p.drawPixmap(int(round(bx)), int(round(by_c - lh / 2.0)), logo_pix)
        bx += lw + 8.0

    f_logo = QFont("Segoe UI Variable")
    f_logo.setStyleName("Display Bold")
    f_logo.setPointSizeF(font_pt)
    f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
    f_logo.setHintingPreference(QFont.PreferNoHinting)

    probe = QPainterPath()
    probe.addText(0.0, 0.0, f_logo, f"{word1} {word2}")
    br = probe.boundingRect()
    baseline_y = by_c - (br.top() + br.height() * 0.5)

    p1 = QPainterPath()
    p1.addText(bx, baseline_y, f_logo, word1)
    p.fillPath(p1, QColor("#FFFFFF"))

    w1 = p1.boundingRect().width()
    smx = bx + w1 + 5.5

    p2 = QPainterPath()
    p2.addText(smx, baseline_y, f_logo, word2)
    p.fillPath(p2, QColor("#A3E635"))


class _ShareMenuItemRow(QWidget):
    clicked = Signal(dict)

    def __init__(self, item_data, idx=0, parent=None):
        super().__init__(parent)
        self.item = item_data
        self.idx = idx
        self._badge_override = None
        self.setFixedHeight(36)
        self.setCursor(Qt.PointingHandCursor)

        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self._reveal = 1.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def set_badge_text(self, txt):
        self._badge_override = txt
        self.update()

    def start_reveal_animation(self):
        self._reveal = 1.0
        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self.update()

    def _step(self):
        active = False
        if self._reveal < 1.0:
            self._reveal = min(1.0, self._reveal + 0.11)
            active = True
        if abs(self._target - self._h) >= 0.005:
            self._h += (self._target - self._h) * 0.23
            active = True
        elif self._h != self._target:
            self._h = self._target
        if self._press > 0.01:
            self._press *= 0.80
            active = True
        else:
            self._press = 0.0

        self.update()
        if not active and self._reveal >= 1.0 and self._h == self._target and self._press == 0.0:
            self._timer.stop()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            self.clicked.emit(self.item)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        rev = self._reveal
        if rev <= 0.01:
            p.end()
            return

        w, h = float(self.width()), float(self.height())
        hv = self._h
        badge_text = self._badge_override if self._badge_override is not None else self.item.get("badge")
        sc = 1.0 - self._press * 0.016

        p.save()
        p.setOpacity(rev)
        p.translate(0.0, (1.0 - rev) * 7.0)
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        pill_rect = QRectF(10.0, 1.5, w - 20.0, h - 3.0)
        pill_path = QPainterPath()
        pill_path.addRoundedRect(pill_rect, 8.5, 8.5)

        if hv > 0.008:
            p.fillPath(pill_path, QColor(18, 26, 15, int(235 * hv)))
            p.setPen(QPen(QColor(163, 230, 53, int(175 * hv)), 1.1))
            p.drawPath(pill_path)

            bar_h = 16.0 * hv
            bp = QPainterPath()
            bp.addRoundedRect(QRectF(10.0, (h - bar_h) * 0.5, 2.5, bar_h), 1.25, 1.25)
            p.fillPath(bp, QColor(163, 230, 53, int(245 * hv)))

        r_c = int(228 * (1.0 - hv) + 163 * hv)
        g_c = int(228 * (1.0 - hv) + 230 * hv)
        b_c = int(231 * (1.0 - hv) + 53 * hv)
        col_hex = f"#{r_c:02x}{g_c:02x}{b_c:02x}"

        ico_s = 16.0
        QSvgRenderer(QByteArray(self.item["svg"].replace("{col}", col_hex).encode("utf-8"))).render(
            p, QRectF(18.0 + hv * 2.5, (h - ico_s) * 0.5, ico_s, ico_s)
        )

        f = QFont("Segoe UI Variable")
        f.setStyleName("Text Semibold" if hv < 0.45 else "Display Bold")
        f.setPointSizeF(9.6)
        text_x = 44.0 + hv * 3.0
        right_m = 72.0 if badge_text else 20.0
        _draw_crisp_text(
            p, QRectF(text_x, 0.0, w - text_x - right_m, h), False, f,
            QColor("#FFFFFF") if hv > 0.3 else QColor("#EDEDEF"), self.item["label"],
        )

        if badge_text:
            pw, ph = 58.0, 15.5
            pr = QRectF(w - 18.0 - pw, (h - ph) * 0.5, pw, ph)
            pp = QPainterPath()
            pp.addRoundedRect(pr, 4.5, 4.5)
            p.fillPath(pp, QColor(163, 230, 53, int(18 + hv * 18)) if hv > 0.2 else QColor(255, 255, 255, 10))
            p.setPen(QPen(QColor(163, 230, 53, int(65 + hv * 95)) if hv > 0.2 else QColor(255, 255, 255, 24), 0.8))
            p.drawPath(pp)
            pf = QFont("Segoe UI Variable")
            pf.setStyleName("Display Bold")
            pf.setPointSizeF(5.6)
            pf.setLetterSpacing(QFont.AbsoluteSpacing, 0.3)
            _draw_crisp_text(p, pr, True, pf, QColor("#a3e635") if hv > 0.2 else QColor("#A1A7B3"), badge_text)

        p.restore()
        p.end()


class SuperShareMenuWindow(QWidget):
    """
    Super Share 3-Item Sub Menu Hub Window.
    Identical pure #040405 Obsidian card & seamless styling to SuperClipboardWindow.
    """

    ITEMS = [
        {
            "id": "share_device_hub",
            "label": "Device Hub",
            "coming_soon": False,
            "badge": None,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect x="2" y="4" width="13" height="10" rx="2"/><rect x="16" y="10" width="6" height="10" rx="1.5"/><path d="M6 18h5m-2.5-4v4"/></g></svg>',
        },
        {
            "id": "share_memory_space",
            "label": "Memory Space",
            "coming_soon": False,
            "badge": "0 Files",
            "svg": COMMON_ICONS["my_box"],
        },
        {
            "id": "share_settings",
            "label": "Share Settings",
            "coming_soon": False,
            "badge": None,
            "svg": COMMON_ICONS["settings"],
        },
    ]

    def __init__(self, on_back_to_menu=None, on_open_device=None, on_open_stored=None, on_open_settings=None, parent=None):
        super().__init__(parent)
        self.on_back_to_menu = on_back_to_menu
        self.on_open_device = on_open_device
        self.on_open_stored = on_open_stored
        self.on_open_settings = on_open_settings

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(316, 214)

        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - Super Share")

        self._dragging = False
        self._is_animating = False
        self._drag_offset = QPoint()
        self._rows = {}

        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        base_assets = os.path.join(base_dir, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        self._raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
        if self._raw_logo and not self._raw_logo.isNull():
            ldpr = native_dpr(self)
            li = self._raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(li)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()
        self._refresh_counts()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header Bar
        header = QWidget(self)
        header.setFixedHeight(52)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(16, 0, 14, 0)
        hdr.setSpacing(2)
        hdr.addStretch(1)

        self.btn_back = CleanBackButton("Back to Quick Menu", box_size=30, icon_size=15, parent=header)
        self.btn_back.clicked.connect(self._go_back_to_menu)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_close = CleanCloseButton("Close Super Share", box_size=30, icon_size=15, parent=header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        lbl_sec = QLabel("SHARE TOOLS", self)
        lbl_sec.setStyleSheet(
            "color: rgba(255, 255, 255, 0.42); font-size: 8px; font-weight: 700; "
            "letter-spacing: 1.4px; padding-left: 18px; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_sec)
        root.addSpacing(4)

        for idx, item in enumerate(self.ITEMS):
            row = _ShareMenuItemRow(item, idx=idx, parent=self)
            row.clicked.connect(self._on_item_clicked)
            root.addWidget(row)
            self._rows[item["id"]] = row

        root.addStretch(1)

        div2 = QFrame(self)
        div2.setFixedHeight(1)
        div2.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0px 18px;")
        root.addWidget(div2)

        lbl_ver = QLabel("THE SUPERMOUSE v1.01", self)
        lbl_ver.setAlignment(Qt.AlignCenter)
        lbl_ver.setFixedHeight(22)
        lbl_ver.setStyleSheet(
            "color: rgba(255, 255, 255, 0.34); font-size: 8px; font-weight: 600; "
            "letter-spacing: 0.9px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_ver)
        root.addSpacing(4)

    def _refresh_counts(self):
        n = count_stored_share_items()
        if "share_memory_space" in self._rows:
            self._rows["share_memory_space"].set_badge_text(format_count_label(n, "File", "Files"))

    def _go_back_to_menu(self):
        self.switch_out_asmr_animation(on_finished=self.on_back_to_menu)

    def _on_item_clicked(self, item):
        oid = item["id"]
        if oid == "share_device_hub":
            if callable(self.on_open_device):
                self.switch_out_asmr_animation(on_finished=self.on_open_device)
        elif oid == "share_memory_space":
            if callable(self.on_open_stored):
                self.switch_out_asmr_animation(on_finished=self.on_open_stored)
        elif oid == "share_settings":
            if callable(self.on_open_settings):
                self.switch_out_asmr_animation(on_finished=self.on_open_settings)

    def _stop_anims(self):
        self._anim_gen = getattr(self, "_anim_gen", 0) + 1
        for attr in ("anim_in", "anim_out"):
            anim = getattr(self, attr, None)
            if anim is not None:
                try:
                    anim.stop()
                except Exception:
                    pass
        self._is_animating = False

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at cursor/center when switching (no vertical slide)."""
        self._refresh_counts()
        self._stop_anims()

        cur = QCursor.pos()
        screen = QApplication.screenAt(cur) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()
        tx = max(avail.left() + 12, min(avail.right() - w - 12, cur.x() - w // 2))
        ty = max(avail.top() + 14, min(avail.bottom() - h - 14, cur.y() - h // 2))

        for r in self._rows.values():
            r.start_reveal_animation()
            r.show()

        self.setGeometry(QRect(tx, ty, w, h))
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        self._is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        af.finished.connect(lambda: setattr(self, "_is_animating", False))
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        self._stop_anims()
        if not self.isVisible():
            if on_finished:
                on_finished()
            return

        gen = self._anim_gen
        self._is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            if getattr(self, "_anim_gen", 0) != gen:
                return
            self._is_animating = False
            self.hide()
            if on_finished:
                on_finished()

        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def close_with_pull_animation(self, on_finished=None):
        self._stop_anims()
        if not self.isVisible():
            if on_finished:
                on_finished()
            return

        screen = QApplication.screenAt(self.pos()) or QApplication.primaryScreen()
        full = screen.geometry()
        curr = self.geometry()
        end_geom = QRect(curr.x(), full.bottom() + 15, curr.width(), curr.height())

        gen = self._anim_gen
        self._is_animating = True
        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(300)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(270)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)

        def _done():
            if getattr(self, "_anim_gen", 0) != gen:
                return
            self._is_animating = False
            self.hide()
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 52.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        elif e.button() == Qt.RightButton:
            self.close_with_pull_animation()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
            e.accept()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 253))
        p.setPen(QPen(QColor(255, 255, 255, 26), 1.0))
        p.drawPath(card)

        _draw_vector_brand(p, 16.0, 26.0, self.logo_pix, "THE", "SUPER SHARE", font_pt=10.2)
        p.end()
