# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - GLOBAL INPUT TRIGGERS, SYSTEM TRAY & AUTOSTART
================================================================
Dedicated module handling all 3 invocation pathways for SuperMouse Quick Menu:
  1. Global Keyboard Hotkey: Win + Shift + M (works anywhere on Windows)
  2. External Mouse Gesture: Hold Right Button + Fast Left Click x3
  3. Always-On Taskbar Tray Icon (^ Overflow Up Arrow) + Windows Boot Autostart
"""

import os
import sys
import json
import time
import ctypes
import winreg
from ctypes import wintypes

from PySide6.QtCore import QObject, Signal, Qt, QTimer
from PySide6.QtGui import QIcon, QAction, QPainter, QColor, QCursor
from PySide6.QtWidgets import QSystemTrayIcon, QMenu, QApplication, QWidget


def _find_base_dir():
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))
        if os.path.isdir(os.path.join(exe_dir, "thesupermouse", "assets")):
            return exe_dir
        return exe_dir
    cur = os.path.abspath(__file__)
    for _ in range(6):
        cur = os.path.dirname(cur)
        if os.path.isdir(os.path.join(cur, "thesupermouse", "assets")):
            return cur
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_CONFIG_DIR = os.path.join(_find_base_dir(), "thesupermouse", "config")
SETTINGS_PATH = os.path.join(_CONFIG_DIR, "access_settings.json")

DEFAULT_ACCESS_SETTINGS = {
    "hotkey_enabled": True,
    "master_hotkey": "Win+Shift+M",
    "secondary_hotkey": "Ctrl+Alt+A",
    "mouse_combo_enabled": True,
    "touchpad_gesture_enabled": True,
    "selection_theme_enabled": True,
    "autostart_enabled": True,
    "follow_cursor": False,
    "cursor_size": 0,
}


def load_access_settings():
    cfg = dict(DEFAULT_ACCESS_SETTINGS)
    try:
        if os.path.exists(SETTINGS_PATH):
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    return cfg


def save_access_settings(cfg):
    merged = dict(DEFAULT_ACCESS_SETTINGS)
    if isinstance(cfg, dict):
        merged.update(cfg)
    try:
        os.makedirs(_CONFIG_DIR, exist_ok=True)
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(merged, f, indent=2)
    except Exception:
        pass
    return merged


def parse_hotkey_combo(combo_str):
    """Parse human combo string like 'Win+Shift+M' or 'Ctrl+Alt+Space' -> (mods_set, vk_code)."""
    parts = [p.strip() for p in str(combo_str or "").split("+") if p.strip()]
    mods = set()
    main_key = None
    for p in parts:
        up = p.upper()
        if up in ("WIN", "LWIN", "RWIN", "META", "CMD"):
            mods.add("WIN")
        elif up in ("SHIFT", "SHF"):
            mods.add("SHIFT")
        elif up in ("CTRL", "CONTROL"):
            mods.add("CTRL")
        elif up in ("ALT", "MENU"):
            mods.add("ALT")
        else:
            main_key = up
    if not main_key:
        return ({"WIN", "SHIFT"}, 0x4D)
    special = {
        "SPACE": 0x20, "ENTER": 0x0D, "TAB": 0x09, "BACKSPACE": 0x08,
        "F1": 0x70, "F2": 0x71, "F3": 0x72, "F4": 0x73, "F5": 0x74, "F6": 0x75,
        "F7": 0x76, "F8": 0x77, "F9": 0x78, "F10": 0x79, "F11": 0x7A, "F12": 0x7B,
    }
    if main_key in special:
        return (mods, special[main_key])
    if len(main_key) == 1 and ("A" <= main_key <= "Z" or "0" <= main_key <= "9"):
        return (mods, ord(main_key))
    return ({"WIN", "SHIFT"}, 0x4D)


class _GUITHREADINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("hwndActive", wintypes.HWND),
        ("hwndFocus", wintypes.HWND),
        ("hwndCapture", wintypes.HWND),
        ("hwndMenuOwner", wintypes.HWND),
        ("hwndMoveSize", wintypes.HWND),
        ("hwndCaret", wintypes.HWND),
        ("rcCaret", wintypes.RECT),
    ]


class _RightReleaseShield(QWidget):
    """
    Brief non-activating cursor absorber shown ONLY while Right Button is still
    physically held after the 3x Left Click chord triggers. Ensures the real
    WM_RBUTTONUP passes cleanly through Windows (preventing any screen/capture
    freeze) without popping a stray Chrome/Desktop context menu underneath.
    """

    def __init__(self, parent=None):
        super().__init__(
            parent,
            Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.NoDropShadowWindowHint,
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFixedSize(120, 120)
        self._auto_hide = QTimer(self)
        self._auto_hide.setSingleShot(True)
        self._auto_hide.timeout.connect(self.hide)

    def arm_at_cursor(self, duration_ms=420):
        pos = QCursor.pos()
        self.move(pos.x() - 60, pos.y() - 60)
        self.show()
        self.raise_()
        self._auto_hide.start(duration_ms)

    def disarm(self):
        self._auto_hide.stop()
        if self.isVisible():
            self.hide()

    def mouseReleaseEvent(self, e):
        if e.button() in (Qt.RightButton, Qt.LeftButton):
            self.disarm()
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def mousePressEvent(self, e):
        # Never block any user follow-up click
        self.disarm()
        super().mousePressEvent(e)

    def contextMenuEvent(self, e):
        self.disarm()
        e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        # 1/255 alpha makes Windows hit-test this window without any visible tint
        p.fillRect(self.rect(), QColor(0, 0, 0, 1))
        p.end()


class GlobalInputTriggers(QObject):
    """
    Low-level Windows Keyboard (WH_KEYBOARD_LL) + Mouse (WH_MOUSE_LL) interceptor
    plus pynput fallback. Uses QueuedConnection so hook callbacks return immediately
    and never swallow paired hardware mouse-up events.
    """
    triggered = Signal()
    right_released = Signal()

    def __init__(self, callback=None, parent=None):
        super().__init__(parent)
        self.callback = callback
        # CRITICAL: Always QueuedConnection so WH_MOUSE_LL / WH_KEYBOARD_LL returns immediately
        self.triggered.connect(self._handle_trigger, Qt.QueuedConnection)

        self._shield = _RightReleaseShield()
        self.right_released.connect(self._shield.disarm, Qt.QueuedConnection)

        self._installed = False
        self.kb_hook_id = None
        self.ms_hook_id = None
        self._kb_c_proc = None
        self._ms_c_proc = None
        self._pynput_listener = None

        # External mouse combo state: Hold Left + Right Click + Press Tab or S
        # Laptop touchpad combo state: Shift + Win + Fast Double Click/Tap
        self._r_down = False
        self._l_down = False
        self._l_clicks = []
        self._laptop_taps = []
        self._suppress_next_l_up_until = 0.0
        self._combo_active_until = 0.0

        self.settings = load_access_settings()
        self._primary_parsed = parse_hotkey_combo(self.settings.get("master_hotkey", "Win+Shift+M"))

    def reload_settings(self, new_settings=None):
        self.settings = dict(new_settings) if isinstance(new_settings, dict) else load_access_settings()
        self._primary_parsed = parse_hotkey_combo(self.settings.get("master_hotkey", "Win+Shift+M"))

    def _cancel_active_mouse_capture(self):
        """Release any background Win32 mouse capture/drag before opening the menu."""
        try:
            user32 = ctypes.windll.user32
            fg = user32.GetForegroundWindow()
            if fg:
                tid = user32.GetWindowThreadProcessId(fg, None)
                gti = _GUITHREADINFO()
                gti.cbSize = ctypes.sizeof(_GUITHREADINFO)
                if user32.GetGUIThreadInfo(tid, ctypes.byref(gti)):
                    for h in (gti.hwndCapture, gti.hwndActive, fg):
                        if h:
                            user32.PostMessageW(h, 0x001F, 0, 0)  # WM_CANCELMODE
                else:
                    user32.PostMessageW(fg, 0x001F, 0, 0)
        except Exception:
            pass

    def _is_physical_rbutton_down(self):
        try:
            user32 = ctypes.windll.user32
            swapped = user32.GetSystemMetrics(23) != 0  # SM_SWAPBUTTON
            vk_r = 0x01 if swapped else 0x02
            return (user32.GetAsyncKeyState(vk_r) & 0x8000) != 0
        except Exception:
            return self._r_down

    def _is_physical_lbutton_down(self):
        try:
            user32 = ctypes.windll.user32
            swapped = user32.GetSystemMetrics(23) != 0  # SM_SWAPBUTTON
            vk_l = 0x02 if swapped else 0x01
            return (user32.GetAsyncKeyState(vk_l) & 0x8000) != 0
        except Exception:
            return self._l_down

    def _handle_trigger(self):
        self._cancel_active_mouse_capture()
        now = time.monotonic()
        if (self._r_down or self._is_physical_rbutton_down() or self._l_down or self._is_physical_lbutton_down()) and now <= self._combo_active_until:
            self._shield.arm_at_cursor(duration_ms=600)
        else:
            self._shield.disarm()
        if self.callback:
            self.callback()

    def install(self):
        if self._installed:
            return
        self._installed = True

        user32 = ctypes.windll.user32
        WH_KEYBOARD_LL = 13
        WH_MOUSE_LL = 14

        WM_KEYDOWN = 0x0100
        WM_SYSKEYDOWN = 0x0104
        WM_LBUTTONDOWN = 0x0201
        WM_LBUTTONUP = 0x0202
        WM_RBUTTONDOWN = 0x0204
        WM_RBUTTONUP = 0x0205

        VK_SHIFT = 0x10
        VK_LWIN = 0x5B
        VK_RWIN = 0x5C
        VK_M = 0x4D
        VK_A = 0x41
        VK_TAB = 0x09
        VK_S = 0x53
        VK_CONTROL = 0x11
        VK_MENU = 0x12

        class KBDLLHOOKSTRUCT(ctypes.Structure):
            _fields_ = [
                ("vkCode", wintypes.DWORD),
                ("scanCode", wintypes.DWORD),
                ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.c_ulonglong),
            ]

        class MSLLHOOKSTRUCT(ctypes.Structure):
            _fields_ = [
                ("pt", wintypes.POINT),
                ("mouseData", wintypes.DWORD),
                ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.c_ulonglong),
            ]

        HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_longlong, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)

        def _mods_match(req_mods):
            s_dn = (user32.GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0
            w_dn = ((user32.GetAsyncKeyState(VK_LWIN) & 0x8000) != 0) or ((user32.GetAsyncKeyState(VK_RWIN) & 0x8000) != 0)
            c_dn = (user32.GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0
            a_dn = (user32.GetAsyncKeyState(VK_MENU) & 0x8000) != 0
            if "WIN" in req_mods and not w_dn:
                return False
            if "SHIFT" in req_mods and not s_dn:
                return False
            if "CTRL" in req_mods and not c_dn:
                return False
            if "ALT" in req_mods and not a_dn:
                return False
            return bool(req_mods)

        def _kb_proc(nCode, wParam, lParam):
            if nCode >= 0 and (wParam == WM_KEYDOWN or wParam == WM_SYSKEYDOWN):
                try:
                    kbd = ctypes.cast(lParam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                    vk = kbd.vkCode

                    # Chord trigger: Hold Left + Right Click + Press Tab or S
                    if self.settings.get("mouse_combo_enabled", True) and (vk == VK_TAB or vk == VK_S):
                        c_dn = (user32.GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0
                        a_dn = (user32.GetAsyncKeyState(VK_MENU) & 0x8000) != 0
                        w_dn = ((user32.GetAsyncKeyState(VK_LWIN) & 0x8000) != 0) or ((user32.GetAsyncKeyState(VK_RWIN) & 0x8000) != 0)
                        if not (c_dn or a_dn or w_dn):
                            l_held = self._l_down or self._is_physical_lbutton_down()
                            r_held = self._r_down or self._is_physical_rbutton_down()
                            if l_held and r_held:
                                now = time.monotonic()
                                self._combo_active_until = now + 2.0
                                self._suppress_next_l_up_until = now + 0.6
                                self.triggered.emit()
                                return 1

                    if self.settings.get("hotkey_enabled", True):
                        p_mods, p_vk = self._primary_parsed
                        if vk == p_vk and _mods_match(p_mods):
                            self.triggered.emit()
                            return 1

                        # Optional secondary hotkey Ctrl + Alt + A
                        if vk == VK_A and _mods_match({"CTRL", "ALT"}):
                            self.triggered.emit()
                            return 1
                except Exception:
                    pass
            return user32.CallNextHookEx(self.kb_hook_id, nCode, wParam, lParam)

        def _ms_proc(nCode, wParam, lParam):
            if nCode >= 0:
                try:
                    ms = ctypes.cast(lParam, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                    # Ignore synthetic injected mouse events
                    if (ms.flags & 0x01) == 0:
                        if wParam == WM_RBUTTONDOWN:
                            self._r_down = True
                            self._l_clicks.clear()
                        elif wParam == WM_RBUTTONUP:
                            self._r_down = False
                            self._l_clicks.clear()
                            if self._combo_active_until > 0.0:
                                self._combo_active_until = 0.0
                                self.right_released.emit()
                            # CRITICAL: Never swallow WM_RBUTTONUP after passing WM_RBUTTONDOWN!
                            # Always forward it so Windows clears physical VK_RBUTTON & capture.
                        elif wParam == WM_LBUTTONDOWN:
                            self._l_down = True
                            now = time.monotonic()
                            # Laptop shortcut: Shift + Win + Double-Click / Touchpad Double-Tap
                            if self.settings.get("touchpad_gesture_enabled", True):
                                shift_down = (user32.GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0
                                win_down = ((user32.GetAsyncKeyState(VK_LWIN) & 0x8000) != 0) or (
                                    (user32.GetAsyncKeyState(VK_RWIN) & 0x8000) != 0
                                )
                                if shift_down and win_down and not self._r_down:
                                    self._laptop_taps = [t for t in self._laptop_taps if (now - t) <= 0.48]
                                    self._laptop_taps.append(now)
                                    if len(self._laptop_taps) >= 2:
                                        self._laptop_taps.clear()
                                        self._suppress_next_l_up_until = now + 0.45
                                        self.triggered.emit()
                                        return 1
                        elif wParam == WM_LBUTTONUP:
                            self._l_down = False
                            if self._suppress_next_l_up_until > 0.0:
                                suppress = time.monotonic() <= self._suppress_next_l_up_until
                                self._suppress_next_l_up_until = 0.0
                                if suppress:
                                    return 1
                except Exception:
                    pass
            return user32.CallNextHookEx(self.ms_hook_id, nCode, wParam, lParam)

        self._kb_c_proc = HOOKPROC(_kb_proc)
        self._ms_c_proc = HOOKPROC(_ms_proc)

        self.kb_hook_id = user32.SetWindowsHookExW(WH_KEYBOARD_LL, self._kb_c_proc, None, 0)
        self.ms_hook_id = user32.SetWindowsHookExW(WH_MOUSE_LL, self._ms_c_proc, None, 0)

        # Fallback keyboard listener via pynput
        try:
            from pynput import keyboard as pynput_kb
            self._pynput_listener = pynput_kb.GlobalHotKeys({
                "<shift>+<cmd>+m": lambda: self.triggered.emit(),
                "<cmd>+<shift>+m": lambda: self.triggered.emit(),
                "<ctrl>+<alt>+a": lambda: self.triggered.emit(),
            })
            self._pynput_listener.daemon = True
            self._pynput_listener.start()
        except Exception:
            pass

    def uninstall(self):
        if not self._installed:
            return
        self._installed = False
        self._shield.disarm()
        user32 = ctypes.windll.user32
        if self.kb_hook_id:
            try:
                user32.UnhookWindowsHookEx(self.kb_hook_id)
            except Exception:
                pass
            self.kb_hook_id = None
        if self.ms_hook_id:
            try:
                user32.UnhookWindowsHookEx(self.ms_hook_id)
            except Exception:
                pass
            self.ms_hook_id = None
        if self._pynput_listener:
            try:
                self._pynput_listener.stop()
            except Exception:
                pass
            self._pynput_listener = None


class SystemTrayManager(QObject):
    """
    Persistent System Tray icon residing in Windows Taskbar Overflow (^ Up Arrow)
    so SuperMouse Quick Menu is always 1 click away.
    """
    open_menu_requested = Signal()
    open_hud_requested = Signal()
    open_clipboard_requested = Signal()
    open_design_requested = Signal()
    quit_requested = Signal()

    def __init__(self, icon_path, parent=None):
        super().__init__(parent)
        self.tray = QSystemTrayIcon(parent)
        from ui_theme import get_app_icon
        tray_icon = get_app_icon()
        if not tray_icon.isNull():
            self.tray.setIcon(tray_icon)
        elif icon_path and os.path.exists(icon_path):
            self.tray.setIcon(QIcon(icon_path))

        self.tray.setToolTip(
            "THE SUPERMOUSE & SUPERPIN (v1.01)\n"
            "• Click / Right-Click: Quick Menu & SuperPin\n"
            "• Keys: Win + Shift + M\n"
            "• Mouse: Hold L+R Click + Tab or S\n"
            "• Laptop: Shift + Win + 2x Touchpad Tap"
        )

        self.menu = QMenu()
        self.menu.setStyleSheet("""
            QMenu {
                background-color: #0B0C0B;
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 10px;
                padding: 6px;
                font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;
                font-size: 12px;
            }
            QMenu::item {
                padding: 7px 20px;
                border-radius: 6px;
            }
            QMenu::item:selected {
                background-color: rgba(163, 230, 53, 0.16);
                color: #a3e635;
            }
            QMenu::separator {
                height: 1px;
                background: rgba(255, 255, 255, 0.12);
                margin: 4px 10px;
            }
        """)

        act_menu = QAction("Open Quick Menu   (Win+Shift+M)", self.menu)
        act_menu.triggered.connect(self.open_menu_requested.emit)
        self.menu.addAction(act_menu)

        act_hud = QAction("Open Super Edit", self.menu)
        act_hud.triggered.connect(self.open_hud_requested.emit)
        self.menu.addAction(act_hud)

        act_clip = QAction("Open Super Snap & Pin", self.menu)
        act_clip.triggered.connect(self.open_clipboard_requested.emit)
        self.menu.addAction(act_clip)

        act_design = QAction("Open Super Get Design", self.menu)
        act_design.triggered.connect(self.open_design_requested.emit)
        self.menu.addAction(act_design)

        self.menu.addSeparator()

        act_quit = QAction("Exit SuperMouse", self.menu)
        act_quit.triggered.connect(self.quit_requested.emit)
        self.menu.addAction(act_quit)

        self.tray.setContextMenu(self.menu)
        self.tray.activated.connect(self._on_activated)
        self.tray.show()

    def _on_activated(self, reason):
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            self.open_menu_requested.emit()


def ensure_autostart_registered(entry_script_path):
    """
    Registers TheSuperMouseLauncher in Windows HKCU Run registry key
    so the taskbar tray icon and global hotkeys auto-start silently on login (100% offline).
    """
    try:
        if getattr(sys, "frozen", False):
            cmd = f'"{os.path.abspath(sys.executable)}" --supershare --silent'
        else:
            py_exe = sys.executable
            pyw_exe = py_exe.replace("python.exe", "pythonw.exe")
            if os.path.exists(pyw_exe):
                py_exe = pyw_exe
            cmd = f'"{py_exe}" "{os.path.abspath(entry_script_path)}" --supershare --silent'
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "TheSuperMouseLauncher", 0, winreg.REG_SZ, cmd)
        return True
    except Exception:
        return False


def disable_autostart_registered():
    """Remove TheSuperMouseLauncher from HKCU Run registry key."""
    try:
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, "TheSuperMouseLauncher")
        return True
    except Exception:
        return False
