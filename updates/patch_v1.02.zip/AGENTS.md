# BEFOREALL - CRITICAL WORKSPACE EXECUTION RULES

MANDATORY: On every user command, the agent MUST immediately enforce these rules before starting any work:

1. **12x Maximum Blitz Speed (< 1 min execution):** Complete tasks under 1 minute with 12x speed.
2. **Meanwhile Timer & Self-Termination:** 1-2 min hard ceiling for all tasks; if taking even 1 second extra, terminate and improve; tick internally every 5 seconds to beat the clock.
3. **Laser-Focused Execution:** Complete the focused task fast without touching or reading any other files.
4. **Zero Redundant Work & Over-Analyzing:** Do not perform extra reads, wide scans, or over-analysis. Jump directly to the exact target file and line.
3. **Use Codebase Comments & Architecture:** Respect existing comments, layouts, and mindmap without re-evaluating working systems.
4. **Strict Response Format:** Direct responses MUST ALWAYS BE EXACTLY ONE SHORT PARAGRAPH SUMMARY AT ANY COST. No bullet points, no lists, no long answers.
5. **MyDesignRule & BEFOREALL Enforcement:**
   - Always read and strictly enforce design standards in: `D:\THESUPERMOUSE\MyDesignRule.md`
   - Full mandate file: `D:\THESUPERMOUSE\BEFOREALL.md`
