# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - THE SUPER PIN & MY BOX STUDIO
===============================================
Matched 100% to SuperMouseHUD (#040405 OLED matte black, vector Display Bold
typography, circular #101010 close button, boxless Lucide outline rows):
  - SuperClipboardWindow ('THE SUPER PIN'): 4 clean tools (Take Snap, Text Extractor, Store Text, My Box)
  - _SnipOverlay & _SnipResultWindow: Snipping Tool dim + crosshair box -> 4 actions (Re-Take, Copy Image, Save Image, Put in Box)
  - Put in Box: Flies captured image itself into the right screen edge, then pops
    'GOT THE BOX' out from inside the right edge for 3s -> clicking opens MY BOX.
  - MyBoxWindow ('MY BOX'): Pure black showcase window with dynamic real-time search bar
    and ChatGPT-style date grouping (Today, Yesterday, Nov 10, 2026...) pulling images cleanly
    from internal storage without exposing raw folder UI.
"""

import io
import os
import json
import math
import wave
import struct
import random
import ctypes
from datetime import datetime, timedelta

try:
    import winsound
except Exception:
    winsound = None

_ASMR_TICK_WAV = None


def _get_asmr_tick_wav():
    global _ASMR_TICK_WAV
    if _ASMR_TICK_WAV is not None:
        return _ASMR_TICK_WAV
    try:
        sr = 22050
        dur = 0.022
        n = int(sr * dur)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            frames = bytearray()
            for i in range(n):
                t = i / float(sr)
                env = math.exp(-t * 175.0) * min(1.0, i / 12.0)
                freq = 210.0 - 110.0 * (t / dur)
                val = math.sin(2.0 * math.pi * freq * t) + 0.35 * math.sin(2.0 * math.pi * 520.0 * t)
                sample = int(max(-32767, min(32767, val * env * 4200.0)))
                frames.extend(struct.pack("<h", sample))
            wf.writeframes(bytes(frames))
        _ASMR_TICK_WAV = buf.getvalue()
    except Exception:
        _ASMR_TICK_WAV = b""
    return _ASMR_TICK_WAV


def _play_asmr_tick():
    if winsound is None:
        return
    wav = _get_asmr_tick_wav()
    if wav:
        try:
            winsound.PlaySound(wav, winsound.SND_MEMORY | winsound.SND_ASYNC | winsound.SND_NOSTOP)
        except Exception:
            pass

from PySide6.QtSvg import QSvgRenderer
from PySide6.QtCore import (
    Qt, QByteArray, QBuffer, QIODevice, QPoint, QPointF, QRect, QRectF, QSize, QTimer, Signal,
    QPropertyAnimation, QParallelAnimationGroup, QEasingCurve
)
from PySide6.QtGui import (
    QPainter, QPainterPath, QColor, QPen, QBrush,
    QLinearGradient, QPixmap, QCursor, QFont, QFontMetrics, QImage, QIcon
)
from PySide6.QtWidgets import (
    QApplication, QWidget, QFrame, QLabel, QHBoxLayout, QVBoxLayout, QPushButton,
    QScrollArea, QGridLayout, QLineEdit, QDialog, QSlider
)
from ui_theme import (
    COMMON_ICONS,
    SLIM_SCROLLBAR_QSS,
    CleanHeaderIconButton,
    CleanBackButton,
    CleanCloseButton,
    render_common_icon,
    native_dpr,
    format_count_label,
)


def _find_base_dir():
    cur = os.path.abspath(__file__)
    for _ in range(6):
        cur = os.path.dirname(cur)
        if os.path.isdir(os.path.join(cur, "thesupermouse", "assets")):
            return cur
    return r"D:\THESUPERMOUSE\VERSION 1.0"

BASE_DIR = _find_base_dir()
BOX_DIR = os.path.join(BASE_DIR, "thesupermouse", "superclipboard_box")
META_FILE = os.path.join(BOX_DIR, "snaps_meta.json")


def get_desktop_dir():
    """Return actual Windows Desktop path (SHGetFolderPathW CSIDL_DESKTOPDIRECTORY)."""
    try:
        buf = ctypes.create_unicode_buffer(260)
        if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf) == 0 and buf.value:
            if os.path.isdir(buf.value):
                return buf.value
    except Exception:
        pass
    fallback = os.path.join(os.path.expanduser("~"), "Desktop")
    os.makedirs(fallback, exist_ok=True)
    return fallback


def ensure_box_dir():
    os.makedirs(BOX_DIR, exist_ok=True)
    return BOX_DIR


def _load_snap_metadata():
    if not os.path.exists(META_FILE):
        return {}
    try:
        with open(META_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_snap_metadata(meta: dict):
    ensure_box_dir()
    try:
        with open(META_FILE, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def _logical_snap_name(dt: datetime, fp: str) -> str:
    h = dt.hour
    if 5 <= h < 9:
        vibe = "Dawn"
    elif 9 <= h < 12:
        vibe = "Morning"
    elif 12 <= h < 16:
        vibe = "Midday"
    elif 16 <= h < 20:
        vibe = "Evening"
    elif 20 <= h < 24:
        vibe = "Night"
    else:
        vibe = "Midnight"

    shape = "Snap"
    try:
        img = QImage(fp)
        if not img.isNull() and img.height() > 0:
            ratio = img.width() / float(img.height())
            if img.width() < 280 and img.height() < 280:
                shape = "Clip"
            elif ratio >= 1.65:
                shape = "Wide Frame"
            elif ratio >= 1.15:
                shape = "Landscape"
            elif ratio <= 0.78:
                shape = "Portrait"
            else:
                shape = "Square Shot"
    except Exception:
        pass
    return f"{vibe} {shape}"


def _next_seq_from_meta(meta: dict) -> int:
    seq = int(meta.get("__seq__", 0) or 0)
    used_max = max(
        (int(v.get("number", 0)) for k, v in meta.items() if k != "__seq__" and isinstance(v, dict)),
        default=0,
    )
    return max(seq, used_max) + 1


def next_snap_number() -> int:
    meta = _load_snap_metadata()
    if "__seq__" not in meta and os.path.isdir(BOX_DIR):
        list_box_entries()
        meta = _load_snap_metadata()
    return _next_seq_from_meta(meta)


def rename_snap_meta(fp: str, new_name: str):
    key = os.path.basename(fp)
    clean = (new_name or "").strip()[:48]
    if not clean:
        return
    meta = _load_snap_metadata()
    entry = meta.get(key, {})
    if not entry.get("number"):
        seq = _next_seq_from_meta(meta)
        entry["number"] = seq
        meta["__seq__"] = max(int(meta.get("__seq__", 0) or 0), seq)
    entry["name"] = clean
    meta[key] = entry
    _save_snap_metadata(meta)


def save_custom_snap_meta(fp: str, snap_num: int, snap_name: str):
    key = os.path.basename(fp)
    meta = _load_snap_metadata()
    clean = (snap_name or "").strip()[:48] or _logical_snap_name(datetime.now(), fp)
    num = int(snap_num)
    meta[key] = {"number": num, "name": clean}
    meta["__seq__"] = max(int(meta.get("__seq__", 0) or 0), num)
    _save_snap_metadata(meta)


def delete_snap_meta(fp: str):
    key = os.path.basename(fp)
    meta = _load_snap_metadata()
    if key in meta:
        meta.pop(key, None)
        _save_snap_metadata(meta)


def list_box_entries():
    """Fetch stored snap image metadata cleanly sorted newest-first in sequential order (#1, #2, #3...)."""
    if not os.path.isdir(BOX_DIR):
        return []
    meta = _load_snap_metadata()
    meta_dirty = False

    # Collect image files sorted oldest -> newest so first sequential migration assigns #1, #2... chronologically
    files = []
    for fn in os.listdir(BOX_DIR):
        if fn.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".webp")):
            fp = os.path.join(BOX_DIR, fn)
            try:
                mtime = os.path.getmtime(fp)
            except Exception:
                mtime = 0.0
            files.append((mtime, fn, fp))
    files.sort(key=lambda x: x[0])

    # One-time migration if legacy random >999 numbers exist before sequential mode
    if "__seq__" not in meta:
        seq = 0
        for mtime, fn, fp in files:
            seq += 1
            dt = datetime.fromtimestamp(mtime)
            old_rec = meta.get(fn) if isinstance(meta.get(fn), dict) else {}
            meta[fn] = {
                "number": seq,
                "name": str(old_rec.get("name") or _logical_snap_name(dt, fp)),
            }
        meta["__seq__"] = seq
        meta_dirty = True

    entries = []
    for mtime, fn, fp in files:
        dt = datetime.fromtimestamp(mtime)
        rec = meta.get(fn)
        if not isinstance(rec, dict) or not rec.get("number") or not rec.get("name"):
            seq = _next_seq_from_meta(meta)
            rec = {
                "number": seq,
                "name": _logical_snap_name(dt, fp),
            }
            meta[fn] = rec
            meta["__seq__"] = max(int(meta.get("__seq__", 0) or 0), seq)
            meta_dirty = True
        entries.append({
            "path": fp,
            "filename": fn,
            "mtime": mtime,
            "dt": dt,
            "snap_num": int(rec["number"]),
            "snap_name": str(rec["name"]),
        })
    if meta_dirty:
        _save_snap_metadata(meta)
    entries.sort(key=lambda x: x["mtime"], reverse=True)
    return entries


def count_box_items():
    return len(list_box_entries())


def copy_pixmap_to_clipboard(pix, hwnd=None):
    """Copy a QPixmap cleanly onto Windows system clipboard (Qt + Win32 CF_DIB retries)."""
    if not pix or pix.isNull():
        return False
    img = pix.toImage()
    cb = QApplication.clipboard()
    cb.setPixmap(pix)
    cb.setImage(img)
    QApplication.processEvents()
    if not cb.image().isNull():
        return True

    try:
        import time
        ba = QByteArray()
        buf = QBuffer(ba)
        buf.open(QIODevice.WriteOnly)
        img.convertToFormat(QImage.Format_RGB888).save(buf, "BMP")
        buf.close()
        dib_bytes = bytes(ba.data())[14:]
        if dib_bytes:
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
            kernel32.GlobalAlloc.restype = ctypes.c_void_p
            kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalLock.restype = ctypes.c_void_p
            kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
            user32.SetClipboardData.restype = ctypes.c_void_p

            for _ in range(5):
                if user32.OpenClipboard(hwnd):
                    try:
                        user32.EmptyClipboard()
                        hmem = kernel32.GlobalAlloc(0x0002, len(dib_bytes))
                        if hmem:
                            ptr = kernel32.GlobalLock(hmem)
                            if ptr:
                                ctypes.memmove(ptr, dib_bytes, len(dib_bytes))
                                kernel32.GlobalUnlock(hmem)
                                user32.SetClipboardData(8, hmem)
                                return True
                    finally:
                        user32.CloseClipboard()
                time.sleep(0.015)
    except Exception:
        pass
    return False


# Shared Common Lucide 24x24 Outline Vector Icons (100% Unified Across All Windows)
_LUCIDE_PIN_ICONS = {
    **COMMON_ICONS,
    "arrow_left_fill": COMMON_ICONS["back"],
    "home_fill": COMMON_ICONS["home"],
    "grid_fill": COMMON_ICONS["grid"],
    "oneline_fill": COMMON_ICONS["oneline"],
    "scissors_fill": COMMON_ICONS["take_snap"],
    "search_fill": COMMON_ICONS["search"],
    "pencil_fill": COMMON_ICONS["pencil"],
    "copy_fill": COMMON_ICONS["copy"],
    "trash_fill": COMMON_ICONS["trash"],
    "supershare_fill": COMMON_ICONS["supershare"],
    "close_fill": COMMON_ICONS["close"],
    "box_fill": COMMON_ICONS["my_box"],
}


def _native_dpr(widget=None):
    return native_dpr(widget)


def _render_lucide_pix(key, color_hex, size_px=16, dpr=None):
    tpl = _LUCIDE_PIN_ICONS.get(key) or _LUCIDE_PIN_ICONS["copy"]
    return render_common_icon(tpl, color_hex, size_px=size_px, dpr=dpr)


def _draw_crisp_text(p, rect, centered, font, color, text):
    """Render razor-sharp text with native subpixel antialiasing and ClearType font hinting."""
    f = QFont(font)
    f.setStyleStrategy(QFont.PreferQuality)
    p.setFont(f)
    p.setPen(QColor(color))
    flags = (Qt.AlignCenter if centered else (Qt.AlignLeft | Qt.AlignVCenter)) | Qt.TextSingleLine
    p.drawText(rect, flags, text)


def _draw_vector_brand(p, bx, by_c, logo_pix, word1, word2, font_pt=11.0):
    """Render razor-sharp QPainterPath vector brand matching SuperMouseHUD."""
    if logo_pix and not logo_pix.isNull():
        dpr = max(1.0, float(logo_pix.devicePixelRatio() or 1.0))
        lw = logo_pix.width() / dpr
        lh = logo_pix.height() / dpr
        p.drawPixmap(int(round(bx)), int(round(by_c - lh / 2.0)), logo_pix)
        bx += lw + 8.0

    f_logo = QFont("Segoe UI Variable")
    f_logo.setStyleName("Display Bold")
    f_logo.setPointSizeF(font_pt)
    f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
    f_logo.setHintingPreference(QFont.PreferNoHinting)

    probe = QPainterPath()
    probe.addText(0.0, 0.0, f_logo, f"{word1} {word2}")
    br = probe.boundingRect()
    baseline_y = by_c - (br.top() + br.height() * 0.5)

    p1 = QPainterPath()
    p1.addText(bx, baseline_y, f_logo, word1)
    p.fillPath(p1, QColor("#FFFFFF"))

    w1 = p1.boundingRect().width()
    smx = bx + w1 + 5.5
    p2 = QPainterPath()
    p2.addText(smx, baseline_y, f_logo, word2)
    b2 = p2.boundingRect()
    g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
    g_sm.setColorAt(0.0, QColor("#FFFF00"))
    g_sm.setColorAt(1.0, QColor("#00FF85"))
    p.fillPath(p2, g_sm)




class _StatusPopup(QFrame):
    """Pure #050505 Obsidian popup notification matching HUD style."""

    def __init__(self, parent=None):
        super().__init__(None, Qt.ToolTip | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFixedSize(292, 68)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 10, 14, 10)
        lay.setSpacing(11)

        self.ico_lbl = QLabel(self)
        self.ico_lbl.setFixedSize(36, 36)
        self.ico_lbl.setAlignment(Qt.AlignCenter)
        self.ico_lbl.setStyleSheet(
            "background-color: #0E0E0E; border: 1px solid rgba(163, 230, 53, 0.55); border-radius: 18px;"
        )
        lay.addWidget(self.ico_lbl)

        col = QVBoxLayout()
        col.setSpacing(3)
        col.setAlignment(Qt.AlignVCenter)

        self.lbl_title = QLabel("TEXT EXTRACTOR", self)
        self.lbl_title.setStyleSheet(
            "color: #FFFFFF; font-size: 11.5px; font-weight: 700; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
        )
        col.addWidget(self.lbl_title)

        b_row = QHBoxLayout()
        b_row.setContentsMargins(0, 0, 0, 0)
        self.lbl_badge = QLabel("COMING SOON", self)
        self.lbl_badge.setFixedHeight(17)
        self.lbl_badge.setAlignment(Qt.AlignCenter)
        self.lbl_badge.setStyleSheet(
            "color: #a3e635; background-color: #121C10; "
            "border: 1px solid rgba(163, 230, 53, 0.50); border-radius: 5px; "
            "font-size: 8.5px; font-weight: 700; letter-spacing: 0.7px; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; padding: 0px 7px;"
        )
        b_row.addWidget(self.lbl_badge)
        b_row.addStretch()
        col.addLayout(b_row)
        lay.addLayout(col, stretch=1)

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.close)

    def mousePressEvent(self, e):
        self._timer.stop()
        self.close()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        path = QPainterPath()
        path.addRoundedRect(rect, 12.0, 12.0)
        p.fillPath(path, QColor(5, 5, 5, 252))
        p.setPen(QPen(QColor(255, 255, 255, 32), 1.0))
        p.drawPath(path)
        p.end()

    def show_message(self, title, svg_tpl, center_pos, badge_text="COMING SOON", duration_ms=2100):
        self.lbl_title.setText(title)
        self.lbl_badge.setText(badge_text)
        svg_raw = svg_tpl.replace("{col}", "#a3e635")
        pix = QPixmap(18, 18)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        QSvgRenderer(QByteArray(svg_raw.encode("utf-8"))).render(p)
        p.end()
        self.ico_lbl.setPixmap(pix)

        x = center_pos.x() - self.width() // 2
        y = center_pos.y() - self.height() // 2
        screen = QApplication.screenAt(center_pos) or QApplication.primaryScreen()
        if screen:
            ag = screen.availableGeometry()
            x = max(ag.left() + 10, min(ag.right() - self.width() - 10, x))
            y = max(ag.top() + 10, min(ag.bottom() - self.height() - 10, y))
        self.move(x, y)
        self.show()
        self.raise_()
        self._timer.start(duration_ms)


class GotTheBoxEdgePopup(QWidget):
    """
    Minimalist iOS Dynamic-Island style capsule emerging smoothly from bottom-right corner:
      - Sleek 216x52 pill with 2x crisp thumbnail, clean 2-line iOS label & subtle chevron
      - Holds for 3s with smooth OutBack spring slide-in, then glides cleanly back inside
    """

    def __init__(self, on_open_box=None, parent=None):
        super().__init__(
            parent,
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint,
        )
        self.on_open_box = on_open_box
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFixedSize(216, 52)
        self.setCursor(Qt.PointingHandCursor)

        self._thumb_pix = None
        self._screen_geo = None
        self._snap_title = ""
        self._hold_timer = QTimer(self)
        self._hold_timer.setSingleShot(True)
        self._hold_timer.timeout.connect(self.slide_back_inside)

    def show_from_right(self, y_center, saved_path, snap_pix=None, screen=None, snap_label=""):
        self._hold_timer.stop()
        if hasattr(self, "_anim") and self._anim.state() == QParallelAnimationGroup.Running:
            self._anim.stop()

        self._snap_title = str(snap_label or "").strip()
        if snap_pix and not snap_pix.isNull():
            sc = snap_pix.scaled(72, 72, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            sc.setDevicePixelRatio(2.0)
            self._thumb_pix = sc
        else:
            self._thumb_pix = None

        scr = screen or QApplication.primaryScreen()
        full = scr.geometry()
        avail = scr.availableGeometry()
        self._screen_geo = full

        w, h = self.width(), self.height()
        target_y = max(avail.top() + 18, avail.bottom() - h - 22)

        start_geom = QRect(full.right() + 16, target_y, w, h)
        target_geom = QRect(full.right() - w - 16, target_y, w, h)

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(360)
        ag.setStartValue(start_geom)
        ag.setEndValue(target_geom)
        ag.setEasingCurve(QEasingCurve.OutBack)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(240)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self._anim = QParallelAnimationGroup(self)
        self._anim.addAnimation(ag)
        self._anim.addAnimation(af)
        self._anim.finished.connect(lambda: self._hold_timer.start(3000))
        self._anim.start()

    def slide_back_inside(self):
        if not self.isVisible():
            return
        if hasattr(self, "_anim") and self._anim.state() == QParallelAnimationGroup.Running:
            self._anim.stop()

        full = self._screen_geo or QApplication.primaryScreen().geometry()
        curr = self.geometry()
        end_geom = QRect(full.right() + 18, curr.y(), curr.width(), curr.height())

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(280)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(240)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        self._anim = QParallelAnimationGroup(self)
        self._anim.addAnimation(ag)
        self._anim.addAnimation(af)
        self._anim.finished.connect(self.hide)
        self._anim.start()

    def mousePressEvent(self, e):
        self._hold_timer.stop()
        if e.button() == Qt.LeftButton and self.on_open_box:
            self.hide()
            self.on_open_box()
            return
        self.slide_back_inside()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        card = QPainterPath()
        card.addRoundedRect(rect, h * 0.5, h * 0.5)

        # Pure Solid Obsidian Black Card (Zero Navy, Zero Blur, 100% Crisp)
        p.fillPath(card, QColor(0, 0, 0, 255))
        p.setPen(QPen(QColor(255, 255, 255, 42), 1.0))
        p.drawPath(card)

        thumb_rect = QRectF(9.0, (h - 34.0) * 0.5, 34.0, 34.0)
        tp = QPainterPath()
        tp.addRoundedRect(thumb_rect, 17.0, 17.0)
        p.fillPath(tp, QColor(8, 8, 8, 255))
        if self._thumb_pix and not self._thumb_pix.isNull():
            p.save()
            p.setClipPath(tp)
            tx = int(round(thumb_rect.center().x() - self._thumb_pix.width() / (2.0 * self._thumb_pix.devicePixelRatio())))
            ty = int(round(thumb_rect.center().y() - self._thumb_pix.height() / (2.0 * self._thumb_pix.devicePixelRatio())))
            p.drawPixmap(tx, ty, self._thumb_pix)
            p.restore()
        else:
            p.drawPixmap(int(thumb_rect.x() + 9), int(thumb_rect.y() + 9), _render_lucide_pix("my_box", "#a3e635", 16, dpr=2.0))
        p.setPen(QPen(QColor(163, 230, 53, 120), 1.0))
        p.drawPath(tp)

        # Simple 2-line iOS pill text
        f1 = QFont("Segoe UI Variable")
        f1.setStyleName("Text Bold")
        f1.setPointSizeF(9.6)
        f1.setStyleStrategy(QFont.PreferAntialias | QFont.NoSubpixelAntialias)
        p.setFont(f1)
        p.setPen(QColor("#FFFFFF"))
        p.drawText(QRect(52, 8, int(w - 78), 18), Qt.AlignVCenter | Qt.AlignLeft, "Got the Box")

        short_sub = self._snap_title.split("·")[0].strip() if self._snap_title else "My Box"
        sub = f"{short_sub} · Saved" if short_sub else "Saved"
        f2 = QFont("Segoe UI Variable")
        f2.setStyleName("Text Semibold")
        f2.setPointSizeF(7.8)
        f2.setStyleStrategy(QFont.PreferAntialias | QFont.NoSubpixelAntialias)
        p.setFont(f2)
        p.setPen(QColor(163, 230, 53, 220))
        p.drawText(QRect(52, 26, int(w - 78), 16), Qt.AlignVCenter | Qt.AlignLeft, sub)

        # Subtle iOS right chevron
        chev_svg = (
            '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" '
            'fill="none" stroke="#9CA3AF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'
            '<path d="m9 18 6-6-6-6"/></svg>'
        )
        QSvgRenderer(QByteArray(chev_svg.encode("utf-8"))).render(p, QRectF(w - 22.0, (h - 12.0) * 0.5, 12.0, 12.0))
        p.end()


class _FlyingSnapImage(QWidget):
    """Always flies the snapped image smoothly into the bottom-right corner above taskbar."""

    def __init__(self, parent=None):
        super().__init__(
            parent,
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint,
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self._pix = None

    def fly_into_right_edge(self, snap_pix, start_global_rect, screen, on_fully_inside):
        self._pix = snap_pix
        scr = screen or QApplication.primaryScreen()
        full = scr.geometry()
        avail = scr.availableGeometry()

        sw = max(72, start_global_rect.width())
        sh = max(48, start_global_rect.height())
        start_rect = QRect(start_global_rect.x(), start_global_rect.y(), sw, sh)

        aspect = sw / max(1.0, float(sh))
        end_w = max(72, min(116, int(sw * 0.35)))
        end_h = max(44, min(86, int(end_w / max(0.4, aspect))))
        # Consistently dock in bottom-right corner just above taskbar slightly upwards
        end_y = max(avail.top() + 24, avail.bottom() - end_h - 34)
        end_rect = QRect(full.right() + 22, end_y, end_w, end_h)

        self.setGeometry(start_rect)
        self.setWindowOpacity(1.0)
        self.show()
        self.raise_()

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(420)
        ag.setStartValue(start_rect)
        ag.setEndValue(end_rect)
        ag.setEasingCurve(QEasingCurve.InOutCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(410)
        af.setStartValue(1.0)
        af.setEndValue(0.88)
        af.setEasingCurve(QEasingCurve.InQuad)

        self._anim = QParallelAnimationGroup(self)
        self._anim.addAnimation(ag)
        self._anim.addAnimation(af)

        def _done():
            self.hide()
            if on_fully_inside:
                on_fully_inside(end_y + end_h // 2)

        self._anim.finished.connect(_done)
        self._anim.start()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        path = QPainterPath()
        path.addRoundedRect(rect, 9.0, 9.0)

        p.save()
        p.setClipPath(path)
        if self._pix and not self._pix.isNull():
            p.drawPixmap(rect.toRect(), self._pix)
        p.restore()

        p.setPen(QPen(QColor("#a3e635"), 1.6))
        p.drawPath(path)
        p.end()


class _ActionPillButton(QWidget):
    """Minimalist iOS action pill: sleek matte obsidian secondary or signature lime CTA."""
    clicked = Signal()

    def __init__(self, label, svg_tpl, primary=False, compact=False, parent=None):
        super().__init__(parent)
        self.label = label
        self.svg_tpl = svg_tpl
        self.primary = primary
        self.compact = compact
        self.setFixedHeight(28 if compact else 32)
        self.setCursor(Qt.PointingHandCursor)

        f = QFont("Segoe UI Variable")
        f.setStyleName("Display Bold" if primary else "Text Semibold")
        f.setPointSizeF(8.3 if compact else 8.6)
        tw = QFontMetrics(f).horizontalAdvance(label)
        self.setFixedWidth(max(72 if compact else 82, tw + (40 if compact else 44)))

        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def _step(self):
        active = False
        if abs(self._target - self._h) >= 0.008:
            self._h += (self._target - self._h) * 0.25
            active = True
        else:
            self._h = self._target
        if self._press > 0.01:
            self._press *= 0.80
            active = True
        else:
            self._press = 0.0
        self.update()
        if not active:
            self._timer.stop()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            self.clicked.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h
        sc = 1.0 - self._press * 0.04

        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        path = QPainterPath()
        path.addRoundedRect(rect, 8.5, 8.5)

        if self.primary:
            fill_c = QColor(int(163 + hv * 25), int(230 + hv * 18), int(53 + hv * 12), 255)
            p.fillPath(path, fill_c)
            col_hex = "#070907"
            txt_col = QColor("#070907")
        else:
            bg = QColor(int(18 + hv * 12), int(19 + hv * 12), int(23 + hv * 13), 255)
            p.fillPath(path, bg)
            p.setPen(QPen(QColor(255, 255, 255, int(22 + hv * 36)), 1.0))
            p.drawPath(path)
            col_hex = "#FFFFFF" if hv > 0.35 else "#D4D4D8"
            txt_col = QColor("#FFFFFF") if hv > 0.35 else QColor("#E4E4E7")

        isz = 13.5 if self.compact else 14.0
        px = 10.0 if self.compact else 11.0
        pix = render_common_icon(self.svg_tpl, col_hex, int(round(isz)), dpr=native_dpr(self))
        p.drawPixmap(int(round(px)), int(round((h - isz) * 0.5)), pix)

        f = QFont("Segoe UI Variable")
        f.setStyleName("Display Bold" if self.primary else "Text Semibold")
        f.setPointSizeF(8.3 if self.compact else 8.6)
        _draw_crisp_text(p, QRectF(px + isz + 6.0, 0.0, w - (px + isz + 14.0), h), False, f, txt_col, self.label)
        p.restore()
        p.end()




class _CloseCircleBtn(CleanCloseButton):
    """Unified borderless common Cross ('X') close button across SuperPin/MyBox."""

    def __init__(self, tip="Close", parent=None):
        super().__init__(tip=tip, box_size=30, icon_size=15, parent=parent)


# ──────────────────────────────────────────────────────────────────────────────
#  MY BOX - BLACK SHOWCASE GALLERY (ChatGPT-Style Dates + Dynamic Search)
# ──────────────────────────────────────────────────────────────────────────────



__all__ = [k for k in list(globals().keys()) if not k.startswith('__')]
