# -*- coding: utf-8 -*-
from .common import *
from .take_snap import _SnipOverlay
from .markup_editor import _SnipResultWindow
from .pin_window import _PinLightboxDialog
from .my_box import MyBoxWindow
class _PinMenuItemRow(QWidget):
    """Boxless row matched 1:1 to Quick Menu V6 (Lucide outline + dual hover personality)."""
    clicked = Signal(dict)

    def __init__(self, item_data, idx=0, parent=None):
        super().__init__(parent)
        self.item = item_data
        self.idx = idx
        self._badge_override = None
        self.setFixedHeight(36)
        self.setCursor(Qt.PointingHandCursor)

        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self._shimmer = -0.25
        self._reveal = 1.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def set_badge_text(self, txt):
        self._badge_override = txt
        self.update()

    def start_reveal_animation(self):
        self._reveal = 1.0
        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self.update()

    def _begin_reveal(self):
        self._reveal = 1.0
        self.update()

    def _step(self):
        active = False
        if self._reveal < 1.0:
            self._reveal = min(1.0, self._reveal + 0.11)
            active = True
        if abs(self._target - self._h) >= 0.005:
            self._h += (self._target - self._h) * 0.23
            active = True
        elif self._h != self._target:
            self._h = self._target
        if self._press > 0.01:
            self._press *= 0.80
            active = True
        else:
            self._press = 0.0

        is_soon = bool(self.item.get("coming_soon"))
        if is_soon and (self._target > 0.0 or self._h > 0.02):
            self._shimmer += 0.011
            if self._shimmer > 1.35:
                self._shimmer = -0.25
            active = True
        elif is_soon:
            self._shimmer = -0.25

        self.update()
        if not active and self._reveal >= 1.0 and self._h == self._target and self._press == 0.0:
            self._timer.stop()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            self.clicked.emit(self.item)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        rev = self._reveal
        if rev <= 0.01:
            p.end()
            return

        w, h = float(self.width()), float(self.height())
        hv = self._h
        is_soon = bool(self.item.get("coming_soon"))
        badge_text = self._badge_override if self._badge_override is not None else self.item.get("badge")
        sc = 1.0 - self._press * 0.016

        p.save()
        p.setOpacity(rev)
        p.translate(0.0, (1.0 - rev) * 7.0)
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        pill_rect = QRectF(10.0, 1.5, w - 20.0, h - 3.0)
        pill_path = QPainterPath()
        pill_path.addRoundedRect(pill_rect, 8.5, 8.5)

        if not is_soon:
            if hv > 0.008:
                p.fillPath(pill_path, QColor(18, 26, 15, int(235 * hv)))
                p.setPen(QPen(QColor(163, 230, 53, int(175 * hv)), 1.1))
                p.drawPath(pill_path)

                bar_h = 16.0 * hv
                bp = QPainterPath()
                bp.addRoundedRect(QRectF(10.0, (h - bar_h) * 0.5, 2.5, bar_h), 1.25, 1.25)
                p.fillPath(bp, QColor(163, 230, 53, int(245 * hv)))

            r_c = int(228 * (1.0 - hv) + 163 * hv)
            g_c = int(228 * (1.0 - hv) + 230 * hv)
            b_c = int(231 * (1.0 - hv) + 53 * hv)
            col_hex = f"#{r_c:02x}{g_c:02x}{b_c:02x}"

            ico_s = 16.0
            QSvgRenderer(QByteArray(self.item["svg"].replace("{col}", col_hex).encode("utf-8"))).render(
                p, QRectF(18.0 + hv * 2.5, (h - ico_s) * 0.5, ico_s, ico_s)
            )

            f = QFont("Segoe UI Variable")
            f.setStyleName("Text Semibold" if hv < 0.45 else "Display Bold")
            f.setPointSizeF(9.6)
            text_x = 44.0 + hv * 3.0
            right_m = 72.0 if badge_text else 20.0
            _draw_crisp_text(
                p, QRectF(text_x, 0.0, w - text_x - right_m, h), False, f,
                QColor("#FFFFFF") if hv > 0.3 else QColor("#EDEDEF"), self.item["label"],
            )

            if badge_text:
                pw, ph = 58.0, 15.5
                pr = QRectF(w - 18.0 - pw, (h - ph) * 0.5, pw, ph)
                pp = QPainterPath()
                pp.addRoundedRect(pr, 4.5, 4.5)
                p.fillPath(pp, QColor(163, 230, 53, int(18 + hv * 18)) if hv > 0.2 else QColor(255, 255, 255, 10))
                p.setPen(QPen(QColor(163, 230, 53, int(65 + hv * 95)) if hv > 0.2 else QColor(255, 255, 255, 24), 0.8))
                p.drawPath(pp)
                pf = QFont("Segoe UI Variable")
                pf.setStyleName("Display Bold")
                pf.setPointSizeF(5.6)
                pf.setLetterSpacing(QFont.AbsoluteSpacing, 0.3)
                _draw_crisp_text(p, pr, True, pf, QColor("#a3e635") if hv > 0.2 else QColor("#A1A7B3"), badge_text)
        else:
            if hv > 0.008:
                p.fillPath(pill_path, QColor(255, 255, 255, int(11 * hv)))
                p.setPen(QPen(QColor(255, 255, 255, int(28 * hv)), 0.9))
                p.drawPath(pill_path)

            v_ico = int(146 + hv * 58)
            col_hex = f"#{v_ico:02x}{v_ico:02x}{min(255, v_ico + 5):02x}"
            QSvgRenderer(QByteArray(self.item["svg"].replace("{col}", col_hex).encode("utf-8"))).render(
                p, QRectF(18.0, (h - 15.5) * 0.5, 15.5, 15.5)
            )

            f = QFont("Segoe UI Variable")
            f.setStyleName("Text Semibold")
            f.setPointSizeF(9.4)
            v_txt = int(172 + hv * 48)
            _draw_crisp_text(p, QRectF(44.0, 0.0, w - 44.0 - 84.0, h), False, f, QColor(v_txt, v_txt, v_txt + 4), self.item["label"])

            pill_w, pill_h = 62.0, 15.5
            pr = QRectF(w - 18.0 - pill_w, (h - pill_h) * 0.5, pill_w, pill_h)
            pp = QPainterPath()
            pp.addRoundedRect(pr, 4.5, 4.5)
            p.fillPath(pp, QColor(255, 255, 255, int(8 + hv * 8)))

            beam = self._shimmer
            if hv > 0.02:
                p.save()
                p.setClipPath(pp)
                sh_grad = QLinearGradient(pr.left(), pr.top(), pr.right(), pr.bottom())
                c0, c1, c2 = max(0.0, min(1.0, beam - 0.28)), max(0.0, min(1.0, beam)), max(0.0, min(1.0, beam + 0.28))
                sh_grad.setColorAt(0.0, QColor(255, 255, 255, 0))
                if c0 > 0.0:
                    sh_grad.setColorAt(c0, QColor(255, 255, 255, 0))
                sh_grad.setColorAt(c1, QColor(255, 255, 255, int(52 * hv)))
                if c2 < 1.0:
                    sh_grad.setColorAt(c2, QColor(255, 255, 255, 0))
                sh_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
                p.fillRect(pr, sh_grad)
                p.restore()

            p.setPen(QPen(QColor(255, 255, 255, int(20 + hv * 32)), 0.8))
            p.drawPath(pp)

            pf = QFont("Segoe UI Variable")
            pf.setStyleName("Display Bold")
            pf.setPointSizeF(5.5)
            pf.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
            p.setFont(pf)
            if hv > 0.02:
                tg = QLinearGradient(pr.left(), 0.0, pr.right(), 0.0)
                base_t, peak_t = QColor(142, 146, 154), QColor(255, 255, 255)
                tg.setColorAt(0.0, base_t)
                c0, c1, c2 = max(0.0, min(1.0, beam - 0.26)), max(0.0, min(1.0, beam)), max(0.0, min(1.0, beam + 0.26))
                if c0 > 0.0:
                    tg.setColorAt(c0, base_t)
                tg.setColorAt(c1, peak_t)
                if c2 < 1.0:
                    tg.setColorAt(c2, base_t)
                tg.setColorAt(1.0, base_t)
                p.setPen(QPen(QBrush(tg), 1.0))
            else:
                p.setPen(QColor(134, 138, 146))
            p.drawText(pr, Qt.AlignCenter, "COMING SOON")

        p.restore()
        p.end()


class SuperClipboardWindow(QWidget):
    """
    THE SUPER PIN 4-Item Hub Window (Image-1 / V6 Pure #040405 Style) + Orchestrator
    for Take Snap & My Box Window.
    """

    ITEMS = [
        {"id": "take_snap",      "label": "Take Snap",      "coming_soon": False, "badge": None,          "svg": _LUCIDE_PIN_ICONS["take_snap"]},
        {"id": "text_extractor", "label": "Text Extractor", "coming_soon": True,  "badge": "COMING SOON", "svg": _LUCIDE_PIN_ICONS["text_extractor"]},
        {"id": "store_text",     "label": "Store Text",     "coming_soon": True,  "badge": "COMING SOON", "svg": _LUCIDE_PIN_ICONS["store_text"]},
        {"id": "my_box",         "label": "My Box",         "coming_soon": False, "badge": "0 SAVED",     "svg": _LUCIDE_PIN_ICONS["my_box"]},
    ]

    def __init__(self, on_back_to_menu=None, parent=None):
        super().__init__(parent)
        self.on_back_to_menu = on_back_to_menu
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(316, 252)
        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - Super Snap & Pin")

        ensure_box_dir()
        self._dragging = False
        self._is_animating = False
        self._drag_offset = QPoint()
        self._rows = {}

        self.status_popup = _StatusPopup()
        self.my_box_window = MyBoxWindow(
            status_popup=self.status_popup,
            on_count_changed=self._refresh_box_count,
            on_back=self.open_asmr_switch,
            on_main_menu=lambda: self.on_back_to_menu() if self.on_back_to_menu else self.open_asmr_switch(),
            on_take_snap=self._start_snip_capture,
        )
        self.edge_popup = GotTheBoxEdgePopup(on_open_box=self.open_my_box_asmr)
        self.snip_overlay = _SnipOverlay()
        self.snip_result = _SnipResultWindow(
            self.status_popup,
            self.edge_popup,
            on_box_updated=self._on_box_saved,
            on_back=self.open_asmr_switch,
            on_main_menu=lambda: self.on_back_to_menu() if self.on_back_to_menu else self.open_asmr_switch(),
        )
        self.snip_overlay.snipped.connect(self.snip_result.show_snap)
        self.snip_overlay.cancelled.connect(self.open_asmr_switch)
        self.snip_result.retake_requested.connect(self._start_snip_capture)

        base_assets = os.path.join(BASE_DIR, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        self._raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
        if self._raw_logo and not self._raw_logo.isNull():
            ldpr = _native_dpr(self)
            li = self._raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(li)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()
        self._refresh_box_count()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Seamless Header (y_c = 26)
        header = QWidget(self)
        header.setFixedHeight(52)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(16, 0, 14, 0)
        hdr.setSpacing(2)
        hdr.addStretch(1)

        self.btn_back = CleanBackButton("Back to Quick Menu", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_back.clicked.connect(self._go_back_to_menu)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_close = _CloseCircleBtn("Close Super Snap & Pin", header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        lbl_sec = QLabel("SNAP TOOLS", self)
        lbl_sec.setStyleSheet(
            "color: rgba(255, 255, 255, 0.42); font-size: 8px; font-weight: 700; "
            "letter-spacing: 1.4px; padding-left: 18px; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_sec)
        root.addSpacing(4)

        for idx, item in enumerate(self.ITEMS):
            row = _PinMenuItemRow(item, idx=idx, parent=self)
            row.clicked.connect(self._on_item_clicked)
            root.addWidget(row)
            self._rows[item["id"]] = row

        root.addStretch(1)

        div2 = QFrame(self)
        div2.setFixedHeight(1)
        div2.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0px 18px;")
        root.addWidget(div2)

        lbl_ver = QLabel("THE SUPERMOUSE v1.02", self)
        lbl_ver.setAlignment(Qt.AlignCenter)
        lbl_ver.setFixedHeight(22)
        lbl_ver.setStyleSheet(
            "color: rgba(255, 255, 255, 0.34); font-size: 8px; font-weight: 600; "
            "letter-spacing: 0.9px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_ver)
        root.addSpacing(4)

    def _on_box_saved(self):
        self._refresh_box_count()
        if self.my_box_window.isVisible():
            self.my_box_window.refresh_gallery()

    def _refresh_box_count(self):
        n = count_box_items()
        if "my_box" in self._rows:
            self._rows["my_box"].set_badge_text(format_count_label(n, "Snap", "Snaps"))

    def _go_back_to_menu(self):
        self.switch_out_asmr_animation(on_finished=self.on_back_to_menu)

    def _start_snip_capture(self):
        self.snip_overlay.begin_snip()

    def start_snap_directly(self):
        """Invoke Take Snap cleanly from Quick Menu submenu without showing the 4-item window."""
        if self.isVisible():
            self.switch_out_asmr_animation(on_finished=lambda: QTimer.singleShot(55, self._start_snip_capture))
        else:
            QTimer.singleShot(55, self._start_snip_capture)

    def open_my_box(self):
        """Open pure-black MY BOX showcase window cleanly."""
        self.my_box_window.open_window()

    def open_my_box_asmr(self):
        """Open MY BOX with smooth ASMR transition when switching from options."""
        self.my_box_window.open_asmr_switch()

    def _on_item_clicked(self, item):
        oid = item["id"]
        center_pos = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        if oid == "take_snap":
            self.switch_out_asmr_animation(
                on_finished=lambda: QTimer.singleShot(55, self._start_snip_capture)
            )
        elif oid == "my_box":
            self.switch_out_asmr_animation(on_finished=self.open_my_box_asmr)
        else:
            self.status_popup.show_message(
                item["label"].upper(),
                item["svg"],
                center_pos,
                badge_text="COMING SOON",
                duration_ms=2100,
            )

    def _stop_anims(self):
        self._anim_gen = getattr(self, "_anim_gen", 0) + 1
        for attr in ("anim_in", "anim_out"):
            anim = getattr(self, attr, None)
            if anim is not None:
                try:
                    anim.stop()
                except Exception:
                    pass
        self._is_animating = False

    def open_at_cursor(self):
        self.open_with_spring_animation()

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at cursor when switching with Quick Menu (no vertical slide)."""
        self._refresh_box_count()
        self._stop_anims()

        cur = QCursor.pos()
        screen = QApplication.screenAt(cur) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()
        tx = max(avail.left() + 12, min(avail.right() - w - 12, cur.x() - w // 2))
        ty = max(avail.top() + 14, min(avail.bottom() - h - 14, cur.y() - h // 2))

        for r in self._rows.values():
            r.start_reveal_animation()
            r.show()

        self.setGeometry(QRect(tx, ty, w, h))
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        self._is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        af.finished.connect(lambda: setattr(self, "_is_animating", False))
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        """Quick, silky normal fade-out back to Cursor Menu (no vertical bounce)."""
        self._stop_anims()
        if not self.isVisible():
            if on_finished:
                on_finished()
            return

        gen = self._anim_gen
        self._is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            if getattr(self, "_anim_gen", 0) != gen:
                return
            self._is_animating = False
            self.hide()
            if on_finished:
                on_finished()

        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def open_with_spring_animation(self):
        self._refresh_box_count()
        self._stop_anims()

        cur = QCursor.pos()
        screen = QApplication.screenAt(cur) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        full = screen.geometry()

        w, h = self.width(), self.height()
        target_x = max(avail.left() + 12, min(avail.right() - w - 12, cur.x() - w // 2))
        target_y = max(avail.top() + 14, min(avail.bottom() - h - 14, cur.y() - h // 2))

        target_geom = QRect(target_x, target_y, w, h)
        start_geom = QRect(target_x, full.bottom() + 15, w, h)

        for r in self._rows.values():
            r.start_reveal_animation()
            r.show()

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        self._is_animating = True
        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(380)
        ag.setStartValue(start_geom)
        ag.setEndValue(target_geom)
        ag.setEasingCurve(QEasingCurve.OutCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(320)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in = QParallelAnimationGroup(self)
        self.anim_in.addAnimation(ag)
        self.anim_in.addAnimation(af)
        self.anim_in.finished.connect(lambda: setattr(self, "_is_animating", False))
        self.anim_in.start()

    def close_with_pull_animation(self, on_finished=None):
        self._stop_anims()
        if not self.isVisible():
            if on_finished:
                on_finished()
            return

        screen = QApplication.screenAt(self.pos()) or QApplication.primaryScreen()
        full = screen.geometry()
        curr = self.geometry()
        end_geom = QRect(curr.x(), full.bottom() + 15, curr.width(), curr.height())

        gen = self._anim_gen
        self._is_animating = True
        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(300)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(270)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)

        def _done():
            if getattr(self, "_anim_gen", 0) != gen:
                return
            self._is_animating = False
            self.hide()
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 52.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        elif e.button() == Qt.RightButton:
            self.close_with_pull_animation()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
            e.accept()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 253))
        p.setPen(QPen(QColor(255, 255, 255, 26), 1.0))
        p.drawPath(card)

        _draw_vector_brand(p, 16.0, 26.0, self.logo_pix, "THE", "SUPER SNAP & PIN", font_pt=10.2)
        p.end()
