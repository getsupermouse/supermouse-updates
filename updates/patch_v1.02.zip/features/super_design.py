# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - SUPERSUPDESIGN STUDIO
=======================================
Obsidian & Cyber-Lime Custom Folder / Files / Cursor Styling Workspace:
  - Upwards Tabs (ALL 3 WORKING):
      * Folder: Style any Windows folder with curated/uploaded artwork (.ico + desktop.ini + SHChangeNotify)
                plus Reset Folder to restore native Windows folder appearance.
      * Files:  Create custom-icon Windows Shortcuts (.lnk) on Desktop for any file, PDF, app, or game.
      * Cursor: Switch live Windows mouse cursors between 5 curated cursor themes (Cyber Lime, Electric Cyan,
                Crimson Flame, Stealth Frost, Windows Default).
  - Native 1:1 DPR QImage thumbnails & Heroicons/Solar/Phosphor filled SVGs + vector-path text (zero blur).
  - Live ASMR search bar, Drag & Drop image uploads, and smooth ASMR navigation back to Quick Menu.
"""

import io
import os
import sys
import struct
import ctypes
import shutil
import subprocess
import winreg
from ctypes import wintypes
from datetime import datetime
from PIL import Image, ImageDraw

try:
    import winsound
except Exception:
    winsound = None

from PySide6.QtSvg import QSvgRenderer
from PySide6.QtCore import (
    Qt, QByteArray, QBuffer, QIODevice, QPoint, QPointF, QRect, QRectF, QSize, QTimer, Signal,
    QPropertyAnimation, QParallelAnimationGroup, QEasingCurve, QUrl
)
from PySide6.QtGui import (
    QPainter, QPainterPath, QColor, QPen, QBrush,
    QLinearGradient, QRadialGradient, QPixmap, QImage, QCursor, QFont, QFontMetrics,
    QDesktopServices, QIcon
)
from PySide6.QtWidgets import (
    QApplication, QWidget, QFrame, QLabel, QHBoxLayout, QVBoxLayout, QPushButton,
    QScrollArea, QGridLayout, QFileDialog, QStackedWidget, QLineEdit
)
from ui_theme import (
    COMMON_ICONS,
    SLIM_SCROLLBAR_QSS,
    CleanHeaderIconButton,
    CleanCloseButton,
    render_common_icon,
    native_dpr,
    format_count_label,
)


def _find_base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    cur = os.path.abspath(__file__)
    for _ in range(6):
        cur = os.path.dirname(cur)
        if os.path.isdir(os.path.join(cur, "thesupermouse", "assets")):
            return cur
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE_DIR = _find_base_dir()
DESIGN_ROOT = os.path.join(BASE_DIR, "thesupermouse", "folder_designs")
PRESET_DIR = os.path.join(DESIGN_ROOT, "presets")
FILE_PRESET_DIR = os.path.join(DESIGN_ROOT, "file_presets")
UPLOAD_DIR = os.path.join(DESIGN_ROOT, "uploaded")
SHORTCUT_ICO_DIR = os.path.join(DESIGN_ROOT, "shortcuts")
CURSOR_PACK_DIR = os.path.join(DESIGN_ROOT, "cursor_packs")
SRC_CURSORS_DIR = os.path.join(BASE_DIR, "thesupermouse", "assets", "cursors")

SUPPORTED_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".ico", ".svg")


_ASMR_TICK_WAV = None


def _get_asmr_tick_wav():
    global _ASMR_TICK_WAV
    if _ASMR_TICK_WAV is not None:
        return _ASMR_TICK_WAV
    try:
        import math
        import wave
        sr = 22050
        dur = 0.020
        n = int(sr * dur)
        frames = bytearray()
        for i in range(n):
            t = i / sr
            env = math.exp(-t * 175.0)
            s = (math.sin(2.0 * math.pi * 1950.0 * t) * 0.55 + math.sin(2.0 * math.pi * 3400.0 * t) * 0.25) * env
            v = max(-32767, min(32767, int(s * 5400)))
            frames += struct.pack("<h", v)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            wf.writeframes(bytes(frames))
        _ASMR_TICK_WAV = buf.getvalue()
        return _ASMR_TICK_WAV
    except Exception:
        _ASMR_TICK_WAV = b""
        return b""


def _play_asmr_tick():
    if winsound is None:
        return
    wav = _get_asmr_tick_wav()
    if wav:
        try:
            winsound.PlaySound(wav, winsound.SND_MEMORY | winsound.SND_ASYNC | winsound.SND_NOSTOP)
        except Exception:
            pass


# Shared Common Lucide 24x24 Outline Vector Icons (100% Unified Across All Windows)
_PH_DESIGN_ICONS = {
    **COMMON_ICONS,
    "arrow_left_fill": COMMON_ICONS["back"],
    "home_fill": COMMON_ICONS["home"],
    "search_fill": COMMON_ICONS["search"],
    "close_fill": COMMON_ICONS["close"],
    "arrow_right_fill": COMMON_ICONS["arrow_right"],
    "reset_fill": COMMON_ICONS["reset"],
}


class _SHFOLDERCUSTOMSETTINGS(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("dwMask", wintypes.DWORD),
        ("pvid", ctypes.c_void_p),
        ("pszWebViewTemplate", wintypes.LPWSTR),
        ("cchWebViewTemplate", wintypes.DWORD),
        ("pszWebViewTemplateVersion", wintypes.LPWSTR),
        ("pszInfoTip", wintypes.LPWSTR),
        ("cchInfoTip", wintypes.DWORD),
        ("pclsid", ctypes.c_void_p),
        ("dwFlags", wintypes.DWORD),
        ("pszIconFile", wintypes.LPWSTR),
        ("cchIconFile", wintypes.DWORD),
        ("iIconIndex", ctypes.c_int),
        ("pszLogo", wintypes.LPWSTR),
        ("cchLogo", wintypes.DWORD),
    ]


CURSOR_PACKS = []


def ensure_design_dirs():
    for d in (PRESET_DIR, FILE_PRESET_DIR, UPLOAD_DIR, SHORTCUT_ICO_DIR, CURSOR_PACK_DIR):
        os.makedirs(d, exist_ok=True)


def get_active_cursor_pack_id():
    """Detect currently active cursor theme from Windows Registry HKCU\\Control Panel\\Cursors."""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Cursors") as k:
            scheme, _ = winreg.QueryValueEx(k, "")
            s_low = str(scheme or "").lower()
            for pk in CURSOR_PACKS:
                if pk["name"].lower() in s_low:
                    return pk["id"]
            if "aero" in s_low or "windows default" in s_low or not s_low:
                arrow, _ = winreg.QueryValueEx(k, "Arrow")
                if "cyber" in str(arrow).lower() or "supermouse" in str(arrow).lower():
                    return "cyber_lime"
                for pk in CURSOR_PACKS:
                    if pk["id"] in str(arrow).lower():
                        return pk["id"]
                return "windows_default"
    except Exception:
        pass
    return "windows_default"


def get_desktop_dir():
    try:
        buf = ctypes.create_unicode_buffer(260)
        if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf) == 0 and buf.value:
            if os.path.isdir(buf.value):
                return buf.value
    except Exception:
        pass
    return os.path.expanduser("~")


def _native_dpr(widget=None):
    try:
        if widget is not None:
            d = float(widget.devicePixelRatioF())
            if d > 0.5:
                return d
        scr = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        if scr is not None:
            return max(1.0, float(scr.devicePixelRatio()))
    except Exception:
        pass
    return 1.0


def _render_svg_icon(svg_tpl, color_hex, size_px=15, dpr=None):
    if dpr is None:
        dpr = _native_dpr()
    svg = svg_tpl.replace("{col}", color_hex)
    px = max(1, int(round(size_px * dpr)))
    pix = QPixmap(px, px)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setRenderHint(QPainter.SmoothPixmapTransform, True)
    QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(p)
    p.end()
    pix.setDevicePixelRatio(dpr)
    return pix


def _draw_crisp_text(p, rect, centered, font, color, text):
    """Fill glyph vector paths cleanly so Windows ClearType never drops stems on dark OLED."""
    f = QFont(font)
    f.setHintingPreference(QFont.PreferNoHinting)
    fm = QFontMetrics(f)
    tx = (rect.center().x() - fm.horizontalAdvance(text) * 0.5) if centered else float(rect.left())
    ty = rect.center().y() + (fm.ascent() - fm.descent()) * 0.5
    tp = QPainterPath()
    tp.addText(tx, ty, f, text)
    p.fillPath(tp, color)


def _load_square_icon_rgba(image_path):
    """Load any supported image (JPG/PNG/WEBP/SVG/ICO) into a crisp 256x256 RGBA PIL Image."""
    ext = os.path.splitext(image_path)[1].lower()
    if ext == ".svg":
        px = QPixmap(256, 256)
        px.fill(Qt.transparent)
        p = QPainter(px)
        p.setRenderHint(QPainter.Antialiasing, True)
        QSvgRenderer(image_path).render(p, QRectF(12, 12, 232, 232))
        p.end()
        ba = QByteArray()
        buf = QBuffer(ba)
        buf.open(QIODevice.WriteOnly)
        px.save(buf, "PNG")
        buf.close()
        return Image.open(io.BytesIO(bytes(ba.data()))).convert("RGBA")

    img = Image.open(image_path).convert("RGBA")
    alpha_extrema = img.getchannel("A").getextrema()
    has_transparency = alpha_extrema[0] < 245

    side = max(img.width, img.height)
    canvas = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
    scale_ratio = 256.0 / float(max(1, side))
    nw = max(1, int(round(img.width * scale_ratio)))
    nh = max(1, int(round(img.height * scale_ratio)))
    resized = img.resize((nw, nh), Image.Resampling.LANCZOS)
    ox = (256 - nw) // 2
    oy = (256 - nh) // 2
    canvas.paste(resized, (ox, oy), resized)

    if not has_transparency:
        mask = Image.new("L", (256, 256), 0)
        draw = ImageDraw.Draw(mask)
        draw.rounded_rectangle([ox, oy, ox + nw - 1, oy + nh - 1], radius=32, fill=255)
        existing_a = canvas.getchannel("A")
        out_a = Image.composite(mask, existing_a, mask)
        canvas.putalpha(out_a)

    return canvas


def _notify_shell_path(target_path):
    shell32 = ctypes.windll.shell32
    SHCNE_UPDATEITEM = 0x00002000
    SHCNE_UPDATEDIR = 0x00001000
    SHCNE_ASSOCCHANGED = 0x08000000
    SHCNF_PATHW = 0x0005
    SHCNF_FLUSH = 0x1000
    try:
        shell32.SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW | SHCNF_FLUSH, target_path, None)
        parent_dir = os.path.dirname(target_path)
        if parent_dir:
            shell32.SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_PATHW | SHCNF_FLUSH, parent_dir, None)
        shell32.SHChangeNotify(SHCNE_ASSOCCHANGED, 0x0000, None, None)
    except Exception:
        pass


def apply_folder_icon_style(image_path, target_folder):
    """Apply multi-resolution custom .ico styling to target_folder via Windows Shell API."""
    target_folder = os.path.abspath(target_folder)
    if not os.path.isdir(target_folder):
        raise ValueError(f"Selected folder does not exist: {target_folder}")

    kernel32 = ctypes.windll.kernel32
    shell32 = ctypes.windll.shell32
    shlwapi = ctypes.windll.shlwapi

    for fn in os.listdir(target_folder):
        if fn.startswith(".superdesign_") and fn.lower().endswith(".ico"):
            old_fp = os.path.join(target_folder, fn)
            try:
                kernel32.SetFileAttributesW(old_fp, 0x80)
                os.remove(old_fp)
            except Exception:
                pass

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:18]
    ico_name = f".superdesign_{stamp}.ico"
    ico_path = os.path.join(target_folder, ico_name)

    rgba = _load_square_icon_rgba(image_path)
    rgba.save(
        ico_path,
        format="ICO",
        sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)],
    )
    kernel32.SetFileAttributesW(ico_path, 0x02)

    ini_path = os.path.join(target_folder, "desktop.ini")
    if os.path.exists(ini_path):
        try:
            kernel32.SetFileAttributesW(ini_path, 0x80)
        except Exception:
            pass

    fcs = _SHFOLDERCUSTOMSETTINGS()
    fcs.dwSize = ctypes.sizeof(_SHFOLDERCUSTOMSETTINGS)
    fcs.dwMask = 0x00000010
    fcs.pszIconFile = ico_name
    fcs.iIconIndex = 0
    hr = shell32.SHGetSetFolderCustomSettings(ctypes.byref(fcs), target_folder, 0x00000002)

    if hr != 0 or not os.path.exists(ini_path):
        with open(ini_path, "w", encoding="utf-8") as f:
            f.write(f"[.ShellClassInfo]\r\nIconResource={ico_name},0\r\n")

    kernel32.SetFileAttributesW(ini_path, 0x02 | 0x04)
    try:
        shlwapi.PathMakeSystemFolderW(target_folder)
    except Exception:
        kernel32.SetFileAttributesW(target_folder, 0x01)

    _notify_shell_path(target_folder)
    return ico_path


def reset_folder_style(target_folder):
    """Restore target_folder back to its native Windows Explorer folder icon."""
    target_folder = os.path.abspath(target_folder)
    if not os.path.isdir(target_folder):
        raise ValueError(f"Selected folder does not exist: {target_folder}")

    kernel32 = ctypes.windll.kernel32
    shlwapi = ctypes.windll.shlwapi

    for fn in os.listdir(target_folder):
        if fn.startswith(".superdesign_") and fn.lower().endswith(".ico"):
            old_fp = os.path.join(target_folder, fn)
            try:
                kernel32.SetFileAttributesW(old_fp, 0x80)
                os.remove(old_fp)
            except Exception:
                pass

    ini_path = os.path.join(target_folder, "desktop.ini")
    if os.path.exists(ini_path):
        try:
            kernel32.SetFileAttributesW(ini_path, 0x80)
            os.remove(ini_path)
        except Exception:
            pass

    try:
        shlwapi.PathUnmakeSystemFolderW(target_folder)
    except Exception:
        try:
            attrs = kernel32.GetFileAttributesW(target_folder)
            if attrs != -1:
                kernel32.SetFileAttributesW(target_folder, attrs & ~0x05)
        except Exception:
            pass

    _notify_shell_path(target_folder)


def apply_file_shortcut_style(image_path, target_file):
    """Apply custom .ico icon to an existing .lnk shortcut or create a styled Desktop .lnk shortcut."""
    ensure_design_dirs()
    target_file = os.path.abspath(target_file)
    if not os.path.exists(target_file):
        raise ValueError(f"Selected file does not exist: {target_file}")

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:18]
    base_name = os.path.splitext(os.path.basename(target_file))[0] or "StyledFile"
    safe_base = "".join(c if c.isalnum() or c in " -_" else "_" for c in base_name).strip() or "StyledFile"

    ico_path = os.path.join(SHORTCUT_ICO_DIR, f"{safe_base}_{stamp}.ico")
    rgba = _load_square_icon_rgba(image_path)
    rgba.save(ico_path, format="ICO", sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])

    def _ps_esc(s):
        return s.replace("'", "''")

    if target_file.lower().endswith(".lnk"):
        lnk_path = target_file
        notify_dir = os.path.dirname(lnk_path)
        ps = (
            "$ws = New-Object -ComObject WScript.Shell; "
            f"$sc = $ws.CreateShortcut('{_ps_esc(lnk_path)}'); "
            f"$sc.IconLocation = '{_ps_esc(ico_path)},0'; "
            "$sc.Save()"
        )
    else:
        desk_dir = get_desktop_dir()
        notify_dir = desk_dir
        lnk_path = os.path.join(desk_dir, f"{safe_base}.lnk")
        if os.path.exists(lnk_path):
            lnk_path = os.path.join(desk_dir, f"{safe_base} (SuperDesign).lnk")
        work_dir = os.path.dirname(target_file)
        ps = (
            "$ws = New-Object -ComObject WScript.Shell; "
            f"$sc = $ws.CreateShortcut('{_ps_esc(lnk_path)}'); "
            f"$sc.TargetPath = '{_ps_esc(target_file)}'; "
            f"$sc.WorkingDirectory = '{_ps_esc(work_dir)}'; "
            f"$sc.IconLocation = '{_ps_esc(ico_path)},0'; "
            "$sc.Save()"
        )

    subprocess.run(
        ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
        check=True,
        creationflags=0x08000000,
    )
    _notify_shell_path(notify_dir)
    return lnk_path


def _read_cur_png_and_hotspot(cur_path):
    """Extract first PNG frame and hotspot (hx, hy) from a PNG-backed Windows .cur file."""
    raw = open(cur_path, "rb").read()
    cnt = struct.unpack_from("<H", raw, 4)[0]
    best = None
    for i in range(cnt):
        w, h, _, _, hx, hy, sz, off = struct.unpack_from("<BBBBHHII", raw, 6 + i * 16)
        payload = raw[off:off + sz]
        if payload.startswith(b"\x89PNG"):
            best = (w or 256, h or 256, hx, hy, payload)
            break
    if best is None:
        return None
    w, h, hx, hy, payload = best
    im = Image.open(io.BytesIO(payload)).convert("RGBA")
    return im, hx, hy


def _tint_cursor_image(im, rgb_tuple):
    """Recolor bright cursor fill pixels toward target RGB while keeping black outlines crisp."""
    tr, tg, tb = rgb_tuple
    px = im.load()
    out = im.copy()
    opx = out.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            if a == 0:
                continue
            lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
            if lum > 0.22:
                k = min(1.0, (lum - 0.12) / 0.85)
                opx[x, y] = (int(tr * k + r * (1.0 - k) * 0.2), int(tg * k + g * (1.0 - k) * 0.2), int(tb * k + b * (1.0 - k) * 0.2), a)
            else:
                opx[x, y] = (r, g, b, a)
    return out


def _write_png_cur(cur_path, im, hx, hy):
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    png_bytes = buf.getvalue()
    w = 0 if im.width >= 256 else im.width
    h = 0 if im.height >= 256 else im.height
    header = struct.pack("<HHH", 0, 2, 1)
    entry = struct.pack("<BBBBHHII", w, h, 0, 0, int(hx), int(hy), len(png_bytes), 22)
    with open(cur_path, "wb") as f:
        f.write(header + entry + png_bytes)


def _get_cursor_pack_files(pack_info):
    """Return mapping of Windows Cursor Registry Role -> .cur file path."""
    role_map = {
        "Arrow": "normal.cur",
        "Hand": "link.cur",
        "IBeam": "text.cur",
        "Wait": "busy.cur",
        "AppStarting": "working.cur",
        "Crosshair": "precision.cur",
        "SizeAll": "move.cur",
        "SizeNS": "resize_ns.cur",
        "SizeWE": "resize_ew.cur",
        "SizeNWSE": "resize_nwse.cur",
        "SizeNESW": "resize_nesw.cur",
        "No": "unavailable.cur",
    }
    if pack_info["is_default"]:
        win_cur = r"C:\Windows\Cursors"
        return {
            "Arrow": os.path.join(win_cur, "aero_arrow.cur"),
            "Hand": os.path.join(win_cur, "aero_link.cur"),
            "IBeam": "",
            "Wait": os.path.join(win_cur, "aero_busy.ani"),
            "AppStarting": os.path.join(win_cur, "aero_working.ani"),
            "Crosshair": "",
            "SizeAll": os.path.join(win_cur, "aero_move.cur"),
            "SizeNS": os.path.join(win_cur, "aero_ns.cur"),
            "SizeWE": os.path.join(win_cur, "aero_ew.cur"),
            "SizeNWSE": os.path.join(win_cur, "aero_nwse.cur"),
            "SizeNESW": os.path.join(win_cur, "aero_nesw.cur"),
            "No": os.path.join(win_cur, "aero_unavail.cur"),
        }

    tint = pack_info.get("tint")
    if tint is None:
        return {
            role: os.path.join(SRC_CURSORS_DIR, fname)
            for role, fname in role_map.items()
            if os.path.exists(os.path.join(SRC_CURSORS_DIR, fname))
        }

    out_dir = os.path.join(CURSOR_PACK_DIR, pack_info["id"])
    os.makedirs(out_dir, exist_ok=True)
    res = {}
    for role, fname in role_map.items():
        src_cur = os.path.join(SRC_CURSORS_DIR, fname)
        if not os.path.exists(src_cur):
            continue
        dst_cur = os.path.join(out_dir, fname)
        if not os.path.exists(dst_cur):
            parsed = _read_cur_png_and_hotspot(src_cur)
            if parsed is not None:
                im, hx, hy = parsed
                tinted = _tint_cursor_image(im, tint)
                _write_png_cur(dst_cur, tinted, hx, hy)
            else:
                shutil.copy2(src_cur, dst_cur)
        res[role] = dst_cur
    return res


def apply_cursor_pack(pack_info):
    """Apply a Cursor Pack to Windows registry HKCU\\Control Panel\\Cursors + SPI_SETCURSORS."""
    ensure_design_dirs()
    files = _get_cursor_pack_files(pack_info)
    key_path = r"Control Panel\Cursors"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as key:
        winreg.SetValueEx(key, "", 0, winreg.REG_SZ, "Windows Default" if pack_info["is_default"] else f"SuperMouse - {pack_info['name']}")
        for role, fp in files.items():
            if not fp or os.path.exists(fp):
                winreg.SetValueEx(key, role, 0, winreg.REG_EXPAND_SZ, fp)
    ctypes.windll.user32.SystemParametersInfoW(0x0057, 0, 0, 0x01 | 0x02)
    # Immediate live cursor switch across Windows without delay
    try:
        user32 = ctypes.windll.user32
        ocr_map = {
            "Arrow": 32512,      # OCR_NORMAL
            "Hand": 32649,       # OCR_HAND
            "IBeam": 32513,      # OCR_IBEAM
            "Wait": 32514,       # OCR_WAIT
            "AppStarting": 32650 # OCR_APPSTARTING
        }
        for role, ocr_id in ocr_map.items():
            cur_p = files.get(role)
            if cur_p and os.path.exists(cur_p):
                h_cur = user32.LoadImageW(None, cur_p, 2, 0, 0, 0x00000010 | 0x00000040)
                if h_cur:
                    user32.SetSystemCursor(h_cur, ocr_id)
    except Exception:
        pass
    return pack_info


def _nice_title_from_filename(fname):
    stem = os.path.splitext(fname)[0]
    parts = stem.split("_")
    if parts and parts[0].isdigit():
        parts = parts[1:]
    if parts and parts[0].lower() == "theme":
        parts = parts[1:]
    return " ".join(parts).strip().title() or stem


class _HeaderIconBtn(CleanHeaderIconButton):
    """Unified borderless fixed-size header slot (invisible box at rest, crisp common icon)."""

    def __init__(self, icon_key, tip_text="", parent=None):
        super().__init__(icon_key=icon_key, tip_text=tip_text, box_size=32, icon_size=16, on_press_tick=_play_asmr_tick, parent=parent)


class _CloseWinBtn(CleanCloseButton):
    """Unified borderless common Cross ('X') close button."""

    def __init__(self, parent=None):
        super().__init__(tip="Close Super Get Design", box_size=30, icon_size=15, parent=parent)


class _UpTabButton(QWidget):
    """Upwards Tab Selector Button for Folder | Files | Cursor (100% crisp filled icon + vector title)."""
    clicked = Signal(str)

    def __init__(self, tab_id, title, tip, svg_tpl, active=False, parent=None):
        super().__init__(parent)
        self.tab_id = tab_id
        self.title = title
        self.svg_tpl = svg_tpl
        self.is_active = active
        self.setToolTip(tip)
        self.setFixedHeight(34)
        self.setCursor(Qt.PointingHandCursor)

        f = QFont("Segoe UI Variable")
        f.setStyleName("Display Bold")
        f.setPointSizeF(9.5)
        tw = QFontMetrics(f).horizontalAdvance(title)
        self.setFixedWidth(tw + 48)

        self._h = 0.0
        self._target = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def set_active(self, flag):
        self.is_active = flag
        self.update()

    def _step(self):
        if abs(self._target - self._h) < 0.008:
            self._h = self._target
            self._timer.stop()
        else:
            self._h += (self._target - self._h) * 0.25
        self.update()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self.clicked.emit(self.tab_id)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h

        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        path = QPainterPath()
        path.addRoundedRect(rect, 8.5, 8.5)

        if self.is_active:
            p.fillPath(path, QColor(20, 32, 15, 245))
            b_grad = QLinearGradient(0, 0, w, 0)
            b_grad.setColorAt(0.0, QColor("#FFFF00"))
            b_grad.setColorAt(1.0, QColor("#a3e635"))
            p.setPen(QPen(QBrush(b_grad), 1.15))
            p.drawPath(path)
        else:
            p.fillPath(path, QColor(255, 255, 255, int(8 + hv * 12)))
            p.setPen(QPen(QColor(255, 255, 255, int(24 + hv * 50)), 0.95))
            p.drawPath(path)

        ico_col = "#a3e635" if (self.is_active or hv > 0.3) else "#9CA3AF"
        ico_pix = _render_svg_icon(self.svg_tpl, ico_col, 15, dpr=_native_dpr(self))
        p.drawPixmap(12, int(round((h - 15) * 0.5)), ico_pix)

        f = QFont("Segoe UI Variable")
        f.setStyleName("Display Bold" if self.is_active else "Text Semibold")
        f.setPointSizeF(9.3)
        t_col = QColor("#FFFFFF") if self.is_active else QColor(int(185 + hv * 60), int(190 + hv * 58), int(196 + hv * 52))
        _draw_crisp_text(p, QRectF(33.0, 0.0, w - 42.0, h), False, f, t_col, self.title)
        p.end()


class _DesignImageCard(QWidget):
    """Native-DPR sharp Gallery tile displaying a Design preset or uploaded artwork."""
    selected = Signal(str)
    delete_requested = Signal(str)

    def __init__(self, image_path, title, is_custom=False, parent=None):
        super().__init__(parent)
        self.image_path = image_path
        self.title = title
        self.is_custom = is_custom
        self.is_selected = False
        self.setFixedSize(148, 154)
        self.setCursor(Qt.PointingHandCursor)

        self._h = 0.0
        self._target = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

        self._dpr = _native_dpr(self)
        self._thumb = self._build_thumb(image_path, self._dpr)

    def _build_thumb(self, path, dpr=1.0):
        px_sz = max(92, int(round(94 * dpr)))
        if path.lower().endswith(".svg"):
            img = QImage(px_sz, px_sz, QImage.Format_ARGB32_Premultiplied)
            img.fill(Qt.transparent)
            p = QPainter(img)
            p.setRenderHint(QPainter.Antialiasing, True)
            pad = 4.0 * dpr
            QSvgRenderer(path).render(p, QRectF(pad, pad, px_sz - pad * 2, px_sz - pad * 2))
            p.end()
            pix = QPixmap.fromImage(img)
            pix.setDevicePixelRatio(dpr)
            return pix

        src = QImage(path)
        if src.isNull():
            return QPixmap()
        if src.width() > px_sz or src.height() > px_sz:
            src = src.scaled(px_sz, px_sz, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        elif src.width() < px_sz and src.height() < px_sz:
            src = src.scaled(px_sz, px_sz, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        pix = QPixmap.fromImage(src)
        pix.setDevicePixelRatio(dpr)
        return pix

    def set_selected(self, flag):
        if self.is_selected != flag:
            self.is_selected = flag
            self.update()

    def _step(self):
        if abs(self._target - self._h) < 0.008:
            self._h = self._target
            self._timer.stop()
        else:
            self._h += (self._target - self._h) * 0.25
        self.update()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            if self.is_custom and QRectF(self.width() - 26, 6, 20, 20).contains(e.position()):
                self.delete_requested.emit(self.image_path)
                e.accept()
                return
            self.selected.emit(self.image_path)
            e.accept()
        elif e.button() == Qt.RightButton and self.is_custom:
            self.delete_requested.emit(self.image_path)
            e.accept()

    def paintEvent(self, e):
        cur_dpr = _native_dpr(self)
        if abs(cur_dpr - self._dpr) > 0.05:
            self._dpr = cur_dpr
            self._thumb = self._build_thumb(self.image_path, cur_dpr)

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        hv = self._h
        sel = self.is_selected

        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        card = QPainterPath()
        card.addRoundedRect(rect, 11.0, 11.0)

        if sel:
            p.fillPath(card, QColor(20, 31, 14, 245))
            g = QLinearGradient(0, 0, w, h)
            g.setColorAt(0.0, QColor("#FFFF00"))
            g.setColorAt(1.0, QColor("#a3e635"))
            p.setPen(QPen(QBrush(g), 1.65))
            p.drawPath(card)
        elif hv > 0.02:
            p.fillPath(card, QColor(14, 18, 13, int(210 * hv)))
            p.setPen(QPen(QColor(163, 230, 53, int(120 * hv)), 1.0))
            p.drawPath(card)

        # Native-DPR sharp centered thumbnail
        if self._thumb and not self._thumb.isNull():
            tdpr = max(1.0, float(self._thumb.devicePixelRatio() or 1.0))
            tw = self._thumb.width() / tdpr
            th = self._thumb.height() / tdpr
            sc = 1.0 + hv * 0.05
            p.save()
            cx, cy = w * 0.5, 58.0
            p.translate(cx, cy)
            p.scale(sc, sc)
            draw_r = QRectF(-tw * 0.5, -th * 0.5, tw, th)
            clip_p = QPainterPath()
            clip_p.addRoundedRect(draw_r, 11.0, 11.0)
            p.setClipPath(clip_p)
            p.drawPixmap(QPointF(-tw * 0.5, -th * 0.5), self._thumb)
            p.restore()

        # Selection Filled Checkmark Badge top-right
        if sel:
            chk = _render_svg_icon(_PH_DESIGN_ICONS["check"], "#a3e635", 17, dpr=cur_dpr)
            p.drawPixmap(int(w - 24), 7, chk)
        elif self.is_custom and hv > 0.15:
            p.save()
            p.setOpacity(hv)
            tr_ico = _render_svg_icon(_PH_DESIGN_ICONS["trash"], "#F87171", 14, dpr=cur_dpr)
            p.drawPixmap(int(w - 23), 8, tr_ico)
            p.restore()

        # Custom badge top-left
        if self.is_custom:
            tp = QPainterPath()
            tp.addRoundedRect(QRectF(8, 8, 46, 15), 4.5, 4.5)
            p.fillPath(tp, QColor(163, 230, 53, 38))
            pf = QFont("Segoe UI Variable")
            pf.setStyleName("Display Bold")
            pf.setPointSizeF(5.7)
            _draw_crisp_text(p, QRectF(8, 8, 46, 15), True, pf, QColor("#b6f34b"), "CUSTOM")

        # Razor-sharp Vector Title at bottom of tile
        f = QFont("Segoe UI Variable")
        f.setStyleName("Display Bold" if sel else "Text Semibold")
        f.setPointSizeF(8.6)
        f.setHintingPreference(QFont.PreferNoHinting)
        elided = QFontMetrics(f).elidedText(self.title, Qt.ElideRight, int(w - 16))
        t_col = QColor("#FFFFFF") if (sel or hv > 0.35) else QColor("#E4E4E7")
        _draw_crisp_text(p, QRectF(8.0, 116.0, w - 16.0, 26.0), True, f, t_col, elided)
        p.end()


class _CursorPackCard(QWidget):
    """Interactive card previewing 4 real pointers (Arrow, Hand, IBeam, Wait) + live ACTIVE status."""
    selected = Signal(str)

    def __init__(self, pack_info, is_live_active=False, parent=None):
        super().__init__(parent)
        self.pack = pack_info
        self.is_selected = False
        self.is_live_active = bool(is_live_active)
        self.setFixedSize(256, 158)
        self.setCursor(Qt.PointingHandCursor)

        self._h = 0.0
        self._target = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

        self._dpr = _native_dpr(self)
        self._previews = self._build_previews(self._dpr)

    def set_live_active(self, flag):
        self.is_live_active = bool(flag)
        self.update()

    def _build_previews(self, dpr):
        files = _get_cursor_pack_files(self.pack)
        out = []
        for role in ("Arrow", "Hand", "IBeam", "Wait"):
            fp = files.get(role, "")
            if self.pack["is_default"] and role == "IBeam":
                cand = os.path.join(r"C:\Windows\Cursors", "beam_r.cur")
                if os.path.exists(cand):
                    fp = cand
            if not fp or not os.path.exists(fp):
                fallback_key = "files" if role == "IBeam" else "cursor"
                out.append(_render_svg_icon(_PH_DESIGN_ICONS[fallback_key], self.pack["c1"], 24, dpr=dpr))
                continue
            parsed = _read_cur_png_and_hotspot(fp)
            if parsed is not None:
                im, _, _ = parsed
                buf = io.BytesIO()
                im.save(buf, format="PNG")
                qi = QImage.fromData(buf.getvalue())
                px = max(28, int(round(32 * dpr)))
                qi = qi.scaled(px, px, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                pix = QPixmap.fromImage(qi)
                pix.setDevicePixelRatio(dpr)
                out.append(pix)
            else:
                qi = QImage(fp)
                if not qi.isNull():
                    px = max(28, int(round(32 * dpr)))
                    qi = qi.scaled(px, px, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    pix = QPixmap.fromImage(qi)
                    pix.setDevicePixelRatio(dpr)
                    out.append(pix)
                else:
                    out.append(_render_svg_icon(_PH_DESIGN_ICONS["cursor"], self.pack["c1"], 28, dpr=dpr))
        return out

    def set_selected(self, flag):
        if self.is_selected != flag:
            self.is_selected = flag
            self.update()

    def _step(self):
        if abs(self._target - self._h) < 0.008:
            self._h = self._target
            self._timer.stop()
        else:
            self._h += (self._target - self._h) * 0.25
        self.update()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self.selected.emit(self.pack["id"])
            e.accept()

    def paintEvent(self, e):
        cur_dpr = _native_dpr(self)
        if abs(cur_dpr - self._dpr) > 0.05:
            self._dpr = cur_dpr
            self._previews = self._build_previews(cur_dpr)

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        hv = self._h
        sel = self.is_selected

        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        card = QPainterPath()
        card.addRoundedRect(rect, 12.0, 12.0)

        if sel:
            p.fillPath(card, QColor(20, 31, 14, 245))
            g = QLinearGradient(0, 0, w, h)
            g.setColorAt(0.0, QColor("#FFFF00"))
            g.setColorAt(1.0, QColor("#a3e635"))
            p.setPen(QPen(QBrush(g), 1.65))
            p.drawPath(card)
        else:
            p.fillPath(card, QColor(int(12 + hv * 8), int(13 + hv * 10), int(14 + hv * 4), 240))
            p.setPen(QPen(QColor(163, 230, 53, int(45 + hv * 95)) if hv > 0.05 else QColor(255, 255, 255, 22), 1.0))
            p.drawPath(card)

        stage = QPainterPath()
        stage.addRoundedRect(QRectF(14.0, 14.0, w - 28.0, 74.0), 9.0, 9.0)
        p.fillPath(stage, QColor(7, 8, 9, 255))
        p.setPen(QPen(QColor(255, 255, 255, 18), 0.9))
        p.drawPath(stage)

        # Draw 4 cursor previews cleanly spaced
        spacing = 46.0
        start_x = w * 0.5 - spacing * 1.5
        for idx, pix in enumerate(self._previews):
            if pix and not pix.isNull():
                pdpr = max(1.0, float(pix.devicePixelRatio() or 1.0))
                pw = pix.width() / pdpr
                ph = pix.height() / pdpr
                cx = start_x + idx * spacing
                cy = 51.0
                p.drawPixmap(QPointF(cx - pw * 0.5, cy - ph * 0.5), pix)

        # LIVE ACTIVE pill top-left inside stage
        if self.is_live_active:
            ap = QPainterPath()
            ar = QRectF(20.0, 20.0, 46.0, 15.0)
            ap.addRoundedRect(ar, 4.5, 4.5)
            p.fillPath(ap, QColor(163, 230, 53, 34))
            p.setPen(QPen(QColor(163, 230, 53, 145), 0.8))
            p.drawPath(ap)
            af = QFont("Segoe UI Variable")
            af.setStyleName("Display Bold")
            af.setPointSizeF(5.5)
            _draw_crisp_text(p, ar, True, af, QColor("#a3e635"), "ACTIVE")

        # Selection check badge top-right (unified cyber-lime)
        if sel:
            chk = _render_svg_icon(_PH_DESIGN_ICONS["check"], "#a3e635", 17, dpr=cur_dpr)
            p.drawPixmap(int(w - 28), 20, chk)

        p.setBrush(QBrush(QColor(self.pack["c1"])))
        p.setPen(Qt.NoPen)
        p.drawEllipse(QPointF(21.0, 108.0), 4.0, 4.0)

        f_title = QFont("Segoe UI Variable")
        f_title.setStyleName("Display Bold")
        f_title.setPointSizeF(9.8)
        _draw_crisp_text(p, QRectF(31.0, 97.0, w - 42.0, 22.0), False, f_title, QColor("#FFFFFF"), self.pack["name"])

        f_sub = QFont("Segoe UI Variable")
        f_sub.setStyleName("Text Semibold")
        f_sub.setPointSizeF(8.0)
        _draw_crisp_text(p, QRectF(16.0, 120.0, w - 32.0, 20.0), False, f_sub, QColor("#9CA3AF"), self.pack["subtitle"])
        p.end()


class _ToastNotice(QFrame):
    """Sleek confirmation popup when a Folder, Shortcut, or Cursor Pack is applied."""

    def __init__(self, parent=None):
        super().__init__(None, Qt.ToolTip | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(348, 74)
        self._folder = ""

        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(12)

        self.ico = QLabel(self)
        self.ico.setFixedSize(40, 40)
        self.ico.setAlignment(Qt.AlignCenter)
        self.ico.setStyleSheet(
            "background-color: #0B0D0A; border: 1px solid rgba(163, 230, 53, 0.55); border-radius: 10px;"
        )
        lay.addWidget(self.ico)

        col = QVBoxLayout()
        col.setSpacing(2)
        self.lbl1 = QLabel("STYLE APPLIED", self)
        self.lbl1.setStyleSheet("color: #FFFFFF; font-size: 11.5px; font-weight: 800; background: transparent;")
        self.lbl2 = QLabel("", self)
        self.lbl2.setStyleSheet("color: #a3e635; font-size: 10.5px; font-weight: 600; background: transparent;")
        col.addWidget(self.lbl1)
        col.addWidget(self.lbl2)
        lay.addLayout(col, stretch=1)

        self.btn_open = QPushButton("Open", self)
        self.btn_open.setFixedSize(56, 28)
        self.btn_open.setCursor(Qt.PointingHandCursor)
        self.btn_open.setStyleSheet(
            "QPushButton { background: rgba(163, 230, 53, 0.18); color: #a3e635; "
            "border: 1px solid rgba(163, 230, 53, 0.65); border-radius: 6px; font-size: 11px; font-weight: 700; }"
            "QPushButton:hover { background: rgba(163, 230, 53, 0.34); color: #FFFFFF; }"
        )
        self.btn_open.clicked.connect(self._open_folder)
        lay.addWidget(self.btn_open)

        self._t = QTimer(self)
        self._t.setSingleShot(True)
        self._t.timeout.connect(self.close)

    def _open_folder(self):
        self._t.stop()
        if self._folder and os.path.isdir(self._folder):
            QDesktopServices.openUrl(QUrl.fromLocalFile(self._folder))
        self.close()

    def show_applied(self, target_dir, thumb_path, center_pos, title="FOLDER STYLE APPLIED", subtitle=None):
        self._folder = target_dir or ""
        self.btn_open.setVisible(bool(target_dir and os.path.isdir(target_dir)))
        self.lbl1.setText(title)
        self.lbl2.setText(subtitle or (os.path.basename(target_dir) or target_dir))
        dpr = _native_dpr(self)
        if thumb_path and os.path.exists(thumb_path):
            qi = QImage(thumb_path)
            if not qi.isNull():
                sz = max(28, int(round(28 * dpr)))
                qi = qi.scaled(sz, sz, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                pix = QPixmap.fromImage(qi)
                pix.setDevicePixelRatio(dpr)
                self.ico.setPixmap(pix)
        else:
            self.ico.setPixmap(_render_svg_icon(_PH_DESIGN_ICONS["check"], "#a3e635", 22, dpr=dpr))
        self.move(center_pos.x() - self.width() // 2, center_pos.y() - self.height() // 2)
        self.show()
        self.raise_()
        self._t.start(4000)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = QRectF(0.5, 0.5, self.width() - 1.0, self.height() - 1.0)
        path = QPainterPath()
        path.addRoundedRect(rect, 12.0, 12.0)
        p.fillPath(path, QColor(8, 10, 8, 252))
        g = QLinearGradient(0, 0, self.width(), 0)
        g.setColorAt(0.0, QColor("#FFFF00"))
        g.setColorAt(1.0, QColor("#a3e635"))
        p.setPen(QPen(QBrush(g), 1.2))
        p.drawPath(path)
        p.end()


class SuperSupDesignWindow(QWidget):
    """
    Full Working Studio Window for SuperSupDesign:
      - Navigation: Back + Home (ASMR switch back to Quick Menu), vector brand, item badge, circular Close
      - Upwards Tabs (ALL 3 WORKING): Folder (with Reset Folder), Files (Desktop Shortcut Styler), Cursor (Live Packs)
      - Live Search Bar with ASMR ticks + Drag & Drop Upload + Curated Collection
    """

    def __init__(self, on_back_to_menu=None, parent=None):
        super().__init__(parent)
        self.on_back_to_menu = on_back_to_menu
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAcceptDrops(True)
        self.resize(864, 610)

        ensure_design_dirs()
        self._dragging = False
        self._drag_offset = QPoint()
        self._selected_by_tab = {"folder": None, "files": None}
        self._selected_path = None
        self._selected_cursor_id = None
        self._active_cursor_id = get_active_cursor_pack_id()
        self._cards = []
        self._cursor_cards = []
        self._active_tab = "folder"
        self._filter_mode = "all"
        self.toast = _ToastNotice()

        base_assets = os.path.join(BASE_DIR, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        if os.path.exists(logo_fp):
            l_img = QImage(logo_fp)
            if not l_img.isNull():
                ldpr = _native_dpr(self)
                l_img = l_img.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
                self.logo_pix = QPixmap.fromImage(l_img)
                self.logo_pix.setDevicePixelRatio(ldpr)
            else:
                self.logo_pix = None
        else:
            self.logo_pix = None

        self._build_ui()
        self.reload_gallery()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 1. Header Navigation Bar (Back + Main Menu | Logo Brand | Count Pill + Circular Close)
        header = QWidget(self)
        header.setFixedHeight(54)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(14, 0, 14, 0)
        hdr.setSpacing(2)

        self.btn_back = _HeaderIconBtn("back", "Back", header)
        self.btn_back.clicked.connect(self._go_back)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_menu = _HeaderIconBtn("home", "Main Menu", header)
        self.btn_menu.clicked.connect(self._go_back)
        hdr.addWidget(self.btn_menu, alignment=Qt.AlignVCenter)

        hdr.addStretch()

        self.lbl_count_hdr = QLabel("0 Designs", header)
        self.lbl_count_hdr.setStyleSheet(
            "color: #848A95; background: transparent; border: none; "
            "padding: 2px 6px; font-size: 11px; font-weight: 600; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        hdr.addWidget(self.lbl_count_hdr, alignment=Qt.AlignVCenter)
        hdr.addSpacing(4)

        self.btn_close = _CloseWinBtn(header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        # 2. Upwards Tab Bar: FOLDER | FILES | CURSOR + Upload / Reset Tools
        tab_bar = QWidget(self)
        tab_bar.setFixedHeight(46)
        tb_lay = QHBoxLayout(tab_bar)
        tb_lay.setContentsMargins(18, 4, 18, 8)
        tb_lay.setSpacing(8)

        self.tab_folder = _UpTabButton("folder", "Folder", "Apply custom icons to any Windows folder", _PH_DESIGN_ICONS["folder"], active=True, parent=tab_bar)
        self.tab_files = _UpTabButton("files", "Files", "Create custom-icon Desktop shortcuts for any file or app", _PH_DESIGN_ICONS["files"], active=False, parent=tab_bar)
        self.tab_cursor = _UpTabButton("cursor", "Cursor", "Switch system mouse cursor pack live", _PH_DESIGN_ICONS["cursor"], active=False, parent=tab_bar)
        self.tab_cursor.hide()

        for tb in (self.tab_folder, self.tab_files):
            tb.clicked.connect(self._on_tab_clicked)
            tb_lay.addWidget(tb)

        tb_lay.addStretch(1)

        dpr = _native_dpr(self)
        self.btn_upload = QPushButton("  Upload Art", tab_bar)
        self.btn_upload.setFixedHeight(34)
        self.btn_upload.setCursor(Qt.PointingHandCursor)
        self.btn_upload.setToolTip("Upload or drag & drop PNG/JPG/SVG/ICO images")
        self.btn_upload.setIcon(QIcon(_render_svg_icon(_PH_DESIGN_ICONS["upload"], "#a3e635", 14, dpr=dpr)))
        self.btn_upload.setIconSize(QSize(14, 14))
        self.btn_upload.setStyleSheet(
            "QPushButton { background-color: rgba(163, 230, 53, 0.14); color: #b6f34b; "
            "border: 1px solid rgba(163, 230, 53, 0.50); border-radius: 8px; "
            "padding: 0px 13px; font-size: 11.5px; font-weight: 700; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
            "QPushButton:hover { background-color: rgba(163, 230, 53, 0.28); color: #FFFFFF; "
            "border-color: #a3e635; }"
        )
        self.btn_upload.clicked.connect(self._on_upload_collection)
        tb_lay.addWidget(self.btn_upload)
        root.addWidget(tab_bar)

        div1 = QFrame(self)
        div1.setFixedHeight(1)
        div1.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0px 18px;")
        root.addWidget(div1)

        # 3. Stacked Content Area (Artwork Gallery for Folder & Files + Working Cursor Studio)
        self.stack = QStackedWidget(self)
        root.addWidget(self.stack, stretch=1)

        # Page 0: Shared Crisp Artwork Collection (Folder Icons & File Shortcuts)
        art_page = QWidget()
        ap_lay = QVBoxLayout(art_page)
        ap_lay.setContentsMargins(18, 12, 18, 8)
        ap_lay.setSpacing(10)

        # Search + Compact Filter Pills Row
        ctrl_row = QHBoxLayout()
        ctrl_row.setSpacing(8)

        self.search_box = QFrame(art_page)
        self.search_box.setFixedHeight(34)
        self.search_box.setStyleSheet(
            "QFrame { background-color: #0D0E10; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 9px; }"
            "QFrame:focus-within { border-color: #a3e635; background-color: #101510; }"
        )
        sb_lay = QHBoxLayout(self.search_box)
        sb_lay.setContentsMargins(10, 0, 8, 0)
        sb_lay.setSpacing(7)

        s_ico = QLabel(self.search_box)
        s_ico.setPixmap(_render_svg_icon(_PH_DESIGN_ICONS["search_fill"], "#9CA3AF", 14, dpr=dpr))
        s_ico.setStyleSheet("background: transparent; border: none;")
        sb_lay.addWidget(s_ico)

        self.search_input = QLineEdit(self.search_box)
        self.search_input.setPlaceholderText("Search designs by name, theme, upload...")
        self.search_input.setStyleSheet(
            "QLineEdit { background: transparent; border: none; color: #FFFFFF; "
            "font-size: 11.5px; font-weight: 500; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
        )
        self.search_input.textEdited.connect(lambda _t: _play_asmr_tick())
        self.search_input.textChanged.connect(self._on_search_changed)
        sb_lay.addWidget(self.search_input, stretch=1)

        self.btn_clear_search = QPushButton("", self.search_box)
        self.btn_clear_search.setFixedSize(18, 18)
        self.btn_clear_search.setIcon(QIcon(_render_svg_icon(_PH_DESIGN_ICONS["close_fill"], "#E4E4E7", 11, dpr=dpr)))
        self.btn_clear_search.setIconSize(QSize(11, 11))
        self.btn_clear_search.setCursor(Qt.PointingHandCursor)
        self.btn_clear_search.setVisible(False)
        self.btn_clear_search.setStyleSheet(
            "QPushButton { background: rgba(255,255,255,0.09); border: none; border-radius: 9px; }"
            "QPushButton:hover { background: rgba(163,230,53,0.25); }"
        )
        self.btn_clear_search.clicked.connect(self.search_input.clear)
        sb_lay.addWidget(self.btn_clear_search)

        ctrl_row.addWidget(self.search_box, stretch=1)

        self._flt_btns = {}
        for fid, label in (("all", "All"), ("preset", "Studio"), ("custom", "Uploads")):
            b = QPushButton(label, art_page)
            b.setFixedHeight(32)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=fid: (_play_asmr_tick(), self._set_filter(k)))
            ctrl_row.addWidget(b)
            self._flt_btns[fid] = b

        ap_lay.addLayout(ctrl_row)
        self._update_filter_styles()

        # Scrollable 5-column Grid (Slim Translucent Pill Scrollbar)
        self.scroll = QScrollArea(art_page)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet(SLIM_SCROLLBAR_QSS)
        self.grid_container = QWidget()
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setContentsMargins(2, 4, 8, 8)
        self.grid_layout.setSpacing(14)
        self.grid_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.scroll.setWidget(self.grid_container)
        ap_lay.addWidget(self.scroll, stretch=1)
        self.stack.addWidget(art_page)

        # Page 1: Working Live Windows Cursor Studio
        cursor_page = QWidget()
        cp_lay = QVBoxLayout(cursor_page)
        cp_lay.setContentsMargins(18, 16, 18, 10)
        cp_lay.setSpacing(12)

        cp_hint = QLabel("Pick any Cursor Theme to preview 4 pointers — active Windows theme is badged cleanly.", cursor_page)
        cp_hint.setStyleSheet(
            "color: #A1A7B3; font-size: 12px; font-weight: 600; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        cp_lay.addWidget(cp_hint)

        c_scroll = QScrollArea(cursor_page)
        c_scroll.setWidgetResizable(True)
        c_scroll.setFrameShape(QFrame.NoFrame)
        c_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        c_scroll.setStyleSheet(SLIM_SCROLLBAR_QSS)
        c_inner = QWidget()
        c_grid = QGridLayout(c_inner)
        c_grid.setContentsMargins(2, 4, 8, 8)
        c_grid.setSpacing(16)
        c_grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        for idx, pk in enumerate(CURSOR_PACKS):
            cc = _CursorPackCard(pk, is_live_active=(pk["id"] == self._active_cursor_id), parent=c_inner)
            cc.selected.connect(self._on_cursor_selected)
            c_grid.addWidget(cc, idx // 3, idx % 3)
            self._cursor_cards.append(cc)
        c_scroll.setWidget(c_inner)
        cp_lay.addWidget(c_scroll, stretch=1)
        self.stack.addWidget(cursor_page)

        # 4. Logical Bottom Action Footer (Selection Preview + Reset Default + Primary Apply CTA)
        div2 = QFrame(self)
        div2.setFixedHeight(1)
        div2.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0px 18px;")
        root.addWidget(div2)

        footer = QWidget(self)
        footer.setFixedHeight(64)
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(18, 10, 18, 10)
        fl.setSpacing(10)

        self.sel_thumb = QLabel(footer)
        self.sel_thumb.setFixedSize(38, 38)
        self.sel_thumb.setAlignment(Qt.AlignCenter)
        self.sel_thumb.setStyleSheet(
            "background-color: #0D0E10; border: 1px solid rgba(255,255,255,0.12); border-radius: 9px;"
        )
        fl.addWidget(self.sel_thumb)

        self.lbl_sel = QLabel("Select an icon above", footer)
        self.lbl_sel.setStyleSheet(
            "color: #848A95; font-size: 12px; font-weight: 600; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        fl.addWidget(self.lbl_sel, stretch=1)

        self.btn_reset_action = QPushButton("  Reset Folder", footer)
        self.btn_reset_action.setFixedHeight(36)
        self.btn_reset_action.setCursor(Qt.PointingHandCursor)
        self.btn_reset_action.setToolTip("Restore a styled folder back to Windows default icon")
        self.btn_reset_action.setIcon(QIcon(_render_svg_icon(_PH_DESIGN_ICONS["reset_fill"], "#E4E4E7", 14, dpr=dpr)))
        self.btn_reset_action.setIconSize(QSize(14, 14))
        self.btn_reset_action.setStyleSheet(
            "QPushButton { background-color: #101113; color: #E4E4E7; "
            "border: 1px solid rgba(255, 255, 255, 0.14); border-radius: 9px; "
            "padding: 0px 13px; font-size: 11.5px; font-weight: 700; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
            "QPushButton:hover { border-color: #a3e635; color: #FFFFFF; background-color: #161A14; }"
        )
        self.btn_reset_action.clicked.connect(self._on_reset_clicked)
        fl.addWidget(self.btn_reset_action)

        self.btn_next = QPushButton("Choose Folder", footer)
        self.btn_next.setFixedSize(156, 38)
        self.btn_next.setCursor(Qt.PointingHandCursor)
        self.btn_next.setLayoutDirection(Qt.RightToLeft)
        self.btn_next.setIconSize(QSize(15, 15))
        self.btn_next.setEnabled(False)
        self.btn_next.clicked.connect(self._on_next_clicked)
        fl.addWidget(self.btn_next)
        root.addWidget(footer)

        self._sync_next_button()

    def _go_back(self):
        if callable(self.on_back_to_menu):
            self.switch_out_asmr_animation(on_finished=self.on_back_to_menu)
        else:
            self.close_with_pull_animation()

    def _on_tab_clicked(self, tab_id):
        self._active_tab = tab_id
        self.tab_folder.set_active(tab_id == "folder")
        self.tab_files.set_active(tab_id == "files")
        self.tab_cursor.set_active(tab_id == "cursor")
        self.stack.setCurrentIndex(1 if tab_id == "cursor" else 0)
        is_art = tab_id in ("folder", "files")
        self.btn_upload.setVisible(is_art)
        if tab_id == "cursor":
            self._active_cursor_id = get_active_cursor_pack_id()
            for cc in self._cursor_cards:
                cc.set_live_active(cc.pack["id"] == self._active_cursor_id)
            self.btn_reset_action.setVisible(True)
            self.btn_reset_action.setText("  Default Cursors")
            self.btn_reset_action.setToolTip("Restore native Windows system cursors")
            self.lbl_count_hdr.setText(format_count_label(len(CURSOR_PACKS), "Theme", "Themes"))
        elif tab_id == "folder":
            self._selected_path = self._selected_by_tab.get("folder")
            self.btn_reset_action.setVisible(True)
            self.btn_reset_action.setText("  Reset Folder")
            self.btn_reset_action.setToolTip("Restore a styled folder back to Windows default icon")
            self.reload_gallery(self.search_input.text())
        else:
            self._selected_path = self._selected_by_tab.get("files")
            self.btn_reset_action.setVisible(False)
            self.reload_gallery(self.search_input.text())
        self._sync_next_button()

    def _set_filter(self, fid):
        self._filter_mode = fid
        self._update_filter_styles()
        self.reload_gallery(self.search_input.text())

    def _on_search_changed(self, text):
        self.btn_clear_search.setVisible(bool(text.strip()))
        self.reload_gallery(text)

    def _update_filter_styles(self):
        for fid, btn in self._flt_btns.items():
            if fid == self._filter_mode:
                btn.setStyleSheet(
                    "QPushButton { background: rgba(163, 230, 53, 0.16); color: #b6f34b; "
                    "border: 1px solid rgba(163, 230, 53, 0.55); border-radius: 8px; padding: 0px 12px; font-size: 11px; font-weight: 700; }"
                )
            else:
                btn.setStyleSheet(
                    "QPushButton { background: rgba(255, 255, 255, 0.04); color: #9CA3AF; "
                    "border: 1px solid rgba(255, 255, 255, 0.09); border-radius: 8px; padding: 0px 12px; font-size: 11px; font-weight: 600; }"
                    "QPushButton:hover { color: #FFFFFF; border-color: rgba(255, 255, 255, 0.25); }"
                )

    def reload_gallery(self, query=""):
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        self._cards.clear()

        entries = []
        preset_src = FILE_PRESET_DIR if self._active_tab == "files" else PRESET_DIR
        if self._filter_mode in ("all", "preset") and os.path.isdir(preset_src):
            for fn in sorted(os.listdir(preset_src)):
                if fn.lower().endswith(SUPPORTED_EXTS):
                    entries.append((os.path.join(preset_src, fn), _nice_title_from_filename(fn), False))

        if self._filter_mode in ("all", "custom") and os.path.isdir(UPLOAD_DIR):
            for fn in sorted(os.listdir(UPLOAD_DIR)):
                if fn.lower().endswith(SUPPORTED_EXTS):
                    entries.append((os.path.join(UPLOAD_DIR, fn), _nice_title_from_filename(fn), True))

        q = (query or "").strip().lower()
        if q:
            filtered = []
            for fp, title, is_custom in entries:
                tag = "custom upload" if is_custom else ("file emblem" if self._active_tab == "files" else "folder preset")
                if q in f"{title.lower()} {os.path.basename(fp).lower()} {tag}":
                    filtered.append((fp, title, is_custom))
            entries = filtered

        cols = 5
        for i, (fp, title, is_custom) in enumerate(entries):
            card = _DesignImageCard(fp, title, is_custom=is_custom, parent=self.grid_container)
            card.set_selected(self._selected_path == fp)
            card.selected.connect(self._on_card_selected)
            card.delete_requested.connect(self._on_delete_upload)
            self.grid_layout.addWidget(card, i // cols, i % cols)
            self._cards.append(card)

        if self._active_tab != "cursor":
            noun = "Emblem" if self._active_tab == "files" else "Design"
            self.lbl_count_hdr.setText(format_count_label(len(entries), noun))
        if self._selected_path and not os.path.exists(self._selected_path):
            self._selected_path = None
        self._sync_next_button()

    def _on_card_selected(self, path):
        self._selected_path = path
        if self._active_tab in self._selected_by_tab:
            self._selected_by_tab[self._active_tab] = path
        for c in self._cards:
            c.set_selected(c.image_path == path)
        self._sync_next_button()

    def _on_cursor_selected(self, pack_id):
        self._selected_cursor_id = pack_id
        for cc in self._cursor_cards:
            cc.set_selected(cc.pack["id"] == pack_id)
        self._sync_next_button()

    def _on_delete_upload(self, path):
        try:
            if os.path.exists(path) and os.path.dirname(os.path.abspath(path)) == os.path.abspath(UPLOAD_DIR):
                os.remove(path)
                if self._selected_path == path:
                    self._selected_path = None
                self.reload_gallery(self.search_input.text())
        except Exception:
            pass

    def _import_files(self, paths):
        ensure_design_dirs()
        last_copied = None
        for src in paths:
            if not os.path.isfile(src):
                continue
            if os.path.splitext(src)[1].lower() not in SUPPORTED_EXTS:
                continue
            try:
                base = os.path.basename(src)
                dest = os.path.join(UPLOAD_DIR, base)
                if os.path.exists(dest):
                    stem, ext = os.path.splitext(base)
                    dest = os.path.join(UPLOAD_DIR, f"{stem}_{datetime.now().strftime('%H%M%S')}{ext}")
                shutil.copy2(src, dest)
                last_copied = dest
            except Exception:
                pass
        if last_copied:
            self._selected_path = last_copied
            _play_asmr_tick()
            self.reload_gallery(self.search_input.text())

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            for u in e.mimeData().urls():
                if u.isLocalFile() and os.path.splitext(u.toLocalFile())[1].lower() in SUPPORTED_EXTS:
                    e.acceptProposedAction()
                    return
        super().dragEnterEvent(e)

    def dropEvent(self, e):
        if e.mimeData().hasUrls():
            files = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
            if files:
                self._import_files(files)
                e.acceptProposedAction()
                return
        super().dropEvent(e)

    def _on_upload_collection(self):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Upload Images to Super Get Design Collection",
            get_desktop_dir(),
            "Images (*.png *.jpg *.jpeg *.webp *.bmp *.ico *.svg);;All Files (*.*)",
        )
        if files:
            self._import_files(files)

    def _sync_next_button(self):
        dpr = _native_dpr(self)
        if self._active_tab == "cursor":
            pk = next((p for p in CURSOR_PACKS if p["id"] == self._selected_cursor_id), None)
            can_next = pk is not None
            self.btn_next.setText("  Apply Cursor" if can_next else "  Select Pack")
            self.btn_next.setEnabled(can_next)
            if can_next:
                self.lbl_sel.setText(f"Selected: {pk['name']}  ·  Apply live Windows cursors")
                self.lbl_sel.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600; background: transparent;")
                self.sel_thumb.setPixmap(_render_svg_icon(_PH_DESIGN_ICONS["cursor"], pk["c1"], 19, dpr=dpr))
            else:
                self.lbl_sel.setText("Select a cursor theme above to enable Apply")
                self.lbl_sel.setStyleSheet("color: #848A95; font-size: 12px; font-weight: 600; background: transparent;")
                self.sel_thumb.setPixmap(_render_svg_icon(_PH_DESIGN_ICONS["cursor"], "#6B7280", 18, dpr=dpr))
        else:
            can_next = bool(self._selected_path and os.path.exists(self._selected_path))
            is_files = self._active_tab == "files"
            self.btn_next.setText(("  Style File" if is_files else "  Choose Folder") if can_next else "  Select Art")
            self.btn_next.setEnabled(can_next)
            if can_next:
                name = _nice_title_from_filename(os.path.basename(self._selected_path))
                action_hint = "Pick any file or app for a custom Desktop shortcut" if is_files else "Choose target folder to style"
                self.lbl_sel.setText(f"Selected: {name}  ·  {action_hint}")
                self.lbl_sel.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600; background: transparent;")
                qi = QImage(self._selected_path)
                if not qi.isNull():
                    sz = max(26, int(round(28 * dpr)))
                    qi = qi.scaled(sz, sz, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    px = QPixmap.fromImage(qi)
                    px.setDevicePixelRatio(dpr)
                    self.sel_thumb.setPixmap(px)
            else:
                self.lbl_sel.setText("Select any artwork above (or drag & drop an image)")
                self.lbl_sel.setStyleSheet("color: #848A95; font-size: 12px; font-weight: 600; background: transparent;")
                ico_key = "files" if is_files else "folder"
                self.sel_thumb.setPixmap(_render_svg_icon(_PH_DESIGN_ICONS[ico_key], "#6B7280", 18, dpr=dpr))

        if self.btn_next.isEnabled():
            self.btn_next.setIcon(QIcon(_render_svg_icon(_PH_DESIGN_ICONS["arrow_right_fill"], "#080A07", 15, dpr=dpr)))
            self.btn_next.setStyleSheet(
                "QPushButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #a3e635, stop:1 #FFFF00); "
                "color: #080A07; border: none; border-radius: 9px; padding: 0px 14px; font-size: 12.5px; font-weight: 800; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
                "QPushButton:hover { background: #c4fa26; }"
            )
        else:
            self.btn_next.setIcon(QIcon(_render_svg_icon(_PH_DESIGN_ICONS["arrow_right_fill"], "#525866", 15, dpr=dpr)))
            self.btn_next.setStyleSheet(
                "QPushButton { background-color: rgba(255, 255, 255, 0.05); color: rgba(255, 255, 255, 0.30); "
                "border: 1px solid rgba(255, 255, 255, 0.09); border-radius: 9px; padding: 0px 14px; font-size: 12.5px; font-weight: 700; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
            )

    def _on_reset_clicked(self):
        _play_asmr_tick()
        center = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        if self._active_tab == "cursor":
            pk = next(p for p in CURSOR_PACKS if p["is_default"])
            apply_cursor_pack(pk)
            self._active_cursor_id = pk["id"]
            for cc in self._cursor_cards:
                cc.set_live_active(cc.pack["id"] == self._active_cursor_id)
            self._on_cursor_selected(pk["id"])
            self.toast.show_applied("", "", center, title="DEFAULT CURSORS RESTORED", subtitle="Native Windows pointers active")
            return

        target_dir = QFileDialog.getExistingDirectory(
            self,
            "Choose Styled Folder to Restore Default",
            get_desktop_dir(),
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks,
        )
        if not target_dir:
            return
        try:
            reset_folder_style(target_dir)
            self.toast.show_applied(target_dir, "", center, title="FOLDER STYLE RESET", subtitle=os.path.basename(target_dir) or target_dir)
        except Exception as err:
            self.lbl_sel.setText(f"Reset failed: {err}")

    def _on_next_clicked(self):
        _play_asmr_tick()
        center = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        if self._active_tab == "cursor":
            pk = next((p for p in CURSOR_PACKS if p["id"] == self._selected_cursor_id), None)
            if pk is None:
                return
            try:
                apply_cursor_pack(pk)
                self._active_cursor_id = pk["id"]
                for cc in self._cursor_cards:
                    cc.set_live_active(cc.pack["id"] == self._active_cursor_id)
                self.toast.show_applied("", "", center, title="CURSOR PACK APPLIED", subtitle=f"{pk['name']} now active")
            except Exception as err:
                self.lbl_sel.setText(f"Cursor error: {err}")
            return

        if not self._selected_path or not os.path.exists(self._selected_path):
            return

        if self._active_tab == "files":
            target_file, _ = QFileDialog.getOpenFileName(
                self,
                "Choose Shortcut (.lnk), File, App or Game to Style",
                get_desktop_dir(),
                "Shortcuts & Files (*.lnk *.exe *.pdf *.mp4 *.mp3 *.py *.*)",
            )
            if not target_file:
                return
            try:
                lnk_path = apply_file_shortcut_style(self._selected_path, target_file)
                self.toast.show_applied(
                    os.path.dirname(lnk_path),
                    self._selected_path,
                    center,
                    title="FILE SHORTCUT CREATED",
                    subtitle=os.path.basename(lnk_path),
                )
            except Exception as err:
                self.lbl_sel.setText(f"Shortcut failed: {err}")
            return

        target_dir = QFileDialog.getExistingDirectory(
            self,
            "Choose Folder to Apply Super Get Design Style",
            get_desktop_dir(),
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks,
        )
        if not target_dir:
            return
        try:
            apply_folder_icon_style(self._selected_path, target_dir)
            self.toast.show_applied(target_dir, self._selected_path, center)
        except Exception as err:
            self.lbl_sel.setText(f"Failed: {err}")

    def open_window(self):
        self.open_with_spring_animation()

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at center when switched from Quick Menu (no vertical slide)."""
        self.reload_gallery(self.search_input.text())
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()
        tx = avail.center().x() - w // 2
        ty = avail.center().y() - h // 2

        self.setGeometry(QRect(tx, ty, w, h))
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        """Quick, silky normal fade-out when returning to Cursor Menu (no vertical bounce)."""
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            self.hide()
            if on_finished:
                on_finished()

        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def open_with_spring_animation(self):
        self.reload_gallery(self.search_input.text())
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        full = screen.geometry()

        w, h = self.width(), self.height()
        tx = avail.center().x() - w // 2
        ty = avail.center().y() - h // 2
        target_geom = QRect(tx, ty, w, h)
        start_geom = QRect(tx, full.bottom() + 20, w, h)

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(400)
        ag.setStartValue(start_geom)
        ag.setEndValue(target_geom)
        ag.setEasingCurve(QEasingCurve.OutCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(330)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in = QParallelAnimationGroup(self)
        self.anim_in.addAnimation(ag)
        self.anim_in.addAnimation(af)
        self.anim_in.start()

    def close_with_pull_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        screen = QApplication.screenAt(self.pos()) or QApplication.primaryScreen()
        full = screen.geometry()
        curr = self.geometry()
        end_geom = QRect(curr.x(), full.bottom() + 20, curr.width(), curr.height())

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(320)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(280)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)

        def _done():
            self.hide()
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 54.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
            e.accept()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 32), 1.0))
        p.drawPath(card)

        # Razor-sharp vector brand aligned cleanly right of borderless Back + Home slots
        bx = 88.0
        by_c = 27.0
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0

        f_b = QFont("Segoe UI Variable")
        f_b.setStyleName("Display Bold")
        f_b.setPointSizeF(11.4)
        f_b.setLetterSpacing(QFont.AbsoluteSpacing, 0.32)
        f_b.setHintingPreference(QFont.PreferNoHinting)

        probe = QPainterPath()
        probe.addText(0.0, 0.0, f_b, "SUPER GET DESIGN")
        br = probe.boundingRect()
        baseline_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, baseline_y, f_b, "SUPER")
        p.fillPath(p1, QColor("#FFFFFF"))

        smx = bx + p1.boundingRect().width() + 5.5
        p2 = QPainterPath()
        p2.addText(smx, baseline_y, f_b, "GET DESIGN")
        b2 = p2.boundingRect()
        g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g_sm.setColorAt(0.0, QColor("#FFFF00"))
        g_sm.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g_sm)
        p.end()
