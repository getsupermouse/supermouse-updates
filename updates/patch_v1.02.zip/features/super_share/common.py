# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE VER 1.0 — SUPER SHARE STUDIO
===========================================
1. Device Window (Obsidian #040405 HUD matching THE SUPERMOUSE design):
   - 8-char logical Device ID: strictly 5 digits + 3 CAPITAL letters (e.g. 49281SMX)
   - 12-digit Linked Connection Code shared across the paired pair
   - Normal vs Trusted connection modes:
       * New connections start as Normal and show a one-time Accept notification on receiver
       * Promote once to Trusted -> future transfers bypass permission prompts cleanly
   - Deduplicated live LAN peer detection (never duplicates local phone/PC models)

2. Stored Window (Modeled after MY BOX open-canvas pure-black gallery):
   - Search bar, file count badge, open-canvas borderless saved image tiles
   - Click preview lightbox, Copy, Send to Connected Device, Open Folder, Delete

3. Behind-Taskbar Original-Aspect Emergence Animation:
   - NO boxy container around the incoming photo; renders the photo at natural original aspect
     ratio with subtle translucency and sleek below-image label, gliding smoothly upward from
     behind the Windows taskbar and saving directly into Pictures/SuperShare.
"""

import hashlib
import json
import os
import random
import re
import socket
import subprocess
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from PySide6.QtCore import (
    QEasingCurve,
    QObject,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    Qt,
    QTimer,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import (
    QIcon,
    QImage,
    QColor,
    QCursor,
    QFont,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QTransform,
    QLinearGradient,
)
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ui_theme import ACCENT_LIME, TEXT_MUTED, TEXT_PRIMARY, TEXT_SECONDARY, native_dpr, CleanBackButton, CleanCloseButton, CleanHeaderIconButton, render_common_icon, COMMON_ICONS, format_count_label

def _find_base_dir():
    cur = os.path.abspath(__file__)
    for _ in range(6):
        cur = os.path.dirname(cur)
        if os.path.isdir(os.path.join(cur, "thesupermouse", "assets")):
            return cur
    return r"D:\THESUPERMOUSE\VERSION 1.0"

BASE_DIR = _find_base_dir()
CONFIG_PATH = os.path.join(BASE_DIR, "super_share_config.json")
DEFAULT_SAVE_DIR = os.path.join(os.path.expanduser("~"), "Pictures", "SuperShare")

UDP_DISCOVERY_PORT = 48765
HTTP_PORT_START = 8766
HTTP_PORT_END = 8776

_DEVICE_ID_PATTERN = re.compile(r"^\d{5}[A-Z]{3}$")
_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}
_MEDIA_EXTS = _IMAGE_EXTS | {".mp4", ".mov", ".mkv", ".webm", ".avi"}


def generate_8char_device_id() -> str:
    """Strictly 5 numbers + 3 CAPITAL letters (e.g. 49281SMX)."""
    digits = "".join(random.choices("0123456789", k=5))
    letters = "".join(random.choices("ABCDEFGHJKLMNPQRSTUVWXYZ", k=3))
    return f"{digits}{letters}"


def compute_linked_12_code(id_a: str, id_b: str) -> str:
    """Deterministic 12-digit linked connection ID shared identically by both paired devices."""
    a, b = sorted([id_a.strip().upper(), id_b.strip().upper()])
    digest = hashlib.sha256(f"{a}:{b}".encode("utf-8")).hexdigest()
    nums = "".join(str(int(digest[i : i + 2], 16) % 10) for i in range(0, 24, 2))
    return nums[:12]


def format_12_code(code: str) -> str:
    c = "".join(ch for ch in code if ch.isdigit())[:12]
    if len(c) != 12:
        return c
    return f"{c[0:4]} {c[4:8]} {c[8:12]}"


def count_stored_share_items() -> int:
    if not os.path.exists(DEFAULT_SAVE_DIR):
        return 0
    try:
        return sum(
            1
            for fn in os.listdir(DEFAULT_SAVE_DIR)
            if os.path.isfile(os.path.join(DEFAULT_SAVE_DIR, fn)) and not fn.startswith(".")
        )
    except Exception:
        return 0


def _get_local_ipv4() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    try:
        host_ip = socket.gethostbyname(socket.gethostname())
        if host_ip and not host_ip.startswith("127."):
            return host_ip
    except Exception:
        pass
    return "127.0.0.1"


def _load_or_create_config() -> dict:
    os.makedirs(DEFAULT_SAVE_DIR, exist_ok=True)
    data = {}
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                data = raw
        except Exception:
            data = {}

    did = str(data.get("device_id") or "").strip().upper()
    if not _DEVICE_ID_PATTERN.match(did):
        did = generate_8char_device_id()
        data["device_id"] = did

    data.setdefault("device_name", f"{socket.gethostname() or 'Windows'} PC")
    data.setdefault("save_dir", DEFAULT_SAVE_DIR)
    data.setdefault("trusted_ids", [])
    _save_config(data)
    return data


def _save_config(data: dict):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


def _format_bytes(size: int) -> str:
    if size < 1024:
        return f"{size} B"
    kb = size / 1024.0
    if kb < 1024.0:
        return f"{kb:.0f} KB"
    return f"{kb / 1024.0:.1f} MB"




def _load_app_logo_pix(widget):
    base_assets = os.path.join(BASE_DIR, "thesupermouse", "assets")
    logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
    if not os.path.exists(logo_fp):
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
    raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
    if raw_logo and not raw_logo.isNull():
        ldpr = native_dpr(widget)
        li = raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
        pix = QPixmap.fromImage(li)
        pix.setDevicePixelRatio(ldpr)
        return pix
    return None


def _draw_vector_brand(p, bx, by_c, logo_pix, word1, word2, font_pt=11.4):
    """Render razor-sharp QPainterPath vector brand matching Super Snap & Pin."""
    if logo_pix and not logo_pix.isNull():
        dpr = max(1.0, float(logo_pix.devicePixelRatio() or 1.0))
        lw = logo_pix.width() / dpr
        lh = logo_pix.height() / dpr
        p.drawPixmap(int(round(bx)), int(round(by_c - lh / 2.0)), logo_pix)
        bx += lw + 7.5

    f_logo = QFont("Segoe UI Variable")
    f_logo.setStyleName("Display Bold")
    f_logo.setPointSizeF(font_pt)
    f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
    f_logo.setHintingPreference(QFont.PreferNoHinting)

    probe = QPainterPath()
    probe.addText(0.0, 0.0, f_logo, f"{word1} {word2}")
    br = probe.boundingRect()
    baseline_y = by_c - (br.top() + br.height() * 0.5)

    p1 = QPainterPath()
    p1.addText(bx, baseline_y, f_logo, word1)
    p.fillPath(p1, QColor("#FFFFFF"))

    w1 = p1.boundingRect().width()
    smx = bx + w1 + 5.0

    p2 = QPainterPath()
    p2.addText(smx, baseline_y, f_logo, word2)
    b2 = p2.boundingRect()
    g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
    g_sm.setColorAt(0.0, QColor("#FFFF00"))
    g_sm.setColorAt(1.0, QColor("#00FF85"))
    p.fillPath(p2, g_sm)


class _IosSwitch(QWidget):
    """Silky-smooth iOS pill toggle switch (cyber-lime active / obsidian rest)."""
    toggled = Signal(bool)

    def __init__(self, checked=True, parent=None):
        super().__init__(parent)
        self._checked = bool(checked)
        self._pos = 1.0 if self._checked else 0.0
        self.setFixedSize(38, 20)
        self.setCursor(Qt.PointingHandCursor)
        self._tm = QTimer(self)
        self._tm.setInterval(16)
        self._tm.timeout.connect(self._step)

    def isChecked(self):
        return self._checked

    def setChecked(self, val, animate=True):
        val = bool(val)
        if self._checked == val and not animate:
            return
        self._checked = val
        if not animate:
            self._pos = 1.0 if val else 0.0
            self.update()
        elif not self._tm.isActive():
            self._tm.start()

    def _step(self):
        tgt = 1.0 if self._checked else 0.0
        if abs(tgt - self._pos) < 0.015:
            self._pos = tgt
            self._tm.stop()
        else:
            self._pos += (tgt - self._pos) * 0.28
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._checked = not self._checked
            if not self._tm.isActive():
                self._tm.start()
            self.toggled.emit(self._checked)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        t = self._pos
        r = h / 2.0
        r_col = int(25 + t * (142 - 25))
        g_col = int(27 + t * (255 - 27))
        b_col = int(25 + t * (0 - 25))
        bg_col = QColor(r_col, g_col, b_col)
        p.setPen(Qt.NoPen)
        p.setBrush(bg_col)
        p.drawRoundedRect(QRectF(0, 0, w, h), r, r)
        knob_d = h - 4.0
        knob_x = 2.0 + t * (w - knob_d - 4.0)
        p.setBrush(QColor(0, 0, 0) if t > 0.5 else QColor(255, 255, 255, 220))
        p.drawEllipse(QRectF(knob_x, 2.0, knob_d, knob_d))


# ──────────────────────────────────────────────────────────────────────────────
#  WINDOW 1: DEVICE HUB (Unified Design Language matching Super Snap & Pin)
# ──────────────────────────────────────────────────────────────────────────────


# ─── AVATAR HELPER & 22 GRADIENT BORDERS ──────────────────────────────────
def _find_official_avatars_dir():
    cand1 = os.path.join(BASE_DIR, "thesupermouse", "assets", "avatars")
    if os.path.exists(cand1):
        return cand1
    cand2 = os.path.join(BASE_DIR, "assets", "avatars")
    if os.path.exists(cand2):
        return cand2
    return cand1

AVATARS_DIR = _find_official_avatars_dir()
USER_AVATARS_DIR = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TheSuperMouse", "user_avatars")

GRADIENT_PRESETS = [
    ("Cyber Lime", [(0.0, "#FFFF00"), (1.0, "#00FF85")]),
    ("Neon Purple", [(0.0, "#FF007F"), (1.0, "#7928CA")]),
    ("Sunset Fire", [(0.0, "#FF4E50"), (1.0, "#F9D423")]),
    ("Ocean Cyan", [(0.0, "#00C6FF"), (1.0, "#0072FF")]),
    ("Aurora Green", [(0.0, "#00F260"), (1.0, "#0575E6")]),
    ("Electric Rose", [(0.0, "#FA709A"), (1.0, "#FEE140")]),
    ("Ultra Violet", [(0.0, "#8A2387"), (0.5, "#E94057"), (1.0, "#F27121")]),
    ("Golden Sun", [(0.0, "#F7971E"), (1.0, "#FFD200")]),
    ("Emerald Mint", [(0.0, "#11998E"), (1.0, "#38EF7D")]),
    ("Deep Velvet", [(0.0, "#654EA3"), (1.0, "#EAAFC8")]),
    ("Cosmic Blue", [(0.0, "#24C6DC"), (1.0, "#514A9D")]),
    ("Cyberpunk Red", [(0.0, "#FF0844"), (1.0, "#FFB199")]),
    ("Solar Flare", [(0.0, "#F857A6"), (1.0, "#FF5858")]),
    ("Lime Matrix", [(0.0, "#96FBC4"), (1.0, "#F9F586")]),
    ("Midnight Indigo", [(0.0, "#3023AE"), (1.0, "#C86DD7")]),
    ("Titanium Chrome", [(0.0, "#E0EAFC"), (1.0, "#CFDEF3")]),
    ("Obsidian Shadow", [(0.0, "#434343"), (1.0, "#111111")]),
    ("Candy Bubblegum", [(0.0, "#F355DA"), (1.0, "#7000FF")]),
    ("Aqua Marine", [(0.0, "#4FACFE"), (1.0, "#00F2FE")]),
    ("Lava Magma", [(0.0, "#F12711"), (1.0, "#F5AF19")]),
    ("Mystic Forest", [(0.0, "#134E5E"), (1.0, "#71B280")]),
    ("Pure Lime Glow", [(0.0, "#a3e635"), (1.0, "#4ade80")]),
]

def get_avatar_pixmap(avatar_id: int | str = 1, size: int = 40, gradient_idx: int = 0, with_border: bool = False) -> QPixmap:
    # 1. Resolve avatar filename
    if isinstance(avatar_id, str):
        if avatar_id.isdigit():
            idx = int(avatar_id)
            fname = f"avatar_{idx:02d}.png"
        elif avatar_id.lower().endswith(('.png', '.jpg', '.jpeg')):
            fname = avatar_id
        else:
            fname = f"{avatar_id}.png"
    elif isinstance(avatar_id, int):
        fname = f"avatar_{avatar_id:02d}.png"
    else:
        fname = "avatar_01.png"

    raw_pix = None
    # Check official bundled avatars first (guaranteed offline & self-contained)
    cand_bundled = os.path.join(AVATARS_DIR, fname)
    if os.path.exists(cand_bundled):
        raw_pix = QPixmap(cand_bundled)
    elif os.path.exists(os.path.join(USER_AVATARS_DIR, fname)):
        raw_pix = QPixmap(os.path.join(USER_AVATARS_DIR, fname))
    else:
        # Fallback to avatar_01.png or first available in AVATARS_DIR
        cand_default = os.path.join(AVATARS_DIR, "avatar_01.png")
        if os.path.exists(cand_default):
            raw_pix = QPixmap(cand_default)
        elif os.path.exists(AVATARS_DIR):
            avail = sorted([f for f in os.listdir(AVATARS_DIR) if f.lower().endswith(('.png', '.jpg'))])
            if avail:
                raw_pix = QPixmap(os.path.join(AVATARS_DIR, avail[0]))

    dpr = 2.0
    w = int(round(size * dpr))
    out = QPixmap(w, w)
    out.fill(Qt.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setRenderHint(QPainter.SmoothPixmapTransform, True)

    if with_border:
        g_idx = max(0, min(len(GRADIENT_PRESETS) - 1, int(gradient_idx or 0)))
        stops = GRADIENT_PRESETS[g_idx][1]

        grad = QLinearGradient(0, 0, w, w)
        for stop, col in stops:
            grad.setColorAt(stop, QColor(col))

        p.setPen(Qt.NoPen)
        p.setBrush(grad)
        p.drawEllipse(0.0, 0.0, float(w), float(w))

        bw = max(2.5, float(w) * 0.055)
        inner_rect = QRectF(bw, bw, float(w) - bw * 2.0, float(w) - bw * 2.0)
    else:
        inner_rect = QRectF(0.0, 0.0, float(w), float(w))

    clip = QPainterPath()
    clip.addEllipse(inner_rect)
    p.setClipPath(clip)

    if raw_pix and not raw_pix.isNull():
        scaled = raw_pix.scaled(int(inner_rect.width()), int(inner_rect.height()), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        sx = inner_rect.x() + (inner_rect.width() - scaled.width()) / 2.0
        sy = inner_rect.y() + (inner_rect.height() - scaled.height()) / 2.0
        p.drawPixmap(int(round(sx)), int(round(sy)), scaled)
    else:
        p.fillRect(inner_rect, QColor("#12141A"))

    p.end()
    out.setDevicePixelRatio(dpr)
    return out




__all__ = [k for k in list(globals().keys()) if not k.startswith('__')]
